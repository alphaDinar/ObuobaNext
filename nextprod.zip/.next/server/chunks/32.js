"use strict";
exports.id = 32;
exports.ids = [32];
exports.modules = {

/***/ 3032:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T2": () => (/* binding */ fireStoreDB),
/* harmony export */   "jv": () => (/* binding */ storageDB),
/* harmony export */   "mO": () => (/* binding */ fireAuth)
/* harmony export */ });
/* unused harmony export realtimeDB */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_analytics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9500);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(401);
/* harmony import */ var firebase_database__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1208);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1492);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3392);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_analytics__WEBPACK_IMPORTED_MODULE_1__, firebase_auth__WEBPACK_IMPORTED_MODULE_2__, firebase_database__WEBPACK_IMPORTED_MODULE_3__, firebase_firestore__WEBPACK_IMPORTED_MODULE_4__, firebase_storage__WEBPACK_IMPORTED_MODULE_5__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_analytics__WEBPACK_IMPORTED_MODULE_1__, firebase_auth__WEBPACK_IMPORTED_MODULE_2__, firebase_database__WEBPACK_IMPORTED_MODULE_3__, firebase_firestore__WEBPACK_IMPORTED_MODULE_4__, firebase_storage__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const firebaseConfig = {
    apiKey: "AIzaSyApVndG5ivlqqQI4S51jGe62HFb86dkqCI",
    authDomain: "obuobafm-a1c6c.firebaseapp.com",
    projectId: "obuobafm-a1c6c",
    storageBucket: "obuobafm-a1c6c.appspot.com",
    messagingSenderId: "490975383648",
    appId: "1:490975383648:web:2d8e96cda3da559f3af305",
    measurementId: "G-SGS0Q50J9V"
};
// Initialize Firebase
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
const fireAuth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.getAuth)(app);
const realtimeDB = (0,firebase_database__WEBPACK_IMPORTED_MODULE_3__.getDatabase)(app);
const fireStoreDB = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_4__.getFirestore)(app);
const storageDB = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.getStorage)(app); // export const realtimeDB =  

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;