"use strict";
exports.id = 761;
exports.ids = [761];
exports.modules = {

/***/ 761:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ dayBoxes),
/* harmony export */   "b": () => (/* binding */ categories)
/* harmony export */ });
const categories = [
    {
        name: "news",
        label: "News Feed",
        iconEl: "breaking_news"
    },
    {
        name: "politics",
        label: "Politics",
        iconEl: "gavel"
    },
    {
        name: "business",
        label: "Business",
        iconEl: "payments"
    },
    {
        name: "entertainment",
        label: "Entertainment",
        iconEl: "sentiment_satisfied"
    },
    {
        name: "sports",
        label: "Sports",
        iconEl: "sports_soccer"
    },
    {
        name: "technology",
        label: "Technology",
        iconEl: "usb"
    },
    {
        name: "opinion",
        label: "Opinion",
        iconEl: "topic"
    },
    {
        name: "lifestyle",
        label: "Lifestyle",
        iconEl: "nightlife"
    },
    {
        name: "gallery",
        label: "Gallery",
        iconEl: "image"
    },
    {
        name: "obituary",
        label: "Obituary",
        iconEl: "deceased"
    }, 
];
const dayBoxes = [
    {
        code: 0,
        name: "Sunday"
    },
    {
        code: 1,
        name: "Monday"
    },
    {
        code: 2,
        name: "Tuesday"
    },
    {
        code: 3,
        name: "Wednesday"
    },
    {
        code: 4,
        name: "Thursday"
    },
    {
        code: 5,
        name: "Friday"
    },
    {
        code: 6,
        name: "Saturday"
    }
];


/***/ })

};
;