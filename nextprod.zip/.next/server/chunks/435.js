"use strict";
exports.id = 435;
exports.ids = [435];
exports.modules = {

/***/ 4435:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _External_external__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2292);
/* harmony import */ var _sides_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3924);
/* harmony import */ var _sides_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_sides_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _External_lists__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(761);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);






const Sidebar = ({ posts , setPosts  })=>{
    // const { posts, setPosts } = props;
    const { 0: postsBank , 1: setPostsBank  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const { 0: currentProgram , 1: setCurrentProgram  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setPostsBank(JSON.parse(sessionStorage.getItem("posts")));
        setCurrentProgram(JSON.parse(sessionStorage.getItem("currentProgram")));
    }, []);
    const filterPosts = (val)=>{
        if (posts) {
            setPosts(postsBank.filter((el)=>el.category === val));
        }
    };
    const { 0: sidebarToggled , 1: setSidebarToggled  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const toggleSidebar = ()=>{
        sidebarToggled ? setSidebarToggled(false) : setSidebarToggled(true);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: sidebarToggled ? `${(_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().sidebar)} ${(_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().change)}` : (_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().sidebar),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: toggleSidebar,
                children: (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("menu")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "https://res.cloudinary.com/dvnemzw0z/image/upload/v1692289104/logo_2_nxwecd.png"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        onClick: ()=>{
                            setPosts(postsBank);
                        },
                        children: [
                            " ",
                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("apps"),
                            "  ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "All"
                            })
                        ]
                    }),
                    _External_lists__WEBPACK_IMPORTED_MODULE_3__/* .categories.map */ .b.map((el, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            onClick: ()=>{
                                filterPosts(el.name);
                            },
                            children: [
                                (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)(el.iconEl),
                                "  ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: el.label
                                })
                            ]
                        }, i))
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        href: "",
                        children: [
                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-google", "#e94235"),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Google Podcast"
                            }),
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        href: "",
                        children: [
                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-itunes", "#924fea"),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "iTunes"
                            }),
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        href: "",
                        children: [
                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-spotify", "#2dd96b"),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Spotify"
                            }),
                            " "
                        ]
                    })
                ]
            }),
            currentProgram && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().presenterBox),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().imgBox),
                        style: {
                            backgroundImage: `url(${currentProgram.media})`
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Presenter Profile"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                children: [
                                    (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("person"),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: currentProgram.host
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("article", {
                        children: currentProgram.description
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().sideAdBox),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_5___default().sideAd),
                    "data-aos": "fade-up",
                    src: "https://res.cloudinary.com/dvnemzw0z/image/upload/v1693298884/WhatsApp_Image_2023-08-28_at_16.29.48_cmmbpk.jpg",
                    alt: ""
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);


/***/ })

};
;