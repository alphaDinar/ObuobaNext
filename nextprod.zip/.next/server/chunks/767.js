"use strict";
exports.id = 767;
exports.ids = [767];
exports.modules = {

/***/ 2767:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1492);
/* harmony import */ var _External_external__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2292);
/* harmony import */ var _Firebase_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3032);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8510);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_1__, _Firebase_base__WEBPACK_IMPORTED_MODULE_3__, _app__WEBPACK_IMPORTED_MODULE_6__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_1__, _Firebase_base__WEBPACK_IMPORTED_MODULE_3__, _app__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const TopNav = ()=>{
    const { 0: currentProgram , 1: setCurrentProgram  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: nextProgram , 1: setNextProgram  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { playing , setPlaying  } = (0,_app__WEBPACK_IMPORTED_MODULE_6__.usePlaying)();
    const togglePlaying = ()=>{
        playing ? setPlaying(false) : setPlaying(true);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDoc)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.doc)(_Firebase_base__WEBPACK_IMPORTED_MODULE_3__/* .fireStoreDB */ .T2, "Obuoba/con")).then((res)=>{
            const day = new Date().getDay();
            const nextDay = new Date(new Date().setDate(new Date().getDate() + 1)).getDay();
            const hours = new Date().getHours();
            const minutes = new Date().getMinutes();
            const sortByHour = (a, b)=>{
                const hourA = a.start.split(",")[0];
                const hourB = b.start.split(",")[0];
                return hourA - hourB;
            };
            const dailyPrograms = res.data().programs.filter((el)=>parseInt(el.day) === day).sort(sortByHour);
            dailyPrograms.map((el)=>{
                const startHours = parseInt(el.start.split(":")[0]);
                const startMinutes = parseInt(el.start.split(":")[1]);
                const endHours = parseInt(el.end.split(":")[0]);
                const endMinutes = parseInt(el.end.split(":")[1]);
                if ((hours > startHours || hours === startHours && minutes >= startMinutes) && (hours < endHours || hours === endHours && minutes <= endMinutes)) {
                    setCurrentProgram(el);
                } else {
                    console.log("me");
                }
                const currentProgramIndex = dailyPrograms.indexOf(el);
                if (dailyPrograms[currentProgramIndex + 1]) {
                    setNextProgram(dailyPrograms[currentProgramIndex + 1]);
                } else {
                    setNextProgram(res.data().programs.filter((el)=>parseInt(el.day) === nextDay).sort(sortByHour)[0]);
                }
            });
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "top_nav",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "player",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    " ",
                                    currentProgram.name,
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                                children: [
                                    " ",
                                    currentProgram.start,
                                    " - ",
                                    currentProgram.end
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: togglePlaying,
                        children: playing ? (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("power_settings_new") : (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("play_arrow")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("audio", {
                        muted: true,
                        style: {
                            display: "none"
                        },
                        id: "radio_track",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                            src: "https://dc4.serverse.com/proxy/vlauavyv/stream",
                            type: "audio/mpeg"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "left_box",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "left",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                children: "Follow Us On"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                style: {
                                    width: "80px",
                                    borderTop: "2px solid darkgray"
                                }
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "",
                                        children: (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-instagram", "white")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "",
                                        children: (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-facebook", "white")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "",
                                        children: (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-twitter", "white")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "",
                                        children: (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .iconFont */ .vC)("fa-brands fa-tiktok", "white")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/about",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    children: [
                                        " ",
                                        (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("not_listed_location"),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "About us"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/contact",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    href: "",
                                    children: [
                                        " ",
                                        (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("contacts"),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Contact us"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/terms",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    href: "",
                                    children: [
                                        " ",
                                        (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("assignment"),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Terms and Policies"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopNav); // <div className="right">
 // <input type="text" placeholder="Search" />
 // {icon('search')}
 // </div>

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;