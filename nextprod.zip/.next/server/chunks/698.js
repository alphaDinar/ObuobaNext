exports.id = 698;
exports.ids = [698];
exports.modules = {

/***/ 3924:
/***/ ((module) => {

// Exports
module.exports = {
	"sidebar": "sides_sidebar__ISRYb",
	"panel": "sides_panel__f1_BG",
	"presenterBox": "sides_presenterBox__JKKTS",
	"imgBox": "sides_imgBox__KXlsn",
	"aBox": "sides_aBox__DFq8P",
	"sideAdBox": "sides_sideAdBox__OObJX",
	"panelAdBox": "sides_panelAdBox__v__cm",
	"sideAd": "sides_sideAd__JXuCF",
	"panelAd": "sides_panelAd__0yF_H",
	"players": "sides_players__X4vfW",
	"player_box": "sides_player_box___gYAA",
	"bars": "sides_bars___CcWz",
	"main_player": "sides_main_player__ERA00",
	"low": "sides_low__bRXd0",
	"player_image": "sides_player_image__BqnDl",
	"progress_box": "sides_progress_box__5H60w",
	"graph": "sides_graph__AkGkO",
	"line": "sides_line__rso2_",
	"progress_box_holder": "sides_progress_box_holder__8x7Zu",
	"play_btn": "sides_play_btn__1z6Oz",
	"topStoryBox": "sides_topStoryBox__QFd_g",
	"topStories": "sides_topStories__ynV8_",
	"topStory": "sides_topStory__cJ0mN",
	"change": "sides_change__6Qdv9",
	"playlist": "sides_playlist__8JTju"
};


/***/ }),

/***/ 9698:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _External_external__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2292);
/* harmony import */ var _sides_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3924);
/* harmony import */ var _sides_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_sides_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Firebase_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3032);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1492);
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8510);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Firebase_base__WEBPACK_IMPORTED_MODULE_3__, firebase_firestore__WEBPACK_IMPORTED_MODULE_4__, _app__WEBPACK_IMPORTED_MODULE_5__]);
([_Firebase_base__WEBPACK_IMPORTED_MODULE_3__, firebase_firestore__WEBPACK_IMPORTED_MODULE_4__, _app__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Panel = ()=>{
    const { 0: currentProgram , 1: setCurrentProgram  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: nextProgram , 1: setNextProgram  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { playing , setPlaying  } = (0,_app__WEBPACK_IMPORTED_MODULE_5__.usePlaying)();
    const togglePlaying = ()=>{
        playing ? setPlaying(false) : setPlaying(true);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_4__.getDoc)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_4__.doc)(_Firebase_base__WEBPACK_IMPORTED_MODULE_3__/* .fireStoreDB */ .T2, "Obuoba/con")).then((res)=>{
            const day = new Date().getDay();
            const nextDay = new Date(new Date().setDate(new Date().getDate() + 1)).getDay();
            const hours = new Date().getHours();
            const minutes = new Date().getMinutes();
            const sortByHour = (a, b)=>{
                const hourA = a.start.split(",")[0];
                const hourB = b.start.split(",")[0];
                return hourA - hourB;
            };
            const dailyPrograms = res.data().programs.filter((el)=>parseInt(el.day) === day).sort(sortByHour);
            dailyPrograms.map((el)=>{
                const startHours = parseInt(el.start.split(":")[0]);
                const startMinutes = parseInt(el.start.split(":")[1]);
                const endHours = parseInt(el.end.split(":")[0]);
                const endMinutes = parseInt(el.end.split(":")[1]);
                if ((hours > startHours || hours === startHours && minutes >= startMinutes) && (hours < endHours || hours === endHours && minutes <= endMinutes)) {
                    sessionStorage.setItem("currentProgram", JSON.stringify(el));
                    setCurrentProgram(el);
                    const currentProgramIndex = dailyPrograms.indexOf(el);
                    console.log(currentProgramIndex);
                    if (dailyPrograms[currentProgramIndex + 1]) {
                        setNextProgram(dailyPrograms[currentProgramIndex + 1]);
                    } else {
                        setNextProgram(res.data().programs.filter((el)=>parseInt(el.day) === nextDay).sort(sortByHour)[0]);
                    }
                } else {
                    console.log("me");
                }
            });
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().panel),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().players),
                children: [
                    currentProgram && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().player_box),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                id: "tag",
                                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().cur_tag),
                                style: {
                                    zIndex: 1000
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().bars),
                                        style: {
                                            position: "revert"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {})
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().player_image),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: currentProgram.media
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("person"),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: currentProgram.host
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("radio"),
                                            " ",
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    "Program : ",
                                                    currentProgram.name
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("timer"),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    currentProgram.start,
                                                    " - ",
                                                    currentProgram.end
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().progress_box_holder),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: togglePlaying,
                                                children: playing ? (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("power_settings_new") : (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("play_arrow")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().progress_box),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().line)
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().graph),
                                                        style: {
                                                            position: "revert"
                                                        }
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().bars),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {})
                                ]
                            })
                        ]
                    }),
                    nextProgram && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().player_box),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "Up Next"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().player_image),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: nextProgram.media
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("person"),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: nextProgram.host
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("radio"),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "next_program "
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            (0,_External_external__WEBPACK_IMPORTED_MODULE_2__/* .icon */ .qv)("timer"),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "10:10 - 12:10"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().panelAdBox),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().panelAd),
                    "data-aos": "fade-up",
                    src: "https://res.cloudinary.com/dvnemzw0z/image/upload/v1693298884/WhatsApp_Image_2023-08-28_at_16.29.48_cmmbpk.jpg"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().panelAdBox),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: (_sides_module_css__WEBPACK_IMPORTED_MODULE_6___default().panelAd),
                    "data-aos": "fade-up",
                    src: "https://res.cloudinary.com/dvnemzw0z/image/upload/v1693298884/WhatsApp_Image_2023-08-28_at_16.29.48_cmmbpk.jpg",
                    alt: ""
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Panel); // <section className={styles.topStoryBox}>
 // <h3>Top Stories</h3>
 // <section className={styles.topStories}>
 //   <a href="{% url 'view_post_page' post.slug %}" data-tags="post.tags" className="topStory">
 //     <span>NPP</span>
 //     <p>
 //       post.title
 //     </p>
 //   </a>
 // </section>
 // </section>

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;