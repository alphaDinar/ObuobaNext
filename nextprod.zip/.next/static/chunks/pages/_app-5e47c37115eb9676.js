(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[888],{4444:function(e,t,n){"use strict";n.d(t,{$s:function(){return es},BH:function(){return E},DV:function(){return W},GJ:function(){return z},L:function(){return d},LL:function(){return F},P0:function(){return b},Pz:function(){return I},Sg:function(){return C},UG:function(){return N},UI:function(){return K},US:function(){return h},Wl:function(){return j},Yr:function(){return P},ZR:function(){return M},aH:function(){return T},b$:function(){return A},cI:function(){return V},dS:function(){return ei},eu:function(){return x},g5:function(){return o},gK:function(){return en},gQ:function(){return J},h$:function(){return c},hl:function(){return O},hu:function(){return s},m9:function(){return eo},ne:function(){return Z},p$:function(){return p},pd:function(){return X},q4:function(){return w},r3:function(){return $},ru:function(){return R},tV:function(){return f},uI:function(){return k},ug:function(){return er},vZ:function(){return function e(t,n){if(t===n)return!0;let i=Object.keys(t),r=Object.keys(n);for(let s of i){if(!r.includes(s))return!1;let o=t[s],a=n[s];if(G(o)&&G(a)){if(!e(o,a))return!1}else if(o!==a)return!1}for(let l of r)if(!i.includes(l))return!1;return!0}},w1:function(){return D},w9:function(){return B},xO:function(){return Q},xb:function(){return H},z$:function(){return S},zI:function(){return L},zd:function(){return Y}});var i=n(3454);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let r={NODE_CLIENT:!1,NODE_ADMIN:!1,SDK_VERSION:"${JSCORE_VERSION}"},s=function(e,t){if(!e)throw o(t)},o=function(e){return Error("Firebase Database ("+r.SDK_VERSION+") INTERNAL ASSERT FAILED: "+e)},a=function(e){let t=[],n=0;for(let i=0;i<e.length;i++){let r=e.charCodeAt(i);r<128?t[n++]=r:r<2048?(t[n++]=r>>6|192,t[n++]=63&r|128):(64512&r)==55296&&i+1<e.length&&(64512&e.charCodeAt(i+1))==56320?(r=65536+((1023&r)<<10)+(1023&e.charCodeAt(++i)),t[n++]=r>>18|240,t[n++]=r>>12&63|128,t[n++]=r>>6&63|128,t[n++]=63&r|128):(t[n++]=r>>12|224,t[n++]=r>>6&63|128,t[n++]=63&r|128)}return t},l=function(e){let t=[],n=0,i=0;for(;n<e.length;){let r=e[n++];if(r<128)t[i++]=String.fromCharCode(r);else if(r>191&&r<224){let s=e[n++];t[i++]=String.fromCharCode((31&r)<<6|63&s)}else if(r>239&&r<365){let o=e[n++],a=e[n++],l=e[n++],h=((7&r)<<18|(63&o)<<12|(63&a)<<6|63&l)-65536;t[i++]=String.fromCharCode(55296+(h>>10)),t[i++]=String.fromCharCode(56320+(1023&h))}else{let u=e[n++],c=e[n++];t[i++]=String.fromCharCode((15&r)<<12|(63&u)<<6|63&c)}}return t.join("")},h={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:"function"==typeof atob,encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();let n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,i=[];for(let r=0;r<e.length;r+=3){let s=e[r],o=r+1<e.length,a=o?e[r+1]:0,l=r+2<e.length,h=l?e[r+2]:0,u=s>>2,c=(3&s)<<4|a>>4,d=(15&a)<<2|h>>6,f=63&h;l||(f=64,o||(d=64)),i.push(n[u],n[c],n[d],n[f])}return i.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(a(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):l(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();let n=t?this.charToByteMapWebSafe_:this.charToByteMap_,i=[];for(let r=0;r<e.length;){let s=n[e.charAt(r++)],o=r<e.length,a=o?n[e.charAt(r)]:0;++r;let l=r<e.length,h=l?n[e.charAt(r)]:64;++r;let c=r<e.length,d=c?n[e.charAt(r)]:64;if(++r,null==s||null==a||null==h||null==d)throw new u;let f=s<<2|a>>4;if(i.push(f),64!==h){let p=a<<4&240|h>>2;if(i.push(p),64!==d){let g=h<<6&192|d;i.push(g)}}}return i},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class u extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}let c=function(e){let t=a(e);return h.encodeByteArray(t,!0)},d=function(e){return c(e).replace(/\./g,"")},f=function(e){try{return h.decodeString(e,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function p(e){return function e(t,n){if(!(n instanceof Object))return n;switch(n.constructor){case Date:return new Date(n.getTime());case Object:void 0===t&&(t={});break;case Array:t=[];break;default:return n}for(let i in n)n.hasOwnProperty(i)&&g(i)&&(t[i]=e(t[i],n[i]));return t}(void 0,e)}function g(e){return"__proto__"!==e}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let m=()=>/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ (function(){if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;if(void 0!==n.g)return n.g;throw Error("Unable to locate global object.")})().__FIREBASE_DEFAULTS__,_=()=>{if(void 0===i||void 0===i.env)return;let e=i.env.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},y=()=>{if("undefined"==typeof document)return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch(t){return}let n=e&&f(e[1]);return n&&JSON.parse(n)},v=()=>{try{return m()||_()||y()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},w=e=>{var t,n;return null===(n=null===(t=v())||void 0===t?void 0:t.emulatorHosts)||void 0===n?void 0:n[e]},b=e=>{let t=w(e);if(!t)return;let n=t.lastIndexOf(":");if(n<=0||n+1===t.length)throw Error(`Invalid host ${t} with no separate hostname and port!`);let i=parseInt(t.substring(n+1),10);return"["===t[0]?[t.substring(1,n-1),i]:[t.substring(0,n),i]},T=()=>{var e;return null===(e=v())||void 0===e?void 0:e.config},I=e=>{var t;return null===(t=v())||void 0===t?void 0:t[`_${e}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class E{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,n)=>{t?this.reject(t):this.resolve(n),"function"==typeof e&&(this.promise.catch(()=>{}),1===e.length?e(t):e(t,n))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function C(e,t){if(e.uid)throw Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');let n=t||"demo-project",i=e.iat||0,r=e.sub||e.user_id;if(!r)throw Error("mockUserToken must contain 'sub' or 'user_id' field!");let s=Object.assign({iss:`https://securetoken.google.com/${n}`,aud:n,iat:i,exp:i+3600,auth_time:i,sub:r,user_id:r,firebase:{sign_in_provider:"custom",identities:{}}},e);return[d(JSON.stringify({alg:"none",type:"JWT"})),d(JSON.stringify(s)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function S(){return"undefined"!=typeof navigator&&"string"==typeof navigator.userAgent?navigator.userAgent:""}function k(){return"undefined"!=typeof window&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(S())}function N(){var e;let t=null===(e=v())||void 0===e?void 0:e.forceEnvironment;if("node"===t)return!0;if("browser"===t)return!1;try{return"[object process]"===Object.prototype.toString.call(n.g.process)}catch(i){return!1}}function R(){let e="object"==typeof chrome?chrome.runtime:"object"==typeof browser?browser.runtime:void 0;return"object"==typeof e&&void 0!==e.id}function A(){return"object"==typeof navigator&&"ReactNative"===navigator.product}function D(){let e=S();return e.indexOf("MSIE ")>=0||e.indexOf("Trident/")>=0}function P(){return!0===r.NODE_CLIENT||!0===r.NODE_ADMIN}function O(){try{return"object"==typeof indexedDB}catch(e){return!1}}function x(){return new Promise((e,t)=>{try{let n=!0,i="validate-browser-context-for-indexeddb-analytics-module",r=self.indexedDB.open(i);r.onsuccess=()=>{r.result.close(),n||self.indexedDB.deleteDatabase(i),e(!0)},r.onupgradeneeded=()=>{n=!1},r.onerror=()=>{var e;t((null===(e=r.error)||void 0===e?void 0:e.message)||"")}}catch(s){t(s)}})}function L(){return"undefined"!=typeof navigator&&!!navigator.cookieEnabled}class M extends Error{constructor(e,t,n){super(t),this.code=e,this.customData=n,this.name="FirebaseError",Object.setPrototypeOf(this,M.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,F.prototype.create)}}class F{constructor(e,t,n){this.service=e,this.serviceName=t,this.errors=n}create(e,...t){var n,i;let r=t[0]||{},s=`${this.service}/${e}`,o=this.errors[e],a=o?(n=o,i=r,n.replace(U,(e,t)=>{let n=i[t];return null!=n?String(n):`<${t}?>`})):"Error",l=`${this.serviceName}: ${a} (${s}).`,h=new M(s,l,r);return h}}let U=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function V(e){return JSON.parse(e)}function j(e){return JSON.stringify(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let q=function(e){let t={},n={},i={},r="";try{let s=e.split(".");t=V(f(s[0])||""),n=V(f(s[1])||""),r=s[2],i=n.d||{},delete n.d}catch(o){}return{header:t,claims:n,data:i,signature:r}},B=function(e){let t=q(e),n=t.claims;return!!n&&"object"==typeof n&&n.hasOwnProperty("iat")},z=function(e){let t=q(e).claims;return"object"==typeof t&&!0===t.admin};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function $(e,t){return Object.prototype.hasOwnProperty.call(e,t)}function W(e,t){return Object.prototype.hasOwnProperty.call(e,t)?e[t]:void 0}function H(e){for(let t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1;return!0}function K(e,t,n){let i={};for(let r in e)Object.prototype.hasOwnProperty.call(e,r)&&(i[r]=t.call(n,e[r],r,e));return i}function G(e){return null!==e&&"object"==typeof e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function Q(e){let t=[];for(let[n,i]of Object.entries(e))Array.isArray(i)?i.forEach(e=>{t.push(encodeURIComponent(n)+"="+encodeURIComponent(e))}):t.push(encodeURIComponent(n)+"="+encodeURIComponent(i));return t.length?"&"+t.join("&"):""}function Y(e){let t={},n=e.replace(/^\?/,"").split("&");return n.forEach(e=>{if(e){let[n,i]=e.split("=");t[decodeURIComponent(n)]=decodeURIComponent(i)}}),t}function X(e){let t=e.indexOf("?");if(!t)return"";let n=e.indexOf("#",t);return e.substring(t,n>0?n:void 0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class J{constructor(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=64,this.pad_[0]=128;for(let e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}reset(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0}compress_(e,t){t||(t=0);let n=this.W_;if("string"==typeof e)for(let i=0;i<16;i++)n[i]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(let r=0;r<16;r++)n[r]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(let s=16;s<80;s++){let o=n[s-3]^n[s-8]^n[s-14]^n[s-16];n[s]=(o<<1|o>>>31)&4294967295}let a=this.chain_[0],l=this.chain_[1],h=this.chain_[2],u=this.chain_[3],c=this.chain_[4],d,f;for(let p=0;p<80;p++){p<40?p<20?(d=u^l&(h^u),f=1518500249):(d=l^h^u,f=1859775393):p<60?(d=l&h|u&(l|h),f=2400959708):(d=l^h^u,f=3395469782);let g=(a<<5|a>>>27)+d+c+f+n[p]&4294967295;c=u,u=h,h=(l<<30|l>>>2)&4294967295,l=a,a=g}this.chain_[0]=this.chain_[0]+a&4294967295,this.chain_[1]=this.chain_[1]+l&4294967295,this.chain_[2]=this.chain_[2]+h&4294967295,this.chain_[3]=this.chain_[3]+u&4294967295,this.chain_[4]=this.chain_[4]+c&4294967295}update(e,t){if(null==e)return;void 0===t&&(t=e.length);let n=t-this.blockSize,i=0,r=this.buf_,s=this.inbuf_;for(;i<t;){if(0===s)for(;i<=n;)this.compress_(e,i),i+=this.blockSize;if("string"==typeof e){for(;i<t;)if(r[s]=e.charCodeAt(i),++s,++i,s===this.blockSize){this.compress_(r),s=0;break}}else for(;i<t;)if(r[s]=e[i],++s,++i,s===this.blockSize){this.compress_(r),s=0;break}}this.inbuf_=s,this.total_+=t}digest(){let e=[],t=8*this.total_;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(let n=this.blockSize-1;n>=56;n--)this.buf_[n]=255&t,t/=256;this.compress_(this.buf_);let i=0;for(let r=0;r<5;r++)for(let s=24;s>=0;s-=8)e[i]=this.chain_[r]>>s&255,++i;return e}}function Z(e,t){let n=new ee(e,t);return n.subscribe.bind(n)}class ee{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(e=>{this.error(e)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,n){let i;if(void 0===e&&void 0===t&&void 0===n)throw Error("Missing Observer.");void 0===(i=!function(e,t){if("object"!=typeof e||null===e)return!1;for(let n of t)if(n in e&&"function"==typeof e[n])return!0;return!1}(e,["next","error","complete"])?{next:e,error:t,complete:n}:e).next&&(i.next=et),void 0===i.error&&(i.error=et),void 0===i.complete&&(i.complete=et);let r=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch(e){}}),this.observers.push(i),r}unsubscribeOne(e){void 0!==this.observers&&void 0!==this.observers[e]&&(delete this.observers[e],this.observerCount-=1,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(void 0!==this.observers&&void 0!==this.observers[e])try{t(this.observers[e])}catch(n){"undefined"!=typeof console&&console.error&&console.error(n)}})}close(e){!this.finalized&&(this.finalized=!0,void 0!==e&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function et(){}function en(e,t){return`${e} failed: ${t} argument `}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ei=function(e){let t=[],n=0;for(let i=0;i<e.length;i++){let r=e.charCodeAt(i);if(r>=55296&&r<=56319){let o=r-55296;s(++i<e.length,"Surrogate pair missing trail surrogate.");let a=e.charCodeAt(i)-56320;r=65536+(o<<10)+a}r<128?t[n++]=r:r<2048?(t[n++]=r>>6|192,t[n++]=63&r|128):r<65536?(t[n++]=r>>12|224,t[n++]=r>>6&63|128,t[n++]=63&r|128):(t[n++]=r>>18|240,t[n++]=r>>12&63|128,t[n++]=r>>6&63|128,t[n++]=63&r|128)}return t},er=function(e){let t=0;for(let n=0;n<e.length;n++){let i=e.charCodeAt(n);i<128?t++:i<2048?t+=2:i>=55296&&i<=56319?(t+=4,n++):t+=3}return t};function es(e,t=1e3,n=2){let i=t*Math.pow(n,e);return Math.min(144e5,i+Math.round(.5*i*(Math.random()-.5)*2))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function eo(e){return e&&e._delegate?e._delegate:e}},3454:function(e,t,n){"use strict";var i,r;e.exports=(null==(i=n.g.process)?void 0:i.env)&&"object"==typeof(null==(r=n.g.process)?void 0:r.env)?n.g.process:n(7663)},1118:function(e,t,n){(window.__NEXT_P=window.__NEXT_P||[]).push(["/_app",function(){return n(2373)}])},6786:function(e,t,n){"use strict";n.d(t,{mO:function(){return rb},T2:function(){return rT},jv:function(){return rI}});var i,r,s,o,a,l,h,u,c,d=n(5816);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ (0,d.KN)("firebase","10.5.0","app");var f=n(3333),p=n(4444),g=n(8463);let m=(e,t)=>t.some(t=>e instanceof t),_,y,v=new WeakMap,w=new WeakMap,b=new WeakMap,T=new WeakMap,I=new WeakMap,E={get(e,t,n){if(e instanceof IDBTransaction){if("done"===t)return w.get(e);if("objectStoreNames"===t)return e.objectStoreNames||b.get(e);if("store"===t)return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return C(e[t])},set:(e,t,n)=>(e[t]=n,!0),has:(e,t)=>e instanceof IDBTransaction&&("done"===t||"store"===t)||t in e};function C(e){if(e instanceof IDBRequest)return function(e){let t=new Promise((t,n)=>{let i=()=>{e.removeEventListener("success",r),e.removeEventListener("error",s)},r=()=>{t(C(e.result)),i()},s=()=>{n(e.error),i()};e.addEventListener("success",r),e.addEventListener("error",s)});return t.then(t=>{t instanceof IDBCursor&&v.set(t,e)}).catch(()=>{}),I.set(t,e),t}(e);if(T.has(e))return T.get(e);let t=function(e){if("function"==typeof e){var t;return e!==IDBDatabase.prototype.transaction||"objectStoreNames"in IDBTransaction.prototype?(y||(y=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey,])).includes(e)?function(...t){return e.apply(S(this),t),C(v.get(this))}:function(...t){return C(e.apply(S(this),t))}:function(t,...n){let i=e.call(S(this),t,...n);return b.set(i,t.sort?t.sort():[t]),C(i)}}return(e instanceof IDBTransaction&&function(e){if(w.has(e))return;let t=new Promise((t,n)=>{let i=()=>{e.removeEventListener("complete",r),e.removeEventListener("error",s),e.removeEventListener("abort",s)},r=()=>{t(),i()},s=()=>{n(e.error||new DOMException("AbortError","AbortError")),i()};e.addEventListener("complete",r),e.addEventListener("error",s),e.addEventListener("abort",s)});w.set(e,t)}(e),m(e,_||(_=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction,])))?new Proxy(e,E):e}(e);return t!==e&&(T.set(e,t),I.set(t,e)),t}let S=e=>I.get(e),k=["get","getKey","getAll","getAllKeys","count"],N=["put","add","delete","clear"],R=new Map;function A(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&"string"==typeof t))return;if(R.get(t))return R.get(t);let n=t.replace(/FromIndex$/,""),i=t!==n,r=N.includes(n);if(!(n in(i?IDBIndex:IDBObjectStore).prototype)||!(r||k.includes(n)))return;let s=async function(e,...t){let s=this.transaction(e,r?"readwrite":"readonly"),o=s.store;return i&&(o=o.index(t.shift())),(await Promise.all([o[n](...t),r&&s.done,]))[0]};return R.set(t,s),s}E=(i=e=>({...e,get:(t,n,i)=>A(t,n)||e.get(t,n,i),has:(t,n)=>!!A(t,n)||e.has(t,n)}))(E);let D="@firebase/installations",P="0.6.4",O=`w:${P}`,x="FIS_v2",L=new p.LL("installations","Installations",{"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."});function M(e){return e instanceof p.ZR&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function F({projectId:e}){return`https://firebaseinstallations.googleapis.com/v1/projects/${e}/installations`}function U(e){var t;return{token:e.token,requestStatus:2,expiresIn:(t=e.expiresIn,Number(t.replace("s","000"))),creationTime:Date.now()}}async function V(e,t){let n=await t.json(),i=n.error;return L.create("request-failed",{requestName:e,serverCode:i.code,serverMessage:i.message,serverStatus:i.status})}function j({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}async function q(e){let t=await e();return t.status>=500&&t.status<600?e():t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function B({appConfig:e,heartbeatServiceProvider:t},{fid:n}){let i=F(e),r=j(e),s=t.getImmediate({optional:!0});if(s){let o=await s.getHeartbeatsHeader();o&&r.append("x-firebase-client",o)}let a={fid:n,authVersion:x,appId:e.appId,sdkVersion:O},l={method:"POST",headers:r,body:JSON.stringify(a)},h=await q(()=>fetch(i,l));if(h.ok){let u=await h.json(),c={fid:u.fid||n,registrationStatus:2,refreshToken:u.refreshToken,authToken:U(u.authToken)};return c}throw await V("Create Installation",h)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function z(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let $=/^[cdef][\w-]{21}$/;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function W(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let H=new Map;function K(e,t){let n=W(e);G(n,t),function(e,t){let n=(!Q&&"BroadcastChannel"in self&&((Q=new BroadcastChannel("[Firebase] FID Change")).onmessage=e=>{G(e.data.key,e.data.fid)}),Q);n&&n.postMessage({key:e,fid:t}),0===H.size&&Q&&(Q.close(),Q=null)}(n,t)}function G(e,t){let n=H.get(e);if(n)for(let i of n)i(t)}let Q=null,Y="firebase-installations-store",X=null;function J(){return X||(X=function(e,t,{blocked:n,upgrade:i,blocking:r,terminated:s}={}){let o=indexedDB.open(e,1),a=C(o);return i&&o.addEventListener("upgradeneeded",e=>{i(C(o.result),e.oldVersion,e.newVersion,C(o.transaction))}),n&&o.addEventListener("blocked",()=>n()),a.then(e=>{s&&e.addEventListener("close",()=>s()),r&&e.addEventListener("versionchange",()=>r())}).catch(()=>{}),a}("firebase-installations-database",1,{upgrade(e,t){0===t&&e.createObjectStore(Y)}})),X}async function Z(e,t){let n=W(e),i=await J(),r=i.transaction(Y,"readwrite"),s=r.objectStore(Y),o=await s.get(n);return await s.put(t,n),await r.done,o&&o.fid===t.fid||K(e,t.fid),t}async function ee(e){let t=W(e),n=await J(),i=n.transaction(Y,"readwrite");await i.objectStore(Y).delete(t),await i.done}async function et(e,t){let n=W(e),i=await J(),r=i.transaction(Y,"readwrite"),s=r.objectStore(Y),o=await s.get(n),a=t(o);return void 0===a?await s.delete(n):await s.put(a,n),await r.done,a&&(!o||o.fid!==a.fid)&&K(e,a.fid),a}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function en(e){let t,n=await et(e.appConfig,n=>{let i=function(e){let t=e||{fid:function(){try{let e=new Uint8Array(17),t=self.crypto||self.msCrypto;t.getRandomValues(e),e[0]=112+e[0]%16;let n=function(e){let t=/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){let t=btoa(String.fromCharCode(...e));return t.replace(/\+/g,"-").replace(/\//g,"_")}(e);return t.substr(0,22)}(e);return $.test(n)?n:""}catch(i){return""}}(),registrationStatus:0};return eo(t)}(n),r=function(e,t){if(0===t.registrationStatus){if(!navigator.onLine){let n=Promise.reject(L.create("app-offline"));return{installationEntry:t,registrationPromise:n}}let i={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},r=ei(e,i);return{installationEntry:i,registrationPromise:r}}return 1===t.registrationStatus?{installationEntry:t,registrationPromise:er(e)}:{installationEntry:t}}(e,i);return t=r.registrationPromise,r.installationEntry});return""===n.fid?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}async function ei(e,t){try{let n=await B(e,t);return Z(e.appConfig,n)}catch(i){throw M(i)&&409===i.customData.serverCode?await ee(e.appConfig):await Z(e.appConfig,{fid:t.fid,registrationStatus:0}),i}}async function er(e){let t=await es(e.appConfig);for(;1===t.registrationStatus;)await z(100),t=await es(e.appConfig);if(0===t.registrationStatus){let{installationEntry:n,registrationPromise:i}=await en(e);return i||n}return t}function es(e){return et(e,e=>{if(!e)throw L.create("installation-not-found");return eo(e)})}function eo(e){var t;return(t=e,1===t.registrationStatus&&t.registrationTime+1e4<Date.now())?{fid:e.fid,registrationStatus:0}:e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function ea({appConfig:e,heartbeatServiceProvider:t},n){let i=function(e,{fid:t}){return`${F(e)}/${t}/authTokens:generate`}(e,n),r=function(e,{refreshToken:t}){var n;let i=j(e);return i.append("Authorization",(n=t,`${x} ${n}`)),i}(e,n),s=t.getImmediate({optional:!0});if(s){let o=await s.getHeartbeatsHeader();o&&r.append("x-firebase-client",o)}let a={installation:{sdkVersion:O,appId:e.appId}},l={method:"POST",headers:r,body:JSON.stringify(a)},h=await q(()=>fetch(i,l));if(h.ok){let u=await h.json(),c=U(u);return c}throw await V("Generate Auth Token",h)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function el(e,t=!1){let n,i=await et(e.appConfig,i=>{var r;if(!ed(i))throw L.create("not-registered");let s=i.authToken;if(!t&&(r=s,2===r.requestStatus&&!function(e){let t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+36e5}(r)))return i;if(1===s.requestStatus)return n=eh(e,t),i;{if(!navigator.onLine)throw L.create("app-offline");let o=function(e){let t={requestStatus:1,requestTime:Date.now()};return Object.assign(Object.assign({},e),{authToken:t})}(i);return n=ec(e,o),o}}),r=n?await n:i.authToken;return r}async function eh(e,t){let n=await eu(e.appConfig);for(;1===n.authToken.requestStatus;)await z(100),n=await eu(e.appConfig);let i=n.authToken;return 0===i.requestStatus?el(e,t):i}function eu(e){return et(e,e=>{var t;if(!ed(e))throw L.create("not-registered");let n=e.authToken;return(t=n,1===t.requestStatus&&t.requestTime+1e4<Date.now())?Object.assign(Object.assign({},e),{authToken:{requestStatus:0}}):e})}async function ec(e,t){try{let n=await ea(e,t),i=Object.assign(Object.assign({},t),{authToken:n});return await Z(e.appConfig,i),n}catch(s){if(M(s)&&(401===s.customData.serverCode||404===s.customData.serverCode))await ee(e.appConfig);else{let r=Object.assign(Object.assign({},t),{authToken:{requestStatus:0}});await Z(e.appConfig,r)}throw s}}function ed(e){return void 0!==e&&2===e.registrationStatus}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function ef(e){let{installationEntry:t,registrationPromise:n}=await en(e);return n?n.catch(console.error):el(e).catch(console.error),t.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function ep(e,t=!1){await eg(e);let n=await el(e,t);return n.token}async function eg(e){let{registrationPromise:t}=await en(e);t&&await t}function em(e){return L.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let e_="installations",ey=e=>{let t=e.getProvider("app").getImmediate(),n=/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){if(!e||!e.options)throw em("App Configuration");if(!e.name)throw em("App Name");for(let t of["projectId","apiKey","appId"])if(!e.options[t])throw em(t);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}(t),i=(0,d.qX)(t,"heartbeat");return{app:t,appConfig:n,heartbeatServiceProvider:i,_delete:()=>Promise.resolve()}},ev=e=>{let t=e.getProvider("app").getImmediate(),n=(0,d.qX)(t,e_).getImmediate();return{getId:()=>ef(n),getToken:e=>ep(n,e)}};(0,d.Xd)(new g.wA(e_,ey,"PUBLIC")),(0,d.Xd)(new g.wA("installations-internal",ev,"PRIVATE")),(0,d.KN)(D,P),(0,d.KN)(D,P,"esm2017");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ew="analytics",eb="https://www.googletagmanager.com/gtag/js",eT=new f.Yd("@firebase/analytics"),eI=new p.LL("analytics","Analytics",{"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-intialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":"Firebase Analytics Interop Component failed to instantiate: {$reason}","invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":"Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}","no-api-key":'The "apiKey" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.',"no-app-id":'The "appId" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.',"no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":"Trusted Types detected an invalid gtag resource: {$gtagURL}."});/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function eE(e){if(!e.startsWith(eb)){let t=eI.create("invalid-gtag-resource",{gtagURL:e});return eT.warn(t.message),""}return e}function eC(e){return Promise.all(e.map(e=>e.catch(e=>e)))}async function eS(e,t,n,i,r,s){let o=i[r];try{if(o)await t[o];else{let a=await eC(n),l=a.find(e=>e.measurementId===r);l&&await t[l.appId]}}catch(h){eT.error(h)}e("config",r,s)}async function ek(e,t,n,i,r){try{let s=[];if(r&&r.send_to){let o=r.send_to;Array.isArray(o)||(o=[o]);let a=await eC(n);for(let l of o){let h=a.find(e=>e.measurementId===l),u=h&&t[h.appId];if(u)s.push(u);else{s=[];break}}}0===s.length&&(s=Object.values(t)),await Promise.all(s),e("event",i,r||{})}catch(c){eT.error(c)}}let eN=new class{constructor(e={},t=1e3){this.throttleMetadata=e,this.intervalMillis=t}getThrottleMetadata(e){return this.throttleMetadata[e]}setThrottleMetadata(e,t){this.throttleMetadata[e]=t}deleteThrottleMetadata(e){delete this.throttleMetadata[e]}};async function eR(e){var t,n;let{appId:i,apiKey:r}=e,s={method:"GET",headers:new Headers({Accept:"application/json","x-goog-api-key":r})},o="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig".replace("{app-id}",i),a=await fetch(o,s);if(200!==a.status&&304!==a.status){let l="";try{let h=await a.json();(null===(t=h.error)||void 0===t?void 0:t.message)&&(l=h.error.message)}catch(u){}throw eI.create("config-fetch-failed",{httpStatus:a.status,responseMessage:l})}return a.json()}async function eA(e,t=eN,n){let{appId:i,apiKey:r,measurementId:s}=e.options;if(!i)throw eI.create("no-app-id");if(!r){if(s)return{measurementId:s,appId:i};throw eI.create("no-api-key")}let o=t.getThrottleMetadata(i)||{backoffCount:0,throttleEndTimeMillis:Date.now()},a=new eP;return setTimeout(async()=>{a.abort()},void 0!==n?n:6e4),eD({appId:i,apiKey:r,measurementId:s},o,a,t)}async function eD(e,{throttleEndTimeMillis:t,backoffCount:n},i,r=eN){var s,o,a;let{appId:l,measurementId:h}=e;try{await (o=i,a=t,new Promise((e,t)=>{let n=Math.max(a-Date.now(),0),i=setTimeout(e,n);o.addEventListener(()=>{clearTimeout(i),t(eI.create("fetch-throttle",{throttleEndTimeMillis:a}))})}))}catch(u){if(h)return eT.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${h} provided in the "measurementId" field in the local Firebase config. [${null==u?void 0:u.message}]`),{appId:l,measurementId:h};throw u}try{let c=await eR(e);return r.deleteThrottleMetadata(l),c}catch(g){if(!function(e){if(!(e instanceof p.ZR)||!e.customData)return!1;let t=Number(e.customData.httpStatus);return 429===t||500===t||503===t||504===t}(g)){if(r.deleteThrottleMetadata(l),h)return eT.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${h} provided in the "measurementId" field in the local Firebase config. [${null==g?void 0:g.message}]`),{appId:l,measurementId:h};throw g}let d=503===Number(null===(s=null==g?void 0:g.customData)||void 0===s?void 0:s.httpStatus)?(0,p.$s)(n,r.intervalMillis,30):(0,p.$s)(n,r.intervalMillis),f={throttleEndTimeMillis:Date.now()+d,backoffCount:n+1};return r.setThrottleMetadata(l,f),eT.debug(`Calling attemptFetch again in ${d} millis`),eD(e,f,i,r)}}class eP{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let eO;async function ex(e,t,n,i,r){if(r&&r.global){e("event",n,i);return}{let s=await t,o=Object.assign(Object.assign({},i),{send_to:s});e("event",n,o)}}let eL;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function eM(){if(!(0,p.hl)())return eT.warn(eI.create("indexeddb-unavailable",{errorInfo:"IndexedDB is not available in this environment."}).message),!1;try{await (0,p.eu)()}catch(e){return eT.warn(eI.create("indexeddb-unavailable",{errorInfo:null==e?void 0:e.toString()}).message),!1}return!0}async function eF(e,t,n,i,r,s,o){var a,l,h;let u=eA(e);u.then(t=>{n[t.measurementId]=t.appId,e.options.measurementId&&t.measurementId!==e.options.measurementId&&eT.warn(`The measurement ID in the local Firebase config (${e.options.measurementId}) does not match the measurement ID fetched from the server (${t.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(e=>eT.error(e)),t.push(u);let c=eM().then(e=>e?i.getId():void 0),[d,f]=await Promise.all([u,c]);!function(e){let t=window.document.getElementsByTagName("script");for(let n of Object.values(t))if(n.src&&n.src.includes(eb)&&n.src.includes(e))return n;return null}(s)&&function(e,t){var n,i;let r,s=(window.trustedTypes&&(r=window.trustedTypes.createPolicy("firebase-js-sdk-policy",{createScriptURL:eE})),r),o=document.createElement("script"),a=`${eb}?l=${e}&id=${t}`;o.src=s?null==s?void 0:s.createScriptURL(a):a,o.async=!0,document.head.appendChild(o)}(s,d.measurementId),eL&&(r("consent","default",eL),eL=l=void 0),r("js",new Date);let p=null!==(a=null==o?void 0:o.config)&&void 0!==a?a:{};return p.origin="firebase",p.update=!0,null!=f&&(p.firebase_id=f),r("config",d.measurementId,p),eO&&(r("set",eO),eO=h=void 0),d.measurementId}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eU{constructor(e){this.app=e}_delete(){return delete eV[this.app.options.appId],Promise.resolve()}}let eV={},ej=[],eq={},eB="dataLayer",ez,e$,eW=!1,eH="@firebase/analytics",eK="0.10.0";(0,d.Xd)(new g.wA(ew,(e,{options:t})=>{let n=e.getProvider("app").getImmediate(),i=e.getProvider("installations-internal").getImmediate();return function(e,t,n){!function(){let e=[];if((0,p.ru)()&&e.push("This is a browser extension environment."),(0,p.zI)()||e.push("Cookies are not available."),e.length>0){let t=e.map((e,t)=>`(${t+1}) ${e}`).join(" "),n=eI.create("invalid-analytics-context",{errorInfo:t});eT.warn(n.message)}}();let i=e.options.appId;if(!i)throw eI.create("no-app-id");if(!e.options.apiKey){if(e.options.measurementId)eT.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${e.options.measurementId} provided in the "measurementId" field in the local Firebase config.`);else throw eI.create("no-api-key")}if(null!=eV[i])throw eI.create("already-exists",{id:i});if(!eW){var r,s,o,a,l,h;let u;u=[],Array.isArray(window[eB])?u=window[eB]:window[eB]=u;let c,{wrappedGtag:d,gtagCore:f}=(h="gtag",c=function(...e){window[eB].push(arguments)},window[h]&&"function"==typeof window[h]&&(c=window[h]),window[h]=function(e,t,n,i){async function r(r,...s){try{if("event"===r){let[o,a]=s;await ek(e,t,n,o,a)}else if("config"===r){let[l,h]=s;await eS(e,t,n,i,l,h)}else if("consent"===r){let[u]=s;e("consent","update",u)}else if("get"===r){let[c,d,f]=s;e("get",c,d,f)}else if("set"===r){let[p]=s;e("set",p)}else e(r,...s)}catch(g){eT.error(g)}}return r}(c,eV,ej,eq),{gtagCore:c,wrappedGtag:window[h]});e$=d,ez=f,eW=!0}eV[i]=eF(e,ej,eq,t,ez,eB,n);let g=new eU(e);return g}(n,i,t)},"PUBLIC")),(0,d.Xd)(new g.wA("analytics-internal",function(e){try{let t=e.getProvider(ew).getImmediate();return{logEvent:(e,n,i)=>(function(e,t,n,i){ex(e$,eV[(e=(0,p.m9)(e)).app.options.appId],t,n,i).catch(e=>eT.error(e))})(t,e,n,i)}}catch(n){throw eI.create("interop-component-reg-failed",{reason:n})}},"PRIVATE")),(0,d.KN)(eH,eK),(0,d.KN)(eH,eK,"esm2017");var eG=n(9915),eQ=n(3454);let eY="@firebase/database",eX="1.0.1",eJ="";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eZ{constructor(e){this.domStorage_=e,this.prefix_="firebase:"}set(e,t){null==t?this.domStorage_.removeItem(this.prefixedName_(e)):this.domStorage_.setItem(this.prefixedName_(e),(0,p.Wl)(t))}get(e){let t=this.domStorage_.getItem(this.prefixedName_(e));return null==t?null:(0,p.cI)(t)}remove(e){this.domStorage_.removeItem(this.prefixedName_(e))}prefixedName_(e){return this.prefix_+e}toString(){return this.domStorage_.toString()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class e0{constructor(){this.cache_={},this.isInMemoryStorage=!0}set(e,t){null==t?delete this.cache_[e]:this.cache_[e]=t}get(e){return(0,p.r3)(this.cache_,e)?this.cache_[e]:null}remove(e){delete this.cache_[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let e1=function(e){try{if("undefined"!=typeof window&&void 0!==window[e]){let t=window[e];return t.setItem("firebase:sentinel","cache"),t.removeItem("firebase:sentinel"),new eZ(t)}}catch(n){}return new e0},e2=e1("localStorage"),e4=e1("sessionStorage"),e9=new f.Yd("@firebase/database"),e6,e5=(e6=1,function(){return e6++}),e3=function(e){let t=(0,p.dS)(e),n=new p.gQ;n.update(t);let i=n.digest();return p.US.encodeByteArray(i)},e7=function(...e){let t="";for(let n=0;n<e.length;n++){let i=e[n];Array.isArray(i)||i&&"object"==typeof i&&"number"==typeof i.length?t+=e7.apply(null,i):"object"==typeof i?t+=(0,p.Wl)(i):t+=i,t+=" "}return t},e8=null,te=!0,tt=function(e,t){(0,p.hu)(!t||!0===e||!1===e,"Can't turn on custom loggers persistently."),!0===e?(e9.logLevel=f.in.VERBOSE,e8=e9.log.bind(e9),t&&e4.set("logging_enabled",!0)):"function"==typeof e?e8=e:(e8=null,e4.remove("logging_enabled"))},tn=function(...e){if(!0===te&&(te=!1,null===e8&&!0===e4.get("logging_enabled")&&tt(!0)),e8){let t=e7.apply(null,e);e8(t)}},ti=function(e){return function(...t){tn(e,...t)}},tr=function(...e){let t="FIREBASE INTERNAL ERROR: "+e7(...e);e9.error(t)},ts=function(...e){let t=`FIREBASE FATAL ERROR: ${e7(...e)}`;throw e9.error(t),Error(t)},to=function(...e){let t="FIREBASE WARNING: "+e7(...e);e9.warn(t)},ta=function(){"undefined"!=typeof window&&window.location&&window.location.protocol&&-1!==window.location.protocol.indexOf("https:")&&to("Insecure Firebase access from a secure page. Please use https in calls to new Firebase().")},tl=function(e){return"number"==typeof e&&(e!=e||e===Number.POSITIVE_INFINITY||e===Number.NEGATIVE_INFINITY)},th=function(e){if((0,p.Yr)()||"complete"===document.readyState)e();else{let t=!1,n=function(){if(!document.body){setTimeout(n,Math.floor(10));return}t||(t=!0,e())};document.addEventListener?(document.addEventListener("DOMContentLoaded",n,!1),window.addEventListener("load",n,!1)):document.attachEvent&&(document.attachEvent("onreadystatechange",()=>{"complete"===document.readyState&&n()}),window.attachEvent("onload",n))}},tu="[MIN_NAME]",tc="[MAX_NAME]",td=function(e,t){if(e===t)return 0;if(e===tu||t===tc)return -1;if(t===tu||e===tc)return 1;{let n=tw(e),i=tw(t);return null!==n?null!==i?n-i==0?e.length-t.length:n-i:-1:null!==i?1:e<t?-1:1}},tf=function(e,t){return e===t?0:e<t?-1:1},tp=function(e,t){if(t&&e in t)return t[e];throw Error("Missing required key ("+e+") in object: "+(0,p.Wl)(t))},tg=function(e){if("object"!=typeof e||null===e)return(0,p.Wl)(e);let t=[];for(let n in e)t.push(n);t.sort();let i="{";for(let r=0;r<t.length;r++)0!==r&&(i+=","),i+=(0,p.Wl)(t[r]),i+=":",i+=tg(e[t[r]]);return i+"}"},tm=function(e,t){let n=e.length;if(n<=t)return[e];let i=[];for(let r=0;r<n;r+=t)r+t>n?i.push(e.substring(r,n)):i.push(e.substring(r,r+t));return i};function t_(e,t){for(let n in e)e.hasOwnProperty(n)&&t(n,e[n])}let ty=function(e){(0,p.hu)(!tl(e),"Invalid JSON number");let t,n,i,r,s;0===e?(n=0,i=0,t=1/e==-1/0?1:0):(t=e<0,(e=Math.abs(e))>=22250738585072014e-324?(n=(r=Math.min(Math.floor(Math.log(e)/Math.LN2),1023))+1023,i=Math.round(e*Math.pow(2,52-r)-4503599627370496)):(n=0,i=Math.round(e/5e-324)));let o=[];for(s=52;s;s-=1)o.push(i%2?1:0),i=Math.floor(i/2);for(s=11;s;s-=1)o.push(n%2?1:0),n=Math.floor(n/2);o.push(t?1:0),o.reverse();let a=o.join(""),l="";for(s=0;s<64;s+=8){let h=parseInt(a.substr(s,8),2).toString(16);1===h.length&&(h="0"+h),l+=h}return l.toLowerCase()},tv=RegExp("^-?(0*)\\d{1,10}$"),tw=function(e){if(tv.test(e)){let t=Number(e);if(t>=-2147483648&&t<=2147483647)return t}return null},tb=function(e){try{e()}catch(t){setTimeout(()=>{let e=t.stack||"";throw to("Exception was thrown by user callback.",e),t},Math.floor(0))}},tT=function(){let e="object"==typeof window&&window.navigator&&window.navigator.userAgent||"";return e.search(/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0},tI=function(e,t){let n=setTimeout(e,t);return"number"==typeof n&&"undefined"!=typeof Deno&&Deno.unrefTimer?Deno.unrefTimer(n):"object"==typeof n&&n.unref&&n.unref(),n};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tE{constructor(e,t){this.appName_=e,this.appCheckProvider=t,this.appCheck=null==t?void 0:t.getImmediate({optional:!0}),this.appCheck||null==t||t.get().then(e=>this.appCheck=e)}getToken(e){return this.appCheck?this.appCheck.getToken(e):new Promise((t,n)=>{setTimeout(()=>{this.appCheck?this.getToken(e).then(t,n):t(null)},0)})}addTokenChangeListener(e){var t;null===(t=this.appCheckProvider)||void 0===t||t.get().then(t=>t.addTokenListener(e))}notifyForInvalidToken(){to(`Provided AppCheck credentials for the app named "${this.appName_}" are invalid. This usually indicates your app was not initialized correctly.`)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tC{constructor(e,t,n){this.appName_=e,this.firebaseOptions_=t,this.authProvider_=n,this.auth_=null,this.auth_=n.getImmediate({optional:!0}),this.auth_||n.onInit(e=>this.auth_=e)}getToken(e){return this.auth_?this.auth_.getToken(e).catch(e=>e&&"auth/token-not-initialized"===e.code?(tn("Got auth/token-not-initialized error.  Treating as null token."),null):Promise.reject(e)):new Promise((t,n)=>{setTimeout(()=>{this.auth_?this.getToken(e).then(t,n):t(null)},0)})}addTokenChangeListener(e){this.auth_?this.auth_.addAuthTokenListener(e):this.authProvider_.get().then(t=>t.addAuthTokenListener(e))}removeTokenChangeListener(e){this.authProvider_.get().then(t=>t.removeAuthTokenListener(e))}notifyForInvalidToken(){let e='Provided authentication credentials for the app named "'+this.appName_+'" are invalid. This usually indicates your app was not initialized correctly. ';"credential"in this.firebaseOptions_?e+='Make sure the "credential" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':"serviceAccount"in this.firebaseOptions_?e+='Make sure the "serviceAccount" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':e+='Make sure the "apiKey" and "databaseURL" properties provided to initializeApp() match the values provided for your app at https://console.firebase.google.com/.',to(e)}}class tS{constructor(e){this.accessToken=e}getToken(e){return Promise.resolve({accessToken:this.accessToken})}addTokenChangeListener(e){e(this.accessToken)}removeTokenChangeListener(e){}notifyForInvalidToken(){}}tS.OWNER="owner";let tk=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,tN="websocket",tR="long_polling";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tA{constructor(e,t,n,i,r=!1,s="",o=!1,a=!1){this.secure=t,this.namespace=n,this.webSocketOnly=i,this.nodeAdmin=r,this.persistenceKey=s,this.includeNamespaceInQueryParams=o,this.isUsingEmulator=a,this._host=e.toLowerCase(),this._domain=this._host.substr(this._host.indexOf(".")+1),this.internalHost=e2.get("host:"+e)||this._host}isCacheableHost(){return"s-"===this.internalHost.substr(0,2)}isCustomHost(){return"firebaseio.com"!==this._domain&&"firebaseio-demo.com"!==this._domain}get host(){return this._host}set host(e){e!==this.internalHost&&(this.internalHost=e,this.isCacheableHost()&&e2.set("host:"+this._host,this.internalHost))}toString(){let e=this.toURLString();return this.persistenceKey&&(e+="<"+this.persistenceKey+">"),e}toURLString(){let e=this.secure?"https://":"http://",t=this.includeNamespaceInQueryParams?`?ns=${this.namespace}`:"";return`${e}${this.host}/${t}`}}function tD(e,t,n){var i;(0,p.hu)("string"==typeof t,"typeof type must == string"),(0,p.hu)("object"==typeof n,"typeof params must == object");let r;if(t===tN)r=(e.secure?"wss://":"ws://")+e.internalHost+"/.ws?";else if(t===tR)r=(e.secure?"https://":"http://")+e.internalHost+"/.lp?";else throw Error("Unknown connection type: "+t);(e.host!==e.internalHost||e.isCustomHost()||e.includeNamespaceInQueryParams)&&(n.ns=e.namespace);let s=[];return t_(n,(e,t)=>{s.push(e+"="+t)}),r+s.join("&")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tP{constructor(){this.counters_={}}incrementCounter(e,t=1){(0,p.r3)(this.counters_,e)||(this.counters_[e]=0),this.counters_[e]+=t}get(){return(0,p.p$)(this.counters_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let tO={},tx={};function tL(e){let t=e.toString();return tO[t]||(tO[t]=new tP),tO[t]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tM{constructor(e){this.onMessage_=e,this.pendingResponses=[],this.currentResponseNum=0,this.closeAfterResponse=-1,this.onClose=null}closeAfter(e,t){this.closeAfterResponse=e,this.onClose=t,this.closeAfterResponse<this.currentResponseNum&&(this.onClose(),this.onClose=null)}handleResponse(e,t){for(this.pendingResponses[e]=t;this.pendingResponses[this.currentResponseNum];){let n=this.pendingResponses[this.currentResponseNum];delete this.pendingResponses[this.currentResponseNum];for(let i=0;i<n.length;++i)n[i]&&tb(()=>{this.onMessage_(n[i])});if(this.currentResponseNum===this.closeAfterResponse){this.onClose&&(this.onClose(),this.onClose=null);break}this.currentResponseNum++}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let tF="start";class tU{constructor(e,t,n,i,r,s,o){this.connId=e,this.repoInfo=t,this.applicationId=n,this.appCheckToken=i,this.authToken=r,this.transportSessionId=s,this.lastSessionId=o,this.bytesSent=0,this.bytesReceived=0,this.everConnected_=!1,this.log_=ti(e),this.stats_=tL(t),this.urlFn=e=>(this.appCheckToken&&(e.ac=this.appCheckToken),tD(t,tR,e))}open(e,t){this.curSegmentNum=0,this.onDisconnect_=t,this.myPacketOrderer=new tM(e),this.isClosed_=!1,this.connectTimeoutTimer_=setTimeout(()=>{this.log_("Timed out trying to connect."),this.onClosed_(),this.connectTimeoutTimer_=null},Math.floor(3e4)),th(()=>{if(this.isClosed_)return;this.scriptTagHolder=new tV((...e)=>{let[t,n,i,r,s]=e;if(this.incrementIncomingBytes_(e),this.scriptTagHolder){if(this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null),this.everConnected_=!0,t===tF)this.id=n,this.password=i;else if("close"===t)n?(this.scriptTagHolder.sendNewPolls=!1,this.myPacketOrderer.closeAfter(n,()=>{this.onClosed_()})):this.onClosed_();else throw Error("Unrecognized command received: "+t)}},(...e)=>{let[t,n]=e;this.incrementIncomingBytes_(e),this.myPacketOrderer.handleResponse(t,n)},()=>{this.onClosed_()},this.urlFn);let e={};e[tF]="t",e.ser=Math.floor(1e8*Math.random()),this.scriptTagHolder.uniqueCallbackIdentifier&&(e.cb=this.scriptTagHolder.uniqueCallbackIdentifier),e.v="5",this.transportSessionId&&(e.s=this.transportSessionId),this.lastSessionId&&(e.ls=this.lastSessionId),this.applicationId&&(e.p=this.applicationId),this.appCheckToken&&(e.ac=this.appCheckToken),"undefined"!=typeof location&&location.hostname&&tk.test(location.hostname)&&(e.r="f");let t=this.urlFn(e);this.log_("Connecting via long-poll to "+t),this.scriptTagHolder.addTag(t,()=>{})})}start(){this.scriptTagHolder.startLongPoll(this.id,this.password),this.addDisconnectPingFrame(this.id,this.password)}static forceAllow(){tU.forceAllow_=!0}static forceDisallow(){tU.forceDisallow_=!0}static isAvailable(){return!(0,p.Yr)()&&(!!tU.forceAllow_||!tU.forceDisallow_&&"undefined"!=typeof document&&null!=document.createElement&&!("object"==typeof window&&window.chrome&&window.chrome.extension&&!/^chrome/.test(window.location.href))&&!("object"==typeof Windows&&"object"==typeof Windows.UI))}markConnectionHealthy(){}shutdown_(){this.isClosed_=!0,this.scriptTagHolder&&(this.scriptTagHolder.close(),this.scriptTagHolder=null),this.myDisconnFrame&&(document.body.removeChild(this.myDisconnFrame),this.myDisconnFrame=null),this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null)}onClosed_(){!this.isClosed_&&(this.log_("Longpoll is closing itself"),this.shutdown_(),this.onDisconnect_&&(this.onDisconnect_(this.everConnected_),this.onDisconnect_=null))}close(){this.isClosed_||(this.log_("Longpoll is being closed."),this.shutdown_())}send(e){let t=(0,p.Wl)(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);let n=(0,p.h$)(t),i=tm(n,1840);for(let r=0;r<i.length;r++)this.scriptTagHolder.enqueueSegment(this.curSegmentNum,i.length,i[r]),this.curSegmentNum++}addDisconnectPingFrame(e,t){if((0,p.Yr)())return;this.myDisconnFrame=document.createElement("iframe");let n={};n.dframe="t",n.id=e,n.pw=t,this.myDisconnFrame.src=this.urlFn(n),this.myDisconnFrame.style.display="none",document.body.appendChild(this.myDisconnFrame)}incrementIncomingBytes_(e){let t=(0,p.Wl)(e).length;this.bytesReceived+=t,this.stats_.incrementCounter("bytes_received",t)}}class tV{constructor(e,t,n,i){if(this.onDisconnect=n,this.urlFn=i,this.outstandingRequests=new Set,this.pendingSegs=[],this.currentSerial=Math.floor(1e8*Math.random()),this.sendNewPolls=!0,(0,p.Yr)())this.commandCB=e,this.onMessageCB=t;else{this.uniqueCallbackIdentifier=e5(),window["pLPCommand"+this.uniqueCallbackIdentifier]=e,window["pRTLPCB"+this.uniqueCallbackIdentifier]=t,this.myIFrame=tV.createIFrame_();let r="";if(this.myIFrame.src&&"javascript:"===this.myIFrame.src.substr(0,11)){let s=document.domain;r='<script>document.domain="'+s+'";</script>'}let o="<html><body>"+r+"</body></html>";try{this.myIFrame.doc.open(),this.myIFrame.doc.write(o),this.myIFrame.doc.close()}catch(a){tn("frame writing exception"),a.stack&&tn(a.stack),tn(a)}}}static createIFrame_(){let e=document.createElement("iframe");if(e.style.display="none",document.body){document.body.appendChild(e);try{let t=e.contentWindow.document;t||tn("No IE domain setting required")}catch(i){let n=document.domain;e.src="javascript:void((function(){document.open();document.domain='"+n+"';document.close();})())"}}else throw"Document body has not initialized. Wait to initialize Firebase until after the document is ready.";return e.contentDocument?e.doc=e.contentDocument:e.contentWindow?e.doc=e.contentWindow.document:e.document&&(e.doc=e.document),e}close(){this.alive=!1,this.myIFrame&&(this.myIFrame.doc.body.textContent="",setTimeout(()=>{null!==this.myIFrame&&(document.body.removeChild(this.myIFrame),this.myIFrame=null)},Math.floor(0)));let e=this.onDisconnect;e&&(this.onDisconnect=null,e())}startLongPoll(e,t){for(this.myID=e,this.myPW=t,this.alive=!0;this.newRequest_(););}newRequest_(){if(!this.alive||!this.sendNewPolls||!(this.outstandingRequests.size<(this.pendingSegs.length>0?2:1)))return!1;{this.currentSerial++;let e={};e.id=this.myID,e.pw=this.myPW,e.ser=this.currentSerial;let t=this.urlFn(e),n="",i=0;for(;this.pendingSegs.length>0;){let r=this.pendingSegs[0];if(r.d.length+30+n.length<=1870){let s=this.pendingSegs.shift();n=n+"&seg"+i+"="+s.seg+"&ts"+i+"="+s.ts+"&d"+i+"="+s.d,i++}else break}return t+=n,this.addLongPollTag_(t,this.currentSerial),!0}}enqueueSegment(e,t,n){this.pendingSegs.push({seg:e,ts:t,d:n}),this.alive&&this.newRequest_()}addLongPollTag_(e,t){this.outstandingRequests.add(t);let n=()=>{this.outstandingRequests.delete(t),this.newRequest_()},i=setTimeout(n,Math.floor(25e3)),r=()=>{clearTimeout(i),n()};this.addTag(e,r)}addTag(e,t){(0,p.Yr)()?this.doNodeLongPoll(e,t):setTimeout(()=>{try{if(!this.sendNewPolls)return;let n=this.myIFrame.doc.createElement("script");n.type="text/javascript",n.async=!0,n.src=e,n.onload=n.onreadystatechange=function(){let e=n.readyState;e&&"loaded"!==e&&"complete"!==e||(n.onload=n.onreadystatechange=null,n.parentNode&&n.parentNode.removeChild(n),t())},n.onerror=()=>{tn("Long-poll script failed to load: "+e),this.sendNewPolls=!1,this.close()},this.myIFrame.doc.body.appendChild(n)}catch(i){}},Math.floor(1))}}let tj=null;"undefined"!=typeof MozWebSocket?tj=MozWebSocket:"undefined"!=typeof WebSocket&&(tj=WebSocket);class tq{constructor(e,t,n,i,r,s,o){this.connId=e,this.applicationId=n,this.appCheckToken=i,this.authToken=r,this.keepaliveTimer=null,this.frames=null,this.totalFrames=0,this.bytesSent=0,this.bytesReceived=0,this.log_=ti(this.connId),this.stats_=tL(t),this.connURL=tq.connectionURL_(t,s,o,i,n),this.nodeAdmin=t.nodeAdmin}static connectionURL_(e,t,n,i,r){let s={};return s.v="5",!(0,p.Yr)()&&"undefined"!=typeof location&&location.hostname&&tk.test(location.hostname)&&(s.r="f"),t&&(s.s=t),n&&(s.ls=n),i&&(s.ac=i),r&&(s.p=r),tD(e,tN,s)}open(e,t){this.onDisconnect=t,this.onMessage=e,this.log_("Websocket connecting to "+this.connURL),this.everConnected_=!1,e2.set("previous_websocket_failure",!0);try{let n;if((0,p.Yr)()){let i=this.nodeAdmin?"AdminNode":"Node";n={headers:{"User-Agent":`Firebase/5/${eJ}/${eQ.platform}/${i}`,"X-Firebase-GMPID":this.applicationId||""}},this.authToken&&(n.headers.Authorization=`Bearer ${this.authToken}`),this.appCheckToken&&(n.headers["X-Firebase-AppCheck"]=this.appCheckToken);let r=eQ.env,s=0===this.connURL.indexOf("wss://")?r.HTTPS_PROXY||r.https_proxy:r.HTTP_PROXY||r.http_proxy;s&&(n.proxy={origin:s})}this.mySock=new tj(this.connURL,[],n)}catch(a){this.log_("Error instantiating WebSocket.");let o=a.message||a.data;o&&this.log_(o),this.onClosed_();return}this.mySock.onopen=()=>{this.log_("Websocket connected."),this.everConnected_=!0},this.mySock.onclose=()=>{this.log_("Websocket connection was disconnected."),this.mySock=null,this.onClosed_()},this.mySock.onmessage=e=>{this.handleIncomingFrame(e)},this.mySock.onerror=e=>{this.log_("WebSocket error.  Closing connection.");let t=e.message||e.data;t&&this.log_(t),this.onClosed_()}}start(){}static forceDisallow(){tq.forceDisallow_=!0}static isAvailable(){let e=!1;if("undefined"!=typeof navigator&&navigator.userAgent){let t=navigator.userAgent.match(/Android ([0-9]{0,}\.[0-9]{0,})/);t&&t.length>1&&4.4>parseFloat(t[1])&&(e=!0)}return!e&&null!==tj&&!tq.forceDisallow_}static previouslyFailed(){return e2.isInMemoryStorage||!0===e2.get("previous_websocket_failure")}markConnectionHealthy(){e2.remove("previous_websocket_failure")}appendFrame_(e){if(this.frames.push(e),this.frames.length===this.totalFrames){let t=this.frames.join("");this.frames=null;let n=(0,p.cI)(t);this.onMessage(n)}}handleNewFrameCount_(e){this.totalFrames=e,this.frames=[]}extractFrameCount_(e){if((0,p.hu)(null===this.frames,"We already have a frame buffer"),e.length<=6){let t=Number(e);if(!isNaN(t))return this.handleNewFrameCount_(t),null}return this.handleNewFrameCount_(1),e}handleIncomingFrame(e){if(null===this.mySock)return;let t=e.data;if(this.bytesReceived+=t.length,this.stats_.incrementCounter("bytes_received",t.length),this.resetKeepAlive(),null!==this.frames)this.appendFrame_(t);else{let n=this.extractFrameCount_(t);null!==n&&this.appendFrame_(n)}}send(e){this.resetKeepAlive();let t=(0,p.Wl)(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);let n=tm(t,16384);n.length>1&&this.sendString_(String(n.length));for(let i=0;i<n.length;i++)this.sendString_(n[i])}shutdown_(){this.isClosed_=!0,this.keepaliveTimer&&(clearInterval(this.keepaliveTimer),this.keepaliveTimer=null),this.mySock&&(this.mySock.close(),this.mySock=null)}onClosed_(){!this.isClosed_&&(this.log_("WebSocket is closing itself"),this.shutdown_(),this.onDisconnect&&(this.onDisconnect(this.everConnected_),this.onDisconnect=null))}close(){this.isClosed_||(this.log_("WebSocket is being closed"),this.shutdown_())}resetKeepAlive(){clearInterval(this.keepaliveTimer),this.keepaliveTimer=setInterval(()=>{this.mySock&&this.sendString_("0"),this.resetKeepAlive()},Math.floor(45e3))}sendString_(e){try{this.mySock.send(e)}catch(t){this.log_("Exception thrown from WebSocket.send():",t.message||t.data,"Closing connection."),setTimeout(this.onClosed_.bind(this),0)}}}tq.responsesRequiredToBeHealthy=2,tq.healthyTimeout=3e4;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tB{constructor(e){this.initTransports_(e)}static get ALL_TRANSPORTS(){return[tU,tq]}static get IS_TRANSPORT_INITIALIZED(){return this.globalTransportInitialized_}initTransports_(e){let t=tq&&tq.isAvailable(),n=t&&!tq.previouslyFailed();if(e.webSocketOnly&&(t||to("wss:// URL used, but browser isn't known to support websockets.  Trying anyway."),n=!0),n)this.transports_=[tq];else{let i=this.transports_=[];for(let r of tB.ALL_TRANSPORTS)r&&r.isAvailable()&&i.push(r);tB.globalTransportInitialized_=!0}}initialTransport(){if(this.transports_.length>0)return this.transports_[0];throw Error("No transports available")}upgradeTransport(){return this.transports_.length>1?this.transports_[1]:null}}tB.globalTransportInitialized_=!1;class tz{constructor(e,t,n,i,r,s,o,a,l,h){this.id=e,this.repoInfo_=t,this.applicationId_=n,this.appCheckToken_=i,this.authToken_=r,this.onMessage_=s,this.onReady_=o,this.onDisconnect_=a,this.onKill_=l,this.lastSessionId=h,this.connectionCount=0,this.pendingDataMessages=[],this.state_=0,this.log_=ti("c:"+this.id+":"),this.transportManager_=new tB(t),this.log_("Connection created"),this.start_()}start_(){let e=this.transportManager_.initialTransport();this.conn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,null,this.lastSessionId),this.primaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;let t=this.connReceiver_(this.conn_),n=this.disconnReceiver_(this.conn_);this.tx_=this.conn_,this.rx_=this.conn_,this.secondaryConn_=null,this.isHealthy_=!1,setTimeout(()=>{this.conn_&&this.conn_.open(t,n)},Math.floor(0));let i=e.healthyTimeout||0;i>0&&(this.healthyTimeout_=tI(()=>{this.healthyTimeout_=null,this.isHealthy_||(this.conn_&&this.conn_.bytesReceived>102400?(this.log_("Connection exceeded healthy timeout but has received "+this.conn_.bytesReceived+" bytes.  Marking connection healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()):this.conn_&&this.conn_.bytesSent>10240?this.log_("Connection exceeded healthy timeout but has sent "+this.conn_.bytesSent+" bytes.  Leaving connection alive."):(this.log_("Closing unhealthy connection after timeout."),this.close()))},Math.floor(i)))}nextTransportId_(){return"c:"+this.id+":"+this.connectionCount++}disconnReceiver_(e){return t=>{e===this.conn_?this.onConnectionLost_(t):e===this.secondaryConn_?(this.log_("Secondary connection lost."),this.onSecondaryConnectionLost_()):this.log_("closing an old connection")}}connReceiver_(e){return t=>{2!==this.state_&&(e===this.rx_?this.onPrimaryMessageReceived_(t):e===this.secondaryConn_?this.onSecondaryMessageReceived_(t):this.log_("message on old connection"))}}sendRequest(e){this.sendData_({t:"d",d:e})}tryCleanupConnection(){this.tx_===this.secondaryConn_&&this.rx_===this.secondaryConn_&&(this.log_("cleaning up and promoting a connection: "+this.secondaryConn_.connId),this.conn_=this.secondaryConn_,this.secondaryConn_=null)}onSecondaryControl_(e){if("t"in e){let t=e.t;"a"===t?this.upgradeIfSecondaryHealthy_():"r"===t?(this.log_("Got a reset on secondary, closing it"),this.secondaryConn_.close(),(this.tx_===this.secondaryConn_||this.rx_===this.secondaryConn_)&&this.close()):"o"===t&&(this.log_("got pong on secondary."),this.secondaryResponsesRequired_--,this.upgradeIfSecondaryHealthy_())}}onSecondaryMessageReceived_(e){let t=tp("t",e),n=tp("d",e);if("c"===t)this.onSecondaryControl_(n);else if("d"===t)this.pendingDataMessages.push(n);else throw Error("Unknown protocol layer: "+t)}upgradeIfSecondaryHealthy_(){this.secondaryResponsesRequired_<=0?(this.log_("Secondary connection is healthy."),this.isHealthy_=!0,this.secondaryConn_.markConnectionHealthy(),this.proceedWithUpgrade_()):(this.log_("sending ping on secondary."),this.secondaryConn_.send({t:"c",d:{t:"p",d:{}}}))}proceedWithUpgrade_(){this.secondaryConn_.start(),this.log_("sending client ack on secondary"),this.secondaryConn_.send({t:"c",d:{t:"a",d:{}}}),this.log_("Ending transmission on primary"),this.conn_.send({t:"c",d:{t:"n",d:{}}}),this.tx_=this.secondaryConn_,this.tryCleanupConnection()}onPrimaryMessageReceived_(e){let t=tp("t",e),n=tp("d",e);"c"===t?this.onControl_(n):"d"===t&&this.onDataMessage_(n)}onDataMessage_(e){this.onPrimaryResponse_(),this.onMessage_(e)}onPrimaryResponse_(){!this.isHealthy_&&(this.primaryResponsesRequired_--,this.primaryResponsesRequired_<=0&&(this.log_("Primary connection is healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()))}onControl_(e){let t=tp("t",e);if("d"in e){let n=e.d;if("h"===t){let i=Object.assign({},n);this.repoInfo_.isUsingEmulator&&(i.h=this.repoInfo_.host),this.onHandshake_(i)}else if("n"===t){this.log_("recvd end transmission on primary"),this.rx_=this.secondaryConn_;for(let r=0;r<this.pendingDataMessages.length;++r)this.onDataMessage_(this.pendingDataMessages[r]);this.pendingDataMessages=[],this.tryCleanupConnection()}else"s"===t?this.onConnectionShutdown_(n):"r"===t?this.onReset_(n):"e"===t?tr("Server Error: "+n):"o"===t?(this.log_("got pong on primary."),this.onPrimaryResponse_(),this.sendPingOnPrimaryIfNecessary_()):tr("Unknown control packet command: "+t)}}onHandshake_(e){let t=e.ts,n=e.v,i=e.h;this.sessionId=e.s,this.repoInfo_.host=i,0===this.state_&&(this.conn_.start(),this.onConnectionEstablished_(this.conn_,t),"5"!==n&&to("Protocol version mismatch detected"),this.tryStartUpgrade_())}tryStartUpgrade_(){let e=this.transportManager_.upgradeTransport();e&&this.startUpgrade_(e)}startUpgrade_(e){this.secondaryConn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,this.sessionId),this.secondaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;let t=this.connReceiver_(this.secondaryConn_),n=this.disconnReceiver_(this.secondaryConn_);this.secondaryConn_.open(t,n),tI(()=>{this.secondaryConn_&&(this.log_("Timed out trying to upgrade."),this.secondaryConn_.close())},Math.floor(6e4))}onReset_(e){this.log_("Reset packet received.  New host: "+e),this.repoInfo_.host=e,1===this.state_?this.close():(this.closeConnections_(),this.start_())}onConnectionEstablished_(e,t){this.log_("Realtime connection established."),this.conn_=e,this.state_=1,this.onReady_&&(this.onReady_(t,this.sessionId),this.onReady_=null),0===this.primaryResponsesRequired_?(this.log_("Primary connection is healthy."),this.isHealthy_=!0):tI(()=>{this.sendPingOnPrimaryIfNecessary_()},Math.floor(5e3))}sendPingOnPrimaryIfNecessary_(){this.isHealthy_||1!==this.state_||(this.log_("sending ping on primary."),this.sendData_({t:"c",d:{t:"p",d:{}}}))}onSecondaryConnectionLost_(){let e=this.secondaryConn_;this.secondaryConn_=null,(this.tx_===e||this.rx_===e)&&this.close()}onConnectionLost_(e){this.conn_=null,e||0!==this.state_?1===this.state_&&this.log_("Realtime connection lost."):(this.log_("Realtime connection failed."),this.repoInfo_.isCacheableHost()&&(e2.remove("host:"+this.repoInfo_.host),this.repoInfo_.internalHost=this.repoInfo_.host)),this.close()}onConnectionShutdown_(e){this.log_("Connection shutdown command received. Shutting down..."),this.onKill_&&(this.onKill_(e),this.onKill_=null),this.onDisconnect_=null,this.close()}sendData_(e){if(1!==this.state_)throw"Connection is not connected";this.tx_.send(e)}close(){2!==this.state_&&(this.log_("Closing realtime connection."),this.state_=2,this.closeConnections_(),this.onDisconnect_&&(this.onDisconnect_(),this.onDisconnect_=null))}closeConnections_(){this.log_("Shutting down all connections"),this.conn_&&(this.conn_.close(),this.conn_=null),this.secondaryConn_&&(this.secondaryConn_.close(),this.secondaryConn_=null),this.healthyTimeout_&&(clearTimeout(this.healthyTimeout_),this.healthyTimeout_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class t${put(e,t,n,i){}merge(e,t,n,i){}refreshAuthToken(e){}refreshAppCheckToken(e){}onDisconnectPut(e,t,n){}onDisconnectMerge(e,t,n){}onDisconnectCancel(e,t){}reportStats(e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tW{constructor(e){this.allowedEvents_=e,this.listeners_={},(0,p.hu)(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){let n=[...this.listeners_[e]];for(let i=0;i<n.length;i++)n[i].callback.apply(n[i].context,t)}}on(e,t,n){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:n});let i=this.getInitialEvent(e);i&&t.apply(n,i)}off(e,t,n){this.validateEventType_(e);let i=this.listeners_[e]||[];for(let r=0;r<i.length;r++)if(i[r].callback===t&&(!n||n===i[r].context)){i.splice(r,1);return}}validateEventType_(e){(0,p.hu)(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tH extends tW{constructor(){super(["online"]),this.online_=!0,"undefined"==typeof window||void 0===window.addEventListener||(0,p.uI)()||(window.addEventListener("online",()=>{this.online_||(this.online_=!0,this.trigger("online",!0))},!1),window.addEventListener("offline",()=>{this.online_&&(this.online_=!1,this.trigger("online",!1))},!1))}static getInstance(){return new tH}getInitialEvent(e){return(0,p.hu)("online"===e,"Unknown event type: "+e),[this.online_]}currentlyOnline(){return this.online_}}class tK{constructor(e,t){if(void 0===t){this.pieces_=e.split("/");let n=0;for(let i=0;i<this.pieces_.length;i++)this.pieces_[i].length>0&&(this.pieces_[n]=this.pieces_[i],n++);this.pieces_.length=n,this.pieceNum_=0}else this.pieces_=e,this.pieceNum_=t}toString(){let e="";for(let t=this.pieceNum_;t<this.pieces_.length;t++)""!==this.pieces_[t]&&(e+="/"+this.pieces_[t]);return e||"/"}}function tG(){return new tK("")}function tQ(e){return e.pieceNum_>=e.pieces_.length?null:e.pieces_[e.pieceNum_]}function tY(e){return e.pieces_.length-e.pieceNum_}function tX(e){let t=e.pieceNum_;return t<e.pieces_.length&&t++,new tK(e.pieces_,t)}function tJ(e){return e.pieceNum_<e.pieces_.length?e.pieces_[e.pieces_.length-1]:null}function tZ(e,t=0){return e.pieces_.slice(e.pieceNum_+t)}function t0(e){if(e.pieceNum_>=e.pieces_.length)return null;let t=[];for(let n=e.pieceNum_;n<e.pieces_.length-1;n++)t.push(e.pieces_[n]);return new tK(t,0)}function t1(e,t){let n=[];for(let i=e.pieceNum_;i<e.pieces_.length;i++)n.push(e.pieces_[i]);if(t instanceof tK)for(let r=t.pieceNum_;r<t.pieces_.length;r++)n.push(t.pieces_[r]);else{let s=t.split("/");for(let o=0;o<s.length;o++)s[o].length>0&&n.push(s[o])}return new tK(n,0)}function t2(e){return e.pieceNum_>=e.pieces_.length}function t4(e,t){let n=tQ(e),i=tQ(t);if(null===n)return t;if(n===i)return t4(tX(e),tX(t));throw Error("INTERNAL ERROR: innerPath ("+t+") is not within outerPath ("+e+")")}function t9(e,t){if(tY(e)!==tY(t))return!1;for(let n=e.pieceNum_,i=t.pieceNum_;n<=e.pieces_.length;n++,i++)if(e.pieces_[n]!==t.pieces_[i])return!1;return!0}function t6(e,t){let n=e.pieceNum_,i=t.pieceNum_;if(tY(e)>tY(t))return!1;for(;n<e.pieces_.length;){if(e.pieces_[n]!==t.pieces_[i])return!1;++n,++i}return!0}class t5{constructor(e,t){this.errorPrefix_=t,this.parts_=tZ(e,0),this.byteLength_=Math.max(1,this.parts_.length);for(let n=0;n<this.parts_.length;n++)this.byteLength_+=(0,p.ug)(this.parts_[n]);t3(this)}}function t3(e){if(e.byteLength_>768)throw Error(e.errorPrefix_+"has a key path longer than 768 bytes ("+e.byteLength_+").");if(e.parts_.length>32)throw Error(e.errorPrefix_+"path specified exceeds the maximum depth that can be written (32) or object contains a cycle "+t7(e))}function t7(e){return 0===e.parts_.length?"":"in property '"+e.parts_.join(".")+"'"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class t8 extends tW{constructor(){super(["visible"]);let e,t;"undefined"!=typeof document&&void 0!==document.addEventListener&&(void 0!==document.hidden?(t="visibilitychange",e="hidden"):void 0!==document.mozHidden?(t="mozvisibilitychange",e="mozHidden"):void 0!==document.msHidden?(t="msvisibilitychange",e="msHidden"):void 0!==document.webkitHidden&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{let t=!document[e];t!==this.visible_&&(this.visible_=t,this.trigger("visible",t))},!1)}static getInstance(){return new t8}getInitialEvent(e){return(0,p.hu)("visible"===e,"Unknown event type: "+e),[this.visible_]}}class ne extends t${constructor(e,t,n,i,r,s,o,a){if(super(),this.repoInfo_=e,this.applicationId_=t,this.onDataUpdate_=n,this.onConnectStatus_=i,this.onServerInfoUpdate_=r,this.authTokenProvider_=s,this.appCheckTokenProvider_=o,this.authOverride_=a,this.id=ne.nextPersistentConnectionId_++,this.log_=ti("p:"+this.id+":"),this.interruptReasons_={},this.listens=new Map,this.outstandingPuts_=[],this.outstandingGets_=[],this.outstandingPutCount_=0,this.outstandingGetCount_=0,this.onDisconnectRequestQueue_=[],this.connected_=!1,this.reconnectDelay_=1e3,this.maxReconnectDelay_=3e5,this.securityDebugCallback_=null,this.lastSessionId=null,this.establishConnectionTimer_=null,this.visible_=!1,this.requestCBHash_={},this.requestNumber_=0,this.realtime_=null,this.authToken_=null,this.appCheckToken_=null,this.forceTokenRefresh_=!1,this.invalidAuthTokenCount_=0,this.invalidAppCheckTokenCount_=0,this.firstConnection_=!0,this.lastConnectionAttemptTime_=null,this.lastConnectionEstablishedTime_=null,a&&!(0,p.Yr)())throw Error("Auth override specified in options, but not supported on non Node.js platforms");t8.getInstance().on("visible",this.onVisible_,this),-1===e.host.indexOf("fblocal")&&tH.getInstance().on("online",this.onOnline_,this)}sendRequest(e,t,n){let i=++this.requestNumber_,r={r:i,a:e,b:t};this.log_((0,p.Wl)(r)),(0,p.hu)(this.connected_,"sendRequest call when we're not connected not allowed."),this.realtime_.sendRequest(r),n&&(this.requestCBHash_[i]=n)}get(e){this.initConnection_();let t=new p.BH,n={p:e._path.toString(),q:e._queryObject};this.outstandingGets_.push({action:"g",request:n,onComplete(e){let n=e.d;"ok"===e.s?t.resolve(n):t.reject(n)}}),this.outstandingGetCount_++;let i=this.outstandingGets_.length-1;return this.connected_&&this.sendGet_(i),t.promise}listen(e,t,n,i){this.initConnection_();let r=e._queryIdentifier,s=e._path.toString();this.log_("Listen called for "+s+" "+r),this.listens.has(s)||this.listens.set(s,new Map),(0,p.hu)(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"listen() called for non-default but complete query"),(0,p.hu)(!this.listens.get(s).has(r),"listen() called twice for same path/queryId.");let o={onComplete:i,hashFn:t,query:e,tag:n};this.listens.get(s).set(r,o),this.connected_&&this.sendListen_(o)}sendGet_(e){let t=this.outstandingGets_[e];this.sendRequest("g",t.request,n=>{delete this.outstandingGets_[e],this.outstandingGetCount_--,0===this.outstandingGetCount_&&(this.outstandingGets_=[]),t.onComplete&&t.onComplete(n)})}sendListen_(e){let t=e.query,n=t._path.toString(),i=t._queryIdentifier;this.log_("Listen on "+n+" for "+i);let r={p:n};e.tag&&(r.q=t._queryObject,r.t=e.tag),r.h=e.hashFn(),this.sendRequest("q",r,r=>{let s=r.d,o=r.s;ne.warnOnListenWarnings_(s,t);let a=this.listens.get(n)&&this.listens.get(n).get(i);a===e&&(this.log_("listen response",r),"ok"!==o&&this.removeListen_(n,i),e.onComplete&&e.onComplete(o,s))})}static warnOnListenWarnings_(e,t){if(e&&"object"==typeof e&&(0,p.r3)(e,"w")){let n=(0,p.DV)(e,"w");if(Array.isArray(n)&&~n.indexOf("no_index")){let i='".indexOn": "'+t._queryParams.getIndex().toString()+'"',r=t._path.toString();to(`Using an unspecified index. Your data will be downloaded and filtered on the client. Consider adding ${i} at ${r} to your security rules for better performance.`)}}}refreshAuthToken(e){this.authToken_=e,this.log_("Auth token refreshed"),this.authToken_?this.tryAuth():this.connected_&&this.sendRequest("unauth",{},()=>{}),this.reduceReconnectDelayIfAdminCredential_(e)}reduceReconnectDelayIfAdminCredential_(e){let t=e&&40===e.length;(t||(0,p.GJ)(e))&&(this.log_("Admin auth credential detected.  Reducing max reconnect time."),this.maxReconnectDelay_=3e4)}refreshAppCheckToken(e){this.appCheckToken_=e,this.log_("App check token refreshed"),this.appCheckToken_?this.tryAppCheck():this.connected_&&this.sendRequest("unappeck",{},()=>{})}tryAuth(){if(this.connected_&&this.authToken_){let e=this.authToken_,t=(0,p.w9)(e)?"auth":"gauth",n={cred:e};null===this.authOverride_?n.noauth=!0:"object"==typeof this.authOverride_&&(n.authvar=this.authOverride_),this.sendRequest(t,n,t=>{let n=t.s,i=t.d||"error";this.authToken_===e&&("ok"===n?this.invalidAuthTokenCount_=0:this.onAuthRevoked_(n,i))})}}tryAppCheck(){this.connected_&&this.appCheckToken_&&this.sendRequest("appcheck",{token:this.appCheckToken_},e=>{let t=e.s,n=e.d||"error";"ok"===t?this.invalidAppCheckTokenCount_=0:this.onAppCheckRevoked_(t,n)})}unlisten(e,t){let n=e._path.toString(),i=e._queryIdentifier;this.log_("Unlisten called for "+n+" "+i),(0,p.hu)(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"unlisten() called for non-default but complete query");let r=this.removeListen_(n,i);r&&this.connected_&&this.sendUnlisten_(n,i,e._queryObject,t)}sendUnlisten_(e,t,n,i){this.log_("Unlisten on "+e+" for "+t);let r={p:e};i&&(r.q=n,r.t=i),this.sendRequest("n",r)}onDisconnectPut(e,t,n){this.initConnection_(),this.connected_?this.sendOnDisconnect_("o",e,t,n):this.onDisconnectRequestQueue_.push({pathString:e,action:"o",data:t,onComplete:n})}onDisconnectMerge(e,t,n){this.initConnection_(),this.connected_?this.sendOnDisconnect_("om",e,t,n):this.onDisconnectRequestQueue_.push({pathString:e,action:"om",data:t,onComplete:n})}onDisconnectCancel(e,t){this.initConnection_(),this.connected_?this.sendOnDisconnect_("oc",e,null,t):this.onDisconnectRequestQueue_.push({pathString:e,action:"oc",data:null,onComplete:t})}sendOnDisconnect_(e,t,n,i){let r={p:t,d:n};this.log_("onDisconnect "+e,r),this.sendRequest(e,r,e=>{i&&setTimeout(()=>{i(e.s,e.d)},Math.floor(0))})}put(e,t,n,i){this.putInternal("p",e,t,n,i)}merge(e,t,n,i){this.putInternal("m",e,t,n,i)}putInternal(e,t,n,i,r){this.initConnection_();let s={p:t,d:n};void 0!==r&&(s.h=r),this.outstandingPuts_.push({action:e,request:s,onComplete:i}),this.outstandingPutCount_++;let o=this.outstandingPuts_.length-1;this.connected_?this.sendPut_(o):this.log_("Buffering put: "+t)}sendPut_(e){let t=this.outstandingPuts_[e].action,n=this.outstandingPuts_[e].request,i=this.outstandingPuts_[e].onComplete;this.outstandingPuts_[e].queued=this.connected_,this.sendRequest(t,n,n=>{this.log_(t+" response",n),delete this.outstandingPuts_[e],this.outstandingPutCount_--,0===this.outstandingPutCount_&&(this.outstandingPuts_=[]),i&&i(n.s,n.d)})}reportStats(e){if(this.connected_){let t={c:e};this.log_("reportStats",t),this.sendRequest("s",t,e=>{let t=e.s;if("ok"!==t){let n=e.d;this.log_("reportStats","Error sending stats: "+n)}})}}onDataMessage_(e){if("r"in e){this.log_("from server: "+(0,p.Wl)(e));let t=e.r,n=this.requestCBHash_[t];n&&(delete this.requestCBHash_[t],n(e.b))}else if("error"in e)throw"A server-side error has occurred: "+e.error;else"a"in e&&this.onDataPush_(e.a,e.b)}onDataPush_(e,t){this.log_("handleServerMessage",e,t),"d"===e?this.onDataUpdate_(t.p,t.d,!1,t.t):"m"===e?this.onDataUpdate_(t.p,t.d,!0,t.t):"c"===e?this.onListenRevoked_(t.p,t.q):"ac"===e?this.onAuthRevoked_(t.s,t.d):"apc"===e?this.onAppCheckRevoked_(t.s,t.d):"sd"===e?this.onSecurityDebugPacket_(t):tr("Unrecognized action received from server: "+(0,p.Wl)(e)+"\nAre you using the latest client?")}onReady_(e,t){this.log_("connection ready"),this.connected_=!0,this.lastConnectionEstablishedTime_=new Date().getTime(),this.handleTimestamp_(e),this.lastSessionId=t,this.firstConnection_&&this.sendConnectStats_(),this.restoreState_(),this.firstConnection_=!1,this.onConnectStatus_(!0)}scheduleConnect_(e){(0,p.hu)(!this.realtime_,"Scheduling a connect when we're already connected/ing?"),this.establishConnectionTimer_&&clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=setTimeout(()=>{this.establishConnectionTimer_=null,this.establishConnection_()},Math.floor(e))}initConnection_(){!this.realtime_&&this.firstConnection_&&this.scheduleConnect_(0)}onVisible_(e){!e||this.visible_||this.reconnectDelay_!==this.maxReconnectDelay_||(this.log_("Window became visible.  Reducing delay."),this.reconnectDelay_=1e3,this.realtime_||this.scheduleConnect_(0)),this.visible_=e}onOnline_(e){e?(this.log_("Browser went online."),this.reconnectDelay_=1e3,this.realtime_||this.scheduleConnect_(0)):(this.log_("Browser went offline.  Killing connection."),this.realtime_&&this.realtime_.close())}onRealtimeDisconnect_(){if(this.log_("data client disconnected"),this.connected_=!1,this.realtime_=null,this.cancelSentTransactions_(),this.requestCBHash_={},this.shouldReconnect_()){if(this.visible_){if(this.lastConnectionEstablishedTime_){let e=new Date().getTime()-this.lastConnectionEstablishedTime_;e>3e4&&(this.reconnectDelay_=1e3),this.lastConnectionEstablishedTime_=null}}else this.log_("Window isn't visible.  Delaying reconnect."),this.reconnectDelay_=this.maxReconnectDelay_,this.lastConnectionAttemptTime_=new Date().getTime();let t=new Date().getTime()-this.lastConnectionAttemptTime_,n=Math.max(0,this.reconnectDelay_-t);n=Math.random()*n,this.log_("Trying to reconnect in "+n+"ms"),this.scheduleConnect_(n),this.reconnectDelay_=Math.min(this.maxReconnectDelay_,1.3*this.reconnectDelay_)}this.onConnectStatus_(!1)}async establishConnection_(){if(this.shouldReconnect_()){this.log_("Making a connection attempt"),this.lastConnectionAttemptTime_=new Date().getTime(),this.lastConnectionEstablishedTime_=null;let e=this.onDataMessage_.bind(this),t=this.onReady_.bind(this),n=this.onRealtimeDisconnect_.bind(this),i=this.id+":"+ne.nextConnectionId_++,r=this.lastSessionId,s=!1,o=null,a=function(){o?o.close():(s=!0,n())},l=function(e){(0,p.hu)(o,"sendRequest call when we're not connected not allowed."),o.sendRequest(e)};this.realtime_={close:a,sendRequest:l};let h=this.forceTokenRefresh_;this.forceTokenRefresh_=!1;try{let[u,c]=await Promise.all([this.authTokenProvider_.getToken(h),this.appCheckTokenProvider_.getToken(h)]);s?tn("getToken() completed but was canceled"):(tn("getToken() completed. Creating connection."),this.authToken_=u&&u.accessToken,this.appCheckToken_=c&&c.token,o=new tz(i,this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,e,t,n,e=>{to(e+" ("+this.repoInfo_.toString()+")"),this.interrupt("server_kill")},r))}catch(d){this.log_("Failed to get token: "+d),s||(this.repoInfo_.nodeAdmin&&to(d),a())}}}interrupt(e){tn("Interrupting connection for reason: "+e),this.interruptReasons_[e]=!0,this.realtime_?this.realtime_.close():(this.establishConnectionTimer_&&(clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=null),this.connected_&&this.onRealtimeDisconnect_())}resume(e){tn("Resuming connection for reason: "+e),delete this.interruptReasons_[e],(0,p.xb)(this.interruptReasons_)&&(this.reconnectDelay_=1e3,this.realtime_||this.scheduleConnect_(0))}handleTimestamp_(e){let t=e-new Date().getTime();this.onServerInfoUpdate_({serverTimeOffset:t})}cancelSentTransactions_(){for(let e=0;e<this.outstandingPuts_.length;e++){let t=this.outstandingPuts_[e];t&&"h"in t.request&&t.queued&&(t.onComplete&&t.onComplete("disconnect"),delete this.outstandingPuts_[e],this.outstandingPutCount_--)}0===this.outstandingPutCount_&&(this.outstandingPuts_=[])}onListenRevoked_(e,t){let n;n=t?t.map(e=>tg(e)).join("$"):"default";let i=this.removeListen_(e,n);i&&i.onComplete&&i.onComplete("permission_denied")}removeListen_(e,t){let n=new tK(e).toString(),i;if(this.listens.has(n)){let r=this.listens.get(n);i=r.get(t),r.delete(t),0===r.size&&this.listens.delete(n)}else i=void 0;return i}onAuthRevoked_(e,t){tn("Auth token revoked: "+e+"/"+t),this.authToken_=null,this.forceTokenRefresh_=!0,this.realtime_.close(),("invalid_token"===e||"permission_denied"===e)&&(this.invalidAuthTokenCount_++,this.invalidAuthTokenCount_>=3&&(this.reconnectDelay_=3e4,this.authTokenProvider_.notifyForInvalidToken()))}onAppCheckRevoked_(e,t){tn("App check token revoked: "+e+"/"+t),this.appCheckToken_=null,this.forceTokenRefresh_=!0,("invalid_token"===e||"permission_denied"===e)&&(this.invalidAppCheckTokenCount_++,this.invalidAppCheckTokenCount_>=3&&this.appCheckTokenProvider_.notifyForInvalidToken())}onSecurityDebugPacket_(e){this.securityDebugCallback_?this.securityDebugCallback_(e):"msg"in e&&console.log("FIREBASE: "+e.msg.replace("\n","\nFIREBASE: "))}restoreState_(){for(let e of(this.tryAuth(),this.tryAppCheck(),this.listens.values()))for(let t of e.values())this.sendListen_(t);for(let n=0;n<this.outstandingPuts_.length;n++)this.outstandingPuts_[n]&&this.sendPut_(n);for(;this.onDisconnectRequestQueue_.length;){let i=this.onDisconnectRequestQueue_.shift();this.sendOnDisconnect_(i.action,i.pathString,i.data,i.onComplete)}for(let r=0;r<this.outstandingGets_.length;r++)this.outstandingGets_[r]&&this.sendGet_(r)}sendConnectStats_(){let e={},t="js";(0,p.Yr)()&&(t=this.repoInfo_.nodeAdmin?"admin_node":"node"),e["sdk."+t+"."+eJ.replace(/\./g,"-")]=1,(0,p.uI)()?e["framework.cordova"]=1:(0,p.b$)()&&(e["framework.reactnative"]=1),this.reportStats(e)}shouldReconnect_(){let e=tH.getInstance().currentlyOnline();return(0,p.xb)(this.interruptReasons_)&&e}}ne.nextPersistentConnectionId_=0,ne.nextConnectionId_=0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nt{constructor(e,t){this.name=e,this.node=t}static Wrap(e,t){return new nt(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nn{getCompare(){return this.compare.bind(this)}indexedValueChanged(e,t){let n=new nt(tu,e),i=new nt(tu,t);return 0!==this.compare(n,i)}minPost(){return nt.MIN}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ni;class nr extends nn{static get __EMPTY_NODE(){return ni}static set __EMPTY_NODE(e){ni=e}compare(e,t){return td(e.name,t.name)}isDefinedOn(e){throw(0,p.g5)("KeyIndex.isDefinedOn not expected to be called.")}indexedValueChanged(e,t){return!1}minPost(){return nt.MIN}maxPost(){return new nt(tc,ni)}makePost(e,t){return(0,p.hu)("string"==typeof e,"KeyIndex indexValue must always be a string."),new nt(e,ni)}toString(){return".key"}}let ns=new nr;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class no{constructor(e,t,n,i,r=null){this.isReverse_=i,this.resultGenerator_=r,this.nodeStack_=[];let s=1;for(;!e.isEmpty();)if(s=t?n(e.key,t):1,i&&(s*=-1),s<0)e=this.isReverse_?e.left:e.right;else if(0===s){this.nodeStack_.push(e);break}else this.nodeStack_.push(e),e=this.isReverse_?e.right:e.left}getNext(){if(0===this.nodeStack_.length)return null;let e=this.nodeStack_.pop(),t;if(t=this.resultGenerator_?this.resultGenerator_(e.key,e.value):{key:e.key,value:e.value},this.isReverse_)for(e=e.left;!e.isEmpty();)this.nodeStack_.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack_.push(e),e=e.left;return t}hasNext(){return this.nodeStack_.length>0}peek(){if(0===this.nodeStack_.length)return null;let e=this.nodeStack_[this.nodeStack_.length-1];return this.resultGenerator_?this.resultGenerator_(e.key,e.value):{key:e.key,value:e.value}}}class na{constructor(e,t,n,i,r){this.key=e,this.value=t,this.color=null!=n?n:na.RED,this.left=null!=i?i:nl.EMPTY_NODE,this.right=null!=r?r:nl.EMPTY_NODE}copy(e,t,n,i,r){return new na(null!=e?e:this.key,null!=t?t:this.value,null!=n?n:this.color,null!=i?i:this.left,null!=r?r:this.right)}count(){return this.left.count()+1+this.right.count()}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||!!e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min_(){return this.left.isEmpty()?this:this.left.min_()}minKey(){return this.min_().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let i=this,r=n(e,i.key);return(i=r<0?i.copy(null,null,null,i.left.insert(e,t,n),null):0===r?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,n))).fixUp_()}removeMin_(){if(this.left.isEmpty())return nl.EMPTY_NODE;let e=this;return e.left.isRed_()||e.left.left.isRed_()||(e=e.moveRedLeft_()),(e=e.copy(null,null,null,e.left.removeMin_(),null)).fixUp_()}remove(e,t){let n,i;if(n=this,0>t(e,n.key))n.left.isEmpty()||n.left.isRed_()||n.left.left.isRed_()||(n=n.moveRedLeft_()),n=n.copy(null,null,null,n.left.remove(e,t),null);else{if(n.left.isRed_()&&(n=n.rotateRight_()),n.right.isEmpty()||n.right.isRed_()||n.right.left.isRed_()||(n=n.moveRedRight_()),0===t(e,n.key)){if(n.right.isEmpty())return nl.EMPTY_NODE;i=n.right.min_(),n=n.copy(i.key,i.value,null,null,n.right.removeMin_())}n=n.copy(null,null,null,null,n.right.remove(e,t))}return n.fixUp_()}isRed_(){return this.color}fixUp_(){let e=this;return e.right.isRed_()&&!e.left.isRed_()&&(e=e.rotateLeft_()),e.left.isRed_()&&e.left.left.isRed_()&&(e=e.rotateRight_()),e.left.isRed_()&&e.right.isRed_()&&(e=e.colorFlip_()),e}moveRedLeft_(){let e=this.colorFlip_();return e.right.left.isRed_()&&(e=(e=(e=e.copy(null,null,null,null,e.right.rotateRight_())).rotateLeft_()).colorFlip_()),e}moveRedRight_(){let e=this.colorFlip_();return e.left.left.isRed_()&&(e=(e=e.rotateRight_()).colorFlip_()),e}rotateLeft_(){let e=this.copy(null,null,na.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight_(){let e=this.copy(null,null,na.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip_(){let e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth_(){let e=this.check_();return Math.pow(2,e)<=this.count()+1}check_(){if(this.isRed_()&&this.left.isRed_())throw Error("Red node has red child("+this.key+","+this.value+")");if(this.right.isRed_())throw Error("Right child of ("+this.key+","+this.value+") is red");let e=this.left.check_();if(e===this.right.check_())return e+(this.isRed_()?0:1);throw Error("Black depths differ")}}na.RED=!0,na.BLACK=!1;class nl{constructor(e,t=nl.EMPTY_NODE){this.comparator_=e,this.root_=t}insert(e,t){return new nl(this.comparator_,this.root_.insert(e,t,this.comparator_).copy(null,null,na.BLACK,null,null))}remove(e){return new nl(this.comparator_,this.root_.remove(e,this.comparator_).copy(null,null,na.BLACK,null,null))}get(e){let t,n=this.root_;for(;!n.isEmpty();){if(0===(t=this.comparator_(e,n.key)))return n.value;t<0?n=n.left:t>0&&(n=n.right)}return null}getPredecessorKey(e){let t,n=this.root_,i=null;for(;!n.isEmpty();){if(0===(t=this.comparator_(e,n.key))){if(n.left.isEmpty()){if(i)return i.key;return null}for(n=n.left;!n.right.isEmpty();)n=n.right;return n.key}t<0?n=n.left:t>0&&(i=n,n=n.right)}throw Error("Attempted to find predecessor key for a nonexistent key.  What gives?")}isEmpty(){return this.root_.isEmpty()}count(){return this.root_.count()}minKey(){return this.root_.minKey()}maxKey(){return this.root_.maxKey()}inorderTraversal(e){return this.root_.inorderTraversal(e)}reverseTraversal(e){return this.root_.reverseTraversal(e)}getIterator(e){return new no(this.root_,null,this.comparator_,!1,e)}getIteratorFrom(e,t){return new no(this.root_,e,this.comparator_,!1,t)}getReverseIteratorFrom(e,t){return new no(this.root_,e,this.comparator_,!0,t)}getReverseIterator(e){return new no(this.root_,null,this.comparator_,!0,e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function nh(e,t){return td(e.name,t.name)}function nu(e,t){return td(e,t)}nl.EMPTY_NODE=new class{copy(e,t,n,i,r){return this}insert(e,t,n){return new na(e,t,null)}remove(e,t){return this}count(){return 0}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}check_(){return 0}isRed_(){return!1}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let nc,nd=function(e){return"number"==typeof e?"number:"+ty(e):"string:"+e},nf=function(e){if(e.isLeafNode()){let t=e.val();(0,p.hu)("string"==typeof t||"number"==typeof t||"object"==typeof t&&(0,p.r3)(t,".sv"),"Priority must be a string or number.")}else(0,p.hu)(e===nc||e.isEmpty(),"priority of unexpected type.");(0,p.hu)(e===nc||e.getPriority().isEmpty(),"Priority nodes can't have a priority of their own.")},np;class ng{constructor(e,t=ng.__childrenNodeConstructor.EMPTY_NODE){this.value_=e,this.priorityNode_=t,this.lazyHash_=null,(0,p.hu)(void 0!==this.value_&&null!==this.value_,"LeafNode shouldn't be created with null/undefined value."),nf(this.priorityNode_)}static set __childrenNodeConstructor(e){np=e}static get __childrenNodeConstructor(){return np}isLeafNode(){return!0}getPriority(){return this.priorityNode_}updatePriority(e){return new ng(this.value_,e)}getImmediateChild(e){return".priority"===e?this.priorityNode_:ng.__childrenNodeConstructor.EMPTY_NODE}getChild(e){return t2(e)?this:".priority"===tQ(e)?this.priorityNode_:ng.__childrenNodeConstructor.EMPTY_NODE}hasChild(){return!1}getPredecessorChildName(e,t){return null}updateImmediateChild(e,t){return".priority"===e?this.updatePriority(t):t.isEmpty()&&".priority"!==e?this:ng.__childrenNodeConstructor.EMPTY_NODE.updateImmediateChild(e,t).updatePriority(this.priorityNode_)}updateChild(e,t){let n=tQ(e);return null===n?t:t.isEmpty()&&".priority"!==n?this:((0,p.hu)(".priority"!==n||1===tY(e),".priority must be the last token in a path"),this.updateImmediateChild(n,ng.__childrenNodeConstructor.EMPTY_NODE.updateChild(tX(e),t)))}isEmpty(){return!1}numChildren(){return 0}forEachChild(e,t){return!1}val(e){return e&&!this.getPriority().isEmpty()?{".value":this.getValue(),".priority":this.getPriority().val()}:this.getValue()}hash(){if(null===this.lazyHash_){let e="";this.priorityNode_.isEmpty()||(e+="priority:"+nd(this.priorityNode_.val())+":");let t=typeof this.value_;e+=t+":","number"===t?e+=ty(this.value_):e+=this.value_,this.lazyHash_=e3(e)}return this.lazyHash_}getValue(){return this.value_}compareTo(e){return e===ng.__childrenNodeConstructor.EMPTY_NODE?1:e instanceof ng.__childrenNodeConstructor?-1:((0,p.hu)(e.isLeafNode(),"Unknown node type"),this.compareToLeafNode_(e))}compareToLeafNode_(e){let t=typeof e.value_,n=typeof this.value_,i=ng.VALUE_TYPE_ORDER.indexOf(t),r=ng.VALUE_TYPE_ORDER.indexOf(n);return((0,p.hu)(i>=0,"Unknown leaf type: "+t),(0,p.hu)(r>=0,"Unknown leaf type: "+n),i!==r)?r-i:"object"===n?0:this.value_<e.value_?-1:this.value_===e.value_?0:1}withIndex(){return this}isIndexed(){return!0}equals(e){return e===this||!!e.isLeafNode()&&this.value_===e.value_&&this.priorityNode_.equals(e.priorityNode_)}}ng.VALUE_TYPE_ORDER=["object","boolean","number","string"];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let nm,n_,ny=new class extends nn{compare(e,t){let n=e.node.getPriority(),i=t.node.getPriority(),r=n.compareTo(i);return 0===r?td(e.name,t.name):r}isDefinedOn(e){return!e.getPriority().isEmpty()}indexedValueChanged(e,t){return!e.getPriority().equals(t.getPriority())}minPost(){return nt.MIN}maxPost(){return new nt(tc,new ng("[PRIORITY-POST]",n_))}makePost(e,t){let n=nm(e);return new nt(t,new ng("[PRIORITY-POST]",n))}toString(){return".priority"}},nv=Math.log(2);class nw{constructor(e){var t;this.count=parseInt(Math.log(e+1)/nv,10),this.current_=this.count-1;let n=parseInt(Array(this.count+1).join("1"),2);this.bits_=e+1&n}nextBitIsOne(){let e=!(this.bits_&1<<this.current_);return this.current_--,e}}let nb=function(e,t,n,i){e.sort(t);let r=function(t,i){let s=i-t,o,a;if(0===s)return null;if(1===s)return o=e[t],a=n?n(o):o,new na(a,o.node,na.BLACK,null,null);{let l=parseInt(s/2,10)+t,h=r(t,l),u=r(l+1,i);return o=e[l],a=n?n(o):o,new na(a,o.node,na.BLACK,h,u)}},s=new nw(e.length),o=function(t){let i=null,s=null,o=e.length,a=function(t,i){let s=o-t;o-=t;let a=r(s+1,o),h=e[s],u=n?n(h):h;l(new na(u,h.node,i,null,a))},l=function(e){i?(i.left=e,i=e):(s=e,i=e)};for(let h=0;h<t.count;++h){let u=t.nextBitIsOne(),c=Math.pow(2,t.count-(h+1));u?a(c,na.BLACK):(a(c,na.BLACK),a(c,na.RED))}return s}(s);return new nl(i||t,o)},nT,nI={};class nE{constructor(e,t){this.indexes_=e,this.indexSet_=t}static get Default(){return(0,p.hu)(nI&&ny,"ChildrenNode.ts has not been loaded"),nT=nT||new nE({".priority":nI},{".priority":ny})}get(e){let t=(0,p.DV)(this.indexes_,e);if(!t)throw Error("No index defined for "+e);return t instanceof nl?t:null}hasIndex(e){return(0,p.r3)(this.indexSet_,e.toString())}addIndex(e,t){(0,p.hu)(e!==ns,"KeyIndex always exists and isn't meant to be added to the IndexMap.");let n=[],i=!1,r=t.getIterator(nt.Wrap),s=r.getNext();for(;s;)i=i||e.isDefinedOn(s.node),n.push(s),s=r.getNext();let o;o=i?nb(n,e.getCompare()):nI;let a=e.toString(),l=Object.assign({},this.indexSet_);l[a]=e;let h=Object.assign({},this.indexes_);return h[a]=o,new nE(h,l)}addToIndexes(e,t){let n=(0,p.UI)(this.indexes_,(n,i)=>{let r=(0,p.DV)(this.indexSet_,i);if((0,p.hu)(r,"Missing index implementation for "+i),n===nI){if(!r.isDefinedOn(e.node))return nI;{let s=[],o=t.getIterator(nt.Wrap),a=o.getNext();for(;a;)a.name!==e.name&&s.push(a),a=o.getNext();return s.push(e),nb(s,r.getCompare())}}{let l=t.get(e.name),h=n;return l&&(h=h.remove(new nt(e.name,l))),h.insert(e,e.node)}});return new nE(n,this.indexSet_)}removeFromIndexes(e,t){let n=(0,p.UI)(this.indexes_,n=>{if(n===nI)return n;{let i=t.get(e.name);return i?n.remove(new nt(e.name,i)):n}});return new nE(n,this.indexSet_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let nC;class nS{constructor(e,t,n){this.children_=e,this.priorityNode_=t,this.indexMap_=n,this.lazyHash_=null,this.priorityNode_&&nf(this.priorityNode_),this.children_.isEmpty()&&(0,p.hu)(!this.priorityNode_||this.priorityNode_.isEmpty(),"An empty node cannot have a priority")}static get EMPTY_NODE(){return nC||(nC=new nS(new nl(nu),null,nE.Default))}isLeafNode(){return!1}getPriority(){return this.priorityNode_||nC}updatePriority(e){return this.children_.isEmpty()?this:new nS(this.children_,e,this.indexMap_)}getImmediateChild(e){if(".priority"===e)return this.getPriority();{let t=this.children_.get(e);return null===t?nC:t}}getChild(e){let t=tQ(e);return null===t?this:this.getImmediateChild(t).getChild(tX(e))}hasChild(e){return null!==this.children_.get(e)}updateImmediateChild(e,t){if((0,p.hu)(t,"We should always be passing snapshot nodes"),".priority"===e)return this.updatePriority(t);{let n=new nt(e,t),i,r;t.isEmpty()?(i=this.children_.remove(e),r=this.indexMap_.removeFromIndexes(n,this.children_)):(i=this.children_.insert(e,t),r=this.indexMap_.addToIndexes(n,this.children_));let s=i.isEmpty()?nC:this.priorityNode_;return new nS(i,s,r)}}updateChild(e,t){let n=tQ(e);if(null===n)return t;{(0,p.hu)(".priority"!==tQ(e)||1===tY(e),".priority must be the last token in a path");let i=this.getImmediateChild(n).updateChild(tX(e),t);return this.updateImmediateChild(n,i)}}isEmpty(){return this.children_.isEmpty()}numChildren(){return this.children_.count()}val(e){if(this.isEmpty())return null;let t={},n=0,i=0,r=!0;if(this.forEachChild(ny,(s,o)=>{t[s]=o.val(e),n++,r&&nS.INTEGER_REGEXP_.test(s)?i=Math.max(i,Number(s)):r=!1}),e||!r||!(i<2*n))return e&&!this.getPriority().isEmpty()&&(t[".priority"]=this.getPriority().val()),t;{let s=[];for(let o in t)s[o]=t[o];return s}}hash(){if(null===this.lazyHash_){let e="";this.getPriority().isEmpty()||(e+="priority:"+nd(this.getPriority().val())+":"),this.forEachChild(ny,(t,n)=>{let i=n.hash();""!==i&&(e+=":"+t+":"+i)}),this.lazyHash_=""===e?"":e3(e)}return this.lazyHash_}getPredecessorChildName(e,t,n){let i=this.resolveIndex_(n);if(!i)return this.children_.getPredecessorKey(e);{let r=i.getPredecessorKey(new nt(e,t));return r?r.name:null}}getFirstChildName(e){let t=this.resolveIndex_(e);if(!t)return this.children_.minKey();{let n=t.minKey();return n&&n.name}}getFirstChild(e){let t=this.getFirstChildName(e);return t?new nt(t,this.children_.get(t)):null}getLastChildName(e){let t=this.resolveIndex_(e);if(!t)return this.children_.maxKey();{let n=t.maxKey();return n&&n.name}}getLastChild(e){let t=this.getLastChildName(e);return t?new nt(t,this.children_.get(t)):null}forEachChild(e,t){let n=this.resolveIndex_(e);return n?n.inorderTraversal(e=>t(e.name,e.node)):this.children_.inorderTraversal(t)}getIterator(e){return this.getIteratorFrom(e.minPost(),e)}getIteratorFrom(e,t){let n=this.resolveIndex_(t);if(n)return n.getIteratorFrom(e,e=>e);{let i=this.children_.getIteratorFrom(e.name,nt.Wrap),r=i.peek();for(;null!=r&&0>t.compare(r,e);)i.getNext(),r=i.peek();return i}}getReverseIterator(e){return this.getReverseIteratorFrom(e.maxPost(),e)}getReverseIteratorFrom(e,t){let n=this.resolveIndex_(t);if(n)return n.getReverseIteratorFrom(e,e=>e);{let i=this.children_.getReverseIteratorFrom(e.name,nt.Wrap),r=i.peek();for(;null!=r&&t.compare(r,e)>0;)i.getNext(),r=i.peek();return i}}compareTo(e){return this.isEmpty()?e.isEmpty()?0:-1:e.isLeafNode()||e.isEmpty()?1:e===nk?-1:0}withIndex(e){if(e===ns||this.indexMap_.hasIndex(e))return this;{let t=this.indexMap_.addIndex(e,this.children_);return new nS(this.children_,this.priorityNode_,t)}}isIndexed(e){return e===ns||this.indexMap_.hasIndex(e)}equals(e){if(e===this)return!0;if(e.isLeafNode()||!this.getPriority().equals(e.getPriority()))return!1;if(this.children_.count()!==e.children_.count())return!1;{let t=this.getIterator(ny),n=e.getIterator(ny),i=t.getNext(),r=n.getNext();for(;i&&r;){if(i.name!==r.name||!i.node.equals(r.node))return!1;i=t.getNext(),r=n.getNext()}return null===i&&null===r}}resolveIndex_(e){return e===ns?null:this.indexMap_.get(e.toString())}}nS.INTEGER_REGEXP_=/^(0|[1-9]\d*)$/;let nk=new class extends nS{constructor(){super(new nl(nu),nS.EMPTY_NODE,nE.Default)}compareTo(e){return e===this?0:1}equals(e){return e===this}getPriority(){return this}getImmediateChild(e){return nS.EMPTY_NODE}isEmpty(){return!1}};function nN(e,t=null){if(null===e)return nS.EMPTY_NODE;if("object"==typeof e&&".priority"in e&&(t=e[".priority"]),(0,p.hu)(null===t||"string"==typeof t||"number"==typeof t||"object"==typeof t&&".sv"in t,"Invalid priority type found: "+typeof t),"object"==typeof e&&".value"in e&&null!==e[".value"]&&(e=e[".value"]),"object"!=typeof e||".sv"in e){let n=e;return new ng(n,nN(t))}if(e instanceof Array){let i=nS.EMPTY_NODE;return t_(e,(t,n)=>{if((0,p.r3)(e,t)&&"."!==t.substring(0,1)){let r=nN(n);(r.isLeafNode()||!r.isEmpty())&&(i=i.updateImmediateChild(t,r))}}),i.updatePriority(nN(t))}{let r=[],s=!1,o=e;if(t_(o,(e,t)=>{if("."!==e.substring(0,1)){let n=nN(t);n.isEmpty()||(s=s||!n.getPriority().isEmpty(),r.push(new nt(e,n)))}}),0===r.length)return nS.EMPTY_NODE;let a=nb(r,nh,e=>e.name,nu);if(!s)return new nS(a,nN(t),nE.Default);{let l=nb(r,ny.getCompare());return new nS(a,nN(t),new nE({".priority":l},{".priority":ny}))}}}Object.defineProperties(nt,{MIN:{value:new nt(tu,nS.EMPTY_NODE)},MAX:{value:new nt(tc,nk)}}),nr.__EMPTY_NODE=nS.EMPTY_NODE,ng.__childrenNodeConstructor=nS,nc=nk,n_=nk,nm=nN;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nR extends nn{constructor(e){super(),this.indexPath_=e,(0,p.hu)(!t2(e)&&".priority"!==tQ(e),"Can't create PathIndex with empty path or .priority key")}extractChild(e){return e.getChild(this.indexPath_)}isDefinedOn(e){return!e.getChild(this.indexPath_).isEmpty()}compare(e,t){let n=this.extractChild(e.node),i=this.extractChild(t.node),r=n.compareTo(i);return 0===r?td(e.name,t.name):r}makePost(e,t){let n=nN(e),i=nS.EMPTY_NODE.updateChild(this.indexPath_,n);return new nt(t,i)}maxPost(){let e=nS.EMPTY_NODE.updateChild(this.indexPath_,nk);return new nt(tc,e)}toString(){return tZ(this.indexPath_,0).join("/")}}let nA=new /**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class extends nn{compare(e,t){let n=e.node.compareTo(t.node);return 0===n?td(e.name,t.name):n}isDefinedOn(e){return!0}indexedValueChanged(e,t){return!e.equals(t)}minPost(){return nt.MIN}maxPost(){return nt.MAX}makePost(e,t){let n=nN(e);return new nt(t,n)}toString(){return".value"}};function nD(e,t,n){return{type:"child_changed",snapshotNode:t,childName:e,oldSnap:n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nP{constructor(){this.limitSet_=!1,this.startSet_=!1,this.startNameSet_=!1,this.startAfterSet_=!1,this.endSet_=!1,this.endNameSet_=!1,this.endBeforeSet_=!1,this.limit_=0,this.viewFrom_="",this.indexStartValue_=null,this.indexStartName_="",this.indexEndValue_=null,this.indexEndName_="",this.index_=ny}hasStart(){return this.startSet_}isViewFromLeft(){return""===this.viewFrom_?this.startSet_:"l"===this.viewFrom_}getIndexStartValue(){return(0,p.hu)(this.startSet_,"Only valid if start has been set"),this.indexStartValue_}getIndexStartName(){return((0,p.hu)(this.startSet_,"Only valid if start has been set"),this.startNameSet_)?this.indexStartName_:tu}hasEnd(){return this.endSet_}getIndexEndValue(){return(0,p.hu)(this.endSet_,"Only valid if end has been set"),this.indexEndValue_}getIndexEndName(){return((0,p.hu)(this.endSet_,"Only valid if end has been set"),this.endNameSet_)?this.indexEndName_:tc}hasLimit(){return this.limitSet_}hasAnchoredLimit(){return this.limitSet_&&""!==this.viewFrom_}getLimit(){return(0,p.hu)(this.limitSet_,"Only valid if limit has been set"),this.limit_}getIndex(){return this.index_}loadsAllData(){return!(this.startSet_||this.endSet_||this.limitSet_)}isDefault(){return this.loadsAllData()&&this.index_===ny}copy(){let e=new nP;return e.limitSet_=this.limitSet_,e.limit_=this.limit_,e.startSet_=this.startSet_,e.startAfterSet_=this.startAfterSet_,e.indexStartValue_=this.indexStartValue_,e.startNameSet_=this.startNameSet_,e.indexStartName_=this.indexStartName_,e.endSet_=this.endSet_,e.endBeforeSet_=this.endBeforeSet_,e.indexEndValue_=this.indexEndValue_,e.endNameSet_=this.endNameSet_,e.indexEndName_=this.indexEndName_,e.index_=this.index_,e.viewFrom_=this.viewFrom_,e}}function nO(e){let t={};if(e.isDefault())return t;let n;if(e.index_===ny?n="$priority":e.index_===nA?n="$value":e.index_===ns?n="$key":((0,p.hu)(e.index_ instanceof nR,"Unrecognized index type!"),n=e.index_.toString()),t.orderBy=(0,p.Wl)(n),e.startSet_){let i=e.startAfterSet_?"startAfter":"startAt";t[i]=(0,p.Wl)(e.indexStartValue_),e.startNameSet_&&(t[i]+=","+(0,p.Wl)(e.indexStartName_))}if(e.endSet_){let r=e.endBeforeSet_?"endBefore":"endAt";t[r]=(0,p.Wl)(e.indexEndValue_),e.endNameSet_&&(t[r]+=","+(0,p.Wl)(e.indexEndName_))}return e.limitSet_&&(e.isViewFromLeft()?t.limitToFirst=e.limit_:t.limitToLast=e.limit_),t}function nx(e){let t={};if(e.startSet_&&(t.sp=e.indexStartValue_,e.startNameSet_&&(t.sn=e.indexStartName_),t.sin=!e.startAfterSet_),e.endSet_&&(t.ep=e.indexEndValue_,e.endNameSet_&&(t.en=e.indexEndName_),t.ein=!e.endBeforeSet_),e.limitSet_){t.l=e.limit_;let n=e.viewFrom_;""===n&&(n=e.isViewFromLeft()?"l":"r"),t.vf=n}return e.index_!==ny&&(t.i=e.index_.toString()),t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nL extends t${constructor(e,t,n,i){super(),this.repoInfo_=e,this.onDataUpdate_=t,this.authTokenProvider_=n,this.appCheckTokenProvider_=i,this.log_=ti("p:rest:"),this.listens_={}}reportStats(e){throw Error("Method not implemented.")}static getListenId_(e,t){return void 0!==t?"tag$"+t:((0,p.hu)(e._queryParams.isDefault(),"should have a tag if it's not a default query."),e._path.toString())}listen(e,t,n,i){let r=e._path.toString();this.log_("Listen called for "+r+" "+e._queryIdentifier);let s=nL.getListenId_(e,n),o={};this.listens_[s]=o;let a=nO(e._queryParams);this.restRequest_(r+".json",a,(e,t)=>{let a=t;404===e&&(a=null,e=null),null===e&&this.onDataUpdate_(r,a,!1,n),(0,p.DV)(this.listens_,s)===o&&i(e?401===e?"permission_denied":"rest_error:"+e:"ok",null)})}unlisten(e,t){let n=nL.getListenId_(e,t);delete this.listens_[n]}get(e){let t=nO(e._queryParams),n=e._path.toString(),i=new p.BH;return this.restRequest_(n+".json",t,(e,t)=>{let r=t;404===e&&(r=null,e=null),null===e?(this.onDataUpdate_(n,r,!1,null),i.resolve(r)):i.reject(Error(r))}),i.promise}refreshAuthToken(e){}restRequest_(e,t={},n){return t.format="export",Promise.all([this.authTokenProvider_.getToken(!1),this.appCheckTokenProvider_.getToken(!1)]).then(([i,r])=>{i&&i.accessToken&&(t.auth=i.accessToken),r&&r.token&&(t.ac=r.token);let s=(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host+e+"?ns="+this.repoInfo_.namespace+(0,p.xO)(t);this.log_("Sending REST request for "+s);let o=new XMLHttpRequest;o.onreadystatechange=()=>{if(n&&4===o.readyState){this.log_("REST Response for "+s+" received. status:",o.status,"response:",o.responseText);let e=null;if(o.status>=200&&o.status<300){try{e=(0,p.cI)(o.responseText)}catch(t){to("Failed to parse JSON response for "+s+": "+o.responseText)}n(null,e)}else 401!==o.status&&404!==o.status&&to("Got unsuccessful REST response for "+s+" Status: "+o.status),n(o.status);n=null}},o.open("GET",s,!0),o.send()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nM{constructor(){this.rootNode_=nS.EMPTY_NODE}getNode(e){return this.rootNode_.getChild(e)}updateSnapshot(e,t){this.rootNode_=this.rootNode_.updateChild(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function nF(){return{value:null,children:new Map}}function nU(e,t,n){null!==e.value?n(t,e.value):function(e,t){e.children.forEach((e,n)=>{t(n,e)})}(e,(e,i)=>{let r=new tK(t.toString()+"/"+e);nU(i,r,n)})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nV{constructor(e){this.collection_=e,this.last_=null}get(){let e=this.collection_.get(),t=Object.assign({},e);return this.last_&&t_(this.last_,(e,n)=>{t[e]=t[e]-n}),this.last_=e,t}}class nj{constructor(e,t){this.server_=t,this.statsToReport_={},this.statsListener_=new nV(e),tI(this.reportStats_.bind(this),Math.floor(1e4+2e4*Math.random()))}reportStats_(){let e=this.statsListener_.get(),t={},n=!1;t_(e,(e,i)=>{i>0&&(0,p.r3)(this.statsToReport_,e)&&(t[e]=i,n=!0)}),n&&this.server_.reportStats(t),tI(this.reportStats_.bind(this),Math.floor(2*Math.random()*3e5))}}function nq(){return{fromUser:!0,fromServer:!1,queryId:null,tagged:!1}}function nB(){return{fromUser:!1,fromServer:!0,queryId:null,tagged:!1}}function nz(e){return{fromUser:!1,fromServer:!0,queryId:e,tagged:!0}}(a=c||(c={}))[a.OVERWRITE=0]="OVERWRITE",a[a.MERGE=1]="MERGE",a[a.ACK_USER_WRITE=2]="ACK_USER_WRITE",a[a.LISTEN_COMPLETE=3]="LISTEN_COMPLETE";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class n${constructor(e,t,n){this.path=e,this.affectedTree=t,this.revert=n,this.type=c.ACK_USER_WRITE,this.source=nq()}operationForChild(e){if(!t2(this.path))return(0,p.hu)(tQ(this.path)===e,"operationForChild called for unrelated child."),new n$(tX(this.path),this.affectedTree,this.revert);if(null!=this.affectedTree.value)return(0,p.hu)(this.affectedTree.children.isEmpty(),"affectedTree should not have overlapping affected paths."),this;{let t=this.affectedTree.subtree(new tK(e));return new n$(tG(),t,this.revert)}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nW{constructor(e,t,n){this.source=e,this.path=t,this.snap=n,this.type=c.OVERWRITE}operationForChild(e){return t2(this.path)?new nW(this.source,tG(),this.snap.getImmediateChild(e)):new nW(this.source,tX(this.path),this.snap)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nH{constructor(e,t,n){this.source=e,this.path=t,this.children=n,this.type=c.MERGE}operationForChild(e){if(!t2(this.path))return(0,p.hu)(tQ(this.path)===e,"Can't get a merge for a child not on the path of the operation"),new nH(this.source,tX(this.path),this.children);{let t=this.children.subtree(new tK(e));return t.isEmpty()?null:t.value?new nW(this.source,tG(),t.value):new nH(this.source,tG(),t)}}toString(){return"Operation("+this.path+": "+this.source.toString()+" merge: "+this.children.toString()+")"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class nK{constructor(e,t,n){this.node_=e,this.fullyInitialized_=t,this.filtered_=n}isFullyInitialized(){return this.fullyInitialized_}isFiltered(){return this.filtered_}isCompleteForPath(e){if(t2(e))return this.isFullyInitialized()&&!this.filtered_;let t=tQ(e);return this.isCompleteForChild(t)}isCompleteForChild(e){return this.isFullyInitialized()&&!this.filtered_||this.node_.hasChild(e)}getNode(){return this.node_}}function nG(e,t,n,i,r,s){let o=i.filter(e=>e.type===n);o.sort((t,n)=>(function(e,t,n){if(null==t.childName||null==n.childName)throw(0,p.g5)("Should only compare child_ events.");let i=new nt(t.childName,t.snapshotNode),r=new nt(n.childName,n.snapshotNode);return e.index_.compare(i,r)})(e,t,n)),o.forEach(n=>{var i,o,a;let l=(i=e,o=n,a=s,"value"===o.type||"child_removed"===o.type||(o.prevName=a.getPredecessorChildName(o.childName,o.snapshotNode,i.index_)),o);r.forEach(i=>{i.respondsTo(n.type)&&t.push(i.createEvent(l,e.query_))})})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function nQ(e,t){return{eventCache:e,serverCache:t}}function nY(e,t,n,i){return nQ(new nK(t,n,i),e.serverCache)}function nX(e,t,n,i){return nQ(e.eventCache,new nK(t,n,i))}function nJ(e){return e.eventCache.isFullyInitialized()?e.eventCache.getNode():null}function nZ(e){return e.serverCache.isFullyInitialized()?e.serverCache.getNode():null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let n0,n1=()=>(n0||(n0=new nl(tf)),n0);class n2{constructor(e,t=n1()){this.value=e,this.children=t}static fromObject(e){let t=new n2(null);return t_(e,(e,n)=>{t=t.set(new tK(e),n)}),t}isEmpty(){return null===this.value&&this.children.isEmpty()}findRootMostMatchingPathAndValue(e,t){if(null!=this.value&&t(this.value))return{path:tG(),value:this.value};if(t2(e))return null;{let n=tQ(e),i=this.children.get(n);if(null===i)return null;{let r=i.findRootMostMatchingPathAndValue(tX(e),t);if(null==r)return null;{let s=t1(new tK(n),r.path);return{path:s,value:r.value}}}}}findRootMostValueAndPath(e){return this.findRootMostMatchingPathAndValue(e,()=>!0)}subtree(e){if(t2(e))return this;{let t=tQ(e),n=this.children.get(t);return null!==n?n.subtree(tX(e)):new n2(null)}}set(e,t){if(t2(e))return new n2(t,this.children);{let n=tQ(e),i=this.children.get(n)||new n2(null),r=i.set(tX(e),t),s=this.children.insert(n,r);return new n2(this.value,s)}}remove(e){if(t2(e))return this.children.isEmpty()?new n2(null):new n2(null,this.children);{let t=tQ(e),n=this.children.get(t);if(!n)return this;{let i=n.remove(tX(e)),r;return(r=i.isEmpty()?this.children.remove(t):this.children.insert(t,i),null===this.value&&r.isEmpty())?new n2(null):new n2(this.value,r)}}}get(e){if(t2(e))return this.value;{let t=tQ(e),n=this.children.get(t);return n?n.get(tX(e)):null}}setTree(e,t){if(t2(e))return t;{let n=tQ(e),i=this.children.get(n)||new n2(null),r=i.setTree(tX(e),t),s;return s=r.isEmpty()?this.children.remove(n):this.children.insert(n,r),new n2(this.value,s)}}fold(e){return this.fold_(tG(),e)}fold_(e,t){let n={};return this.children.inorderTraversal((i,r)=>{n[i]=r.fold_(t1(e,i),t)}),t(e,this.value,n)}findOnPath(e,t){return this.findOnPath_(e,tG(),t)}findOnPath_(e,t,n){let i=!!this.value&&n(t,this.value);if(i)return i;if(t2(e))return null;{let r=tQ(e),s=this.children.get(r);return s?s.findOnPath_(tX(e),t1(t,r),n):null}}foreachOnPath(e,t){return this.foreachOnPath_(e,tG(),t)}foreachOnPath_(e,t,n){if(t2(e))return this;{this.value&&n(t,this.value);let i=tQ(e),r=this.children.get(i);return r?r.foreachOnPath_(tX(e),t1(t,i),n):new n2(null)}}foreach(e){this.foreach_(tG(),e)}foreach_(e,t){this.children.inorderTraversal((n,i)=>{i.foreach_(t1(e,n),t)}),this.value&&t(e,this.value)}foreachChild(e){this.children.inorderTraversal((t,n)=>{n.value&&e(t,n.value)})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class n4{constructor(e){this.writeTree_=e}static empty(){return new n4(new n2(null))}}function n9(e,t,n){if(t2(t))return new n4(new n2(n));{let i=e.writeTree_.findRootMostValueAndPath(t);if(null!=i){let r=i.path,s=i.value,o=t4(r,t);return s=s.updateChild(o,n),new n4(e.writeTree_.set(r,s))}{let a=new n2(n),l=e.writeTree_.setTree(t,a);return new n4(l)}}}function n6(e,t,n){let i=e;return t_(n,(e,n)=>{i=n9(i,t1(t,e),n)}),i}function n5(e,t){if(t2(t))return n4.empty();{let n=e.writeTree_.setTree(t,new n2(null));return new n4(n)}}function n3(e,t){return null!=n7(e,t)}function n7(e,t){let n=e.writeTree_.findRootMostValueAndPath(t);return null!=n?e.writeTree_.get(n.path).getChild(t4(n.path,t)):null}function n8(e){let t=[],n=e.writeTree_.value;return null!=n?n.isLeafNode()||n.forEachChild(ny,(e,n)=>{t.push(new nt(e,n))}):e.writeTree_.children.inorderTraversal((e,n)=>{null!=n.value&&t.push(new nt(e,n.value))}),t}function ie(e,t){if(t2(t))return e;{let n=n7(e,t);return new n4(null!=n?new n2(n):e.writeTree_.subtree(t))}}function it(e){return e.writeTree_.isEmpty()}function ii(e,t){return function e(t,n,i){if(null!=n.value)return i.updateChild(t,n.value);{let r=null;return n.children.inorderTraversal((n,s)=>{".priority"===n?((0,p.hu)(null!==s.value,"Priority writes must always be leaf nodes"),r=s.value):i=e(t1(t,n),s,i)}),i.getChild(t).isEmpty()||null===r||(i=i.updateChild(t1(t,".priority"),r)),i}}(tG(),e.writeTree_,t)}function ir(e,t){if(e.snap)return t6(e.path,t);for(let n in e.children)if(e.children.hasOwnProperty(n)&&t6(t1(e.path,n),t))return!0;return!1}function is(e){return e.visible}function io(e,t,n){let i=n4.empty();for(let r=0;r<e.length;++r){let s=e[r];if(t(s)){let o=s.path,a;if(s.snap)t6(n,o)?(a=t4(n,o),i=n9(i,a,s.snap)):t6(o,n)&&(a=t4(o,n),i=n9(i,tG(),s.snap.getChild(a)));else if(s.children){if(t6(n,o))a=t4(n,o),i=n6(i,a,s.children);else if(t6(o,n)){if(a=t4(o,n),t2(a))i=n6(i,tG(),s.children);else{let l=(0,p.DV)(s.children,tQ(a));if(l){let h=l.getChild(tX(a));i=n9(i,tG(),h)}}}}else throw(0,p.g5)("WriteRecord should have .snap or .children")}}return i}function ia(e,t,n,i,r){if(i||r){let s=ie(e.visibleWrites,t);if(!r&&it(s))return n;if(!r&&null==n&&!n3(s,tG()))return null;{let o=function(e){return(e.visible||r)&&(!i||!~i.indexOf(e.writeId))&&(t6(e.path,t)||t6(t,e.path))},a=io(e.allWrites,o,t),l=n||nS.EMPTY_NODE;return ii(a,l)}}{let h=n7(e.visibleWrites,t);if(null!=h)return h;{let u=ie(e.visibleWrites,t);if(it(u))return n;if(null==n&&!n3(u,tG()))return null;{let c=n||nS.EMPTY_NODE;return ii(u,c)}}}}function il(e,t,n,i){return ia(e.writeTree,e.treePath,t,n,i)}function ih(e,t){return function(e,t,n){let i=nS.EMPTY_NODE,r=n7(e.visibleWrites,t);if(r)return r.isLeafNode()||r.forEachChild(ny,(e,t)=>{i=i.updateImmediateChild(e,t)}),i;if(n){let s=ie(e.visibleWrites,t);return n.forEachChild(ny,(e,t)=>{let n=ii(ie(s,new tK(e)),t);i=i.updateImmediateChild(e,n)}),n8(s).forEach(e=>{i=i.updateImmediateChild(e.name,e.node)}),i}{let o=ie(e.visibleWrites,t);return n8(o).forEach(e=>{i=i.updateImmediateChild(e.name,e.node)}),i}}(e.writeTree,e.treePath,t)}function iu(e,t,n,i){return function(e,t,n,i,r){(0,p.hu)(i||r,"Either existingEventSnap or existingServerSnap must exist");let s=t1(t,n);if(n3(e.visibleWrites,s))return null;{let o=ie(e.visibleWrites,s);return it(o)?r.getChild(n):ii(o,r.getChild(n))}}(e.writeTree,e.treePath,t,n,i)}function ic(e,t){var n,i;return n=e.writeTree,i=t1(e.treePath,t),n7(n.visibleWrites,i)}function id(e,t,n){return function(e,t,n,i){let r=t1(t,n),s=n7(e.visibleWrites,r);if(null!=s)return s;if(!i.isCompleteForChild(n))return null;{let o=ie(e.visibleWrites,r);return ii(o,i.getNode().getImmediateChild(n))}}(e.writeTree,e.treePath,t,n)}function ip(e,t){return ig(t1(e.treePath,t),e.writeTree)}function ig(e,t){return{treePath:e,writeTree:t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class im{constructor(){this.changeMap=new Map}trackChildChange(e){let t=e.type,n=e.childName;(0,p.hu)("child_added"===t||"child_changed"===t||"child_removed"===t,"Only child changes supported for tracking"),(0,p.hu)(".priority"!==n,"Only non-priority child changes can be tracked.");let i=this.changeMap.get(n);if(i){var r,s,o,a;let l=i.type;if("child_added"===t&&"child_removed"===l)this.changeMap.set(n,nD(n,e.snapshotNode,i.snapshotNode));else if("child_removed"===t&&"child_added"===l)this.changeMap.delete(n);else if("child_removed"===t&&"child_changed"===l)this.changeMap.set(n,(r=n,s=i.oldSnap,{type:"child_removed",snapshotNode:s,childName:r}));else if("child_changed"===t&&"child_added"===l)this.changeMap.set(n,(o=n,a=e.snapshotNode,{type:"child_added",snapshotNode:a,childName:o}));else if("child_changed"===t&&"child_changed"===l)this.changeMap.set(n,nD(n,e.snapshotNode,i.oldSnap));else throw(0,p.g5)("Illegal combination of changes: "+e+" occurred after "+i)}else this.changeMap.set(n,e)}getChanges(){return Array.from(this.changeMap.values())}}let i_=new /**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class{getCompleteChild(e){return null}getChildAfterChild(e,t,n){return null}};class iy{constructor(e,t,n=null){this.writes_=e,this.viewCache_=t,this.optCompleteServerCache_=n}getCompleteChild(e){let t=this.viewCache_.eventCache;if(t.isCompleteForChild(e))return t.getNode().getImmediateChild(e);{let n=null!=this.optCompleteServerCache_?new nK(this.optCompleteServerCache_,!0,!1):this.viewCache_.serverCache;return id(this.writes_,e,n)}}getChildAfterChild(e,t,n){var i,r,s,o,a;let l=null!=this.optCompleteServerCache_?this.optCompleteServerCache_:nZ(this.viewCache_),h=function(e,t,n,i,r,s,o){let a,l=ie(e.visibleWrites,t),h=n7(l,tG());if(null!=h)a=h;else{if(null==n)return[];a=ii(l,n)}if((a=a.withIndex(o)).isEmpty()||a.isLeafNode())return[];{let u=[],c=o.getCompare(),d=s?a.getReverseIteratorFrom(i,o):a.getIteratorFrom(i,o),f=d.getNext();for(;f&&u.length<1;)0!==c(f,i)&&u.push(f),f=d.getNext();return u}}((i=this.writes_).writeTree,i.treePath,l,t,1,n,e);return 0===h.length?null:h[0]}}function iv(e,t,n,i,r,s){let o=t.eventCache;if(null!=ic(i,n))return t;{let a,l;if(t2(n)){if((0,p.hu)(t.serverCache.isFullyInitialized(),"If change path is empty, we must have complete server data"),t.serverCache.isFiltered()){let h=nZ(t),u=h instanceof nS?h:nS.EMPTY_NODE,c=ih(i,u);a=e.filter.updateFullNode(t.eventCache.getNode(),c,s)}else{let d=il(i,nZ(t));a=e.filter.updateFullNode(t.eventCache.getNode(),d,s)}}else{let f=tQ(n);if(".priority"===f){(0,p.hu)(1===tY(n),"Can't have a priority with additional path components");let g=o.getNode();l=t.serverCache.getNode();let m=iu(i,n,g,l);a=null!=m?e.filter.updatePriority(g,m):o.getNode()}else{let _=tX(n),y;if(o.isCompleteForChild(f)){l=t.serverCache.getNode();let v=iu(i,n,o.getNode(),l);y=null!=v?o.getNode().getImmediateChild(f).updateChild(_,v):o.getNode().getImmediateChild(f)}else y=id(i,f,t.serverCache);a=null!=y?e.filter.updateChild(o.getNode(),f,y,_,r,s):o.getNode()}}return nY(t,a,o.isFullyInitialized()||t2(n),e.filter.filtersNodes())}}function iw(e,t,n,i,r,s,o,a){let l=t.serverCache,h,u=o?e.filter:e.filter.getIndexedFilter();if(t2(n))h=u.updateFullNode(l.getNode(),i,null);else if(u.filtersNodes()&&!l.isFiltered()){let c=l.getNode().updateChild(n,i);h=u.updateFullNode(l.getNode(),c,null)}else{let d=tQ(n);if(!l.isCompleteForPath(n)&&tY(n)>1)return t;let f=tX(n),p=l.getNode().getImmediateChild(d),g=p.updateChild(f,i);h=".priority"===d?u.updatePriority(l.getNode(),g):u.updateChild(l.getNode(),d,g,f,i_,null)}let m=nX(t,h,l.isFullyInitialized()||t2(n),u.filtersNodes()),_=new iy(r,m,s);return iv(e,m,n,r,_,a)}function ib(e,t,n,i,r,s,o){let a=t.eventCache,l,h,u=new iy(r,t,s);if(t2(n))h=e.filter.updateFullNode(t.eventCache.getNode(),i,o),l=nY(t,h,!0,e.filter.filtersNodes());else{let c=tQ(n);if(".priority"===c)h=e.filter.updatePriority(t.eventCache.getNode(),i),l=nY(t,h,a.isFullyInitialized(),a.isFiltered());else{let d=tX(n),f=a.getNode().getImmediateChild(c),p;if(t2(d))p=i;else{let g=u.getCompleteChild(c);p=null!=g?".priority"===tJ(d)&&g.getChild(t0(d)).isEmpty()?g:g.updateChild(d,i):nS.EMPTY_NODE}if(f.equals(p))l=t;else{let m=e.filter.updateChild(a.getNode(),c,p,d,u,o);l=nY(t,m,a.isFullyInitialized(),e.filter.filtersNodes())}}}return l}function iT(e,t){return e.eventCache.isCompleteForChild(t)}function iI(e,t,n){return n.foreach((e,n)=>{t=t.updateChild(e,n)}),t}function iE(e,t,n,i,r,s,o,a){if(t.serverCache.getNode().isEmpty()&&!t.serverCache.isFullyInitialized())return t;let l=t,h;h=t2(n)?i:new n2(null).setTree(n,i);let u=t.serverCache.getNode();return h.children.inorderTraversal((n,i)=>{if(u.hasChild(n)){let h=t.serverCache.getNode().getImmediateChild(n),c=iI(e,h,i);l=iw(e,l,new tK(n),c,r,s,o,a)}}),h.children.inorderTraversal((n,i)=>{let h=!t.serverCache.isCompleteForChild(n)&&null===i.value;if(!u.hasChild(n)&&!h){let c=t.serverCache.getNode().getImmediateChild(n),d=iI(e,c,i);l=iw(e,l,new tK(n),d,r,s,o,a)}}),l}function iC(e,t){let n=nZ(e.viewCache_);return n&&(e.query._queryParams.loadsAllData()||!t2(t)&&!n.getImmediateChild(tQ(t)).isEmpty())?n.getChild(t):null}function iS(e,t,n,i){var r,s;t.type===c.MERGE&&null!==t.source.queryId&&((0,p.hu)(nZ(e.viewCache_),"We should always have a full cache before handling merges"),(0,p.hu)(nJ(e.viewCache_),"Missing event cache, even though we have a server cache"));let o=e.viewCache_,a=function(e,t,n,i,r){let s=new im,o,a;if(n.type===c.OVERWRITE)n.source.fromUser?o=ib(e,t,n.path,n.snap,i,r,s):((0,p.hu)(n.source.fromServer,"Unknown source."),a=n.source.tagged||t.serverCache.isFiltered()&&!t2(n.path),o=iw(e,t,n.path,n.snap,i,r,a,s));else if(n.type===c.MERGE){var l,h,u,d,f,g,m;let _;n.source.fromUser?(l=e,h=t,u=n.path,d=n.children,f=i,g=r,m=s,_=h,o=(d.foreach((e,t)=>{let n=t1(u,e);iT(h,tQ(n))&&(_=ib(l,_,n,t,f,g,m))}),d.foreach((e,t)=>{let n=t1(u,e);iT(h,tQ(n))||(_=ib(l,_,n,t,f,g,m))}),_)):((0,p.hu)(n.source.fromServer,"Unknown source."),a=n.source.tagged||t.serverCache.isFiltered(),o=iE(e,t,n.path,n.children,i,r,a,s))}else if(n.type===c.ACK_USER_WRITE)o=n.revert?function(e,t,n,i,r,s){let o;if(null!=ic(i,n))return t;{let a=new iy(i,t,r),l=t.eventCache.getNode(),h;if(t2(n)||".priority"===tQ(n)){let u;if(t.serverCache.isFullyInitialized())u=il(i,nZ(t));else{let c=t.serverCache.getNode();(0,p.hu)(c instanceof nS,"serverChildren would be complete if leaf node"),u=ih(i,c)}h=e.filter.updateFullNode(l,u,s)}else{let d=tQ(n),f=id(i,d,t.serverCache);null==f&&t.serverCache.isCompleteForChild(d)&&(f=l.getImmediateChild(d)),(h=null!=f?e.filter.updateChild(l,d,f,tX(n),a,s):t.eventCache.getNode().hasChild(d)?e.filter.updateChild(l,d,nS.EMPTY_NODE,tX(n),a,s):l).isEmpty()&&t.serverCache.isFullyInitialized()&&(o=il(i,nZ(t))).isLeafNode()&&(h=e.filter.updateFullNode(h,o,s))}return o=t.serverCache.isFullyInitialized()||null!=ic(i,tG()),nY(t,h,o,e.filter.filtersNodes())}}(e,t,n.path,i,r,s):function(e,t,n,i,r,s,o){if(null!=ic(r,n))return t;let a=t.serverCache.isFiltered(),l=t.serverCache;if(null!=i.value){if(t2(n)&&l.isFullyInitialized()||l.isCompleteForPath(n))return iw(e,t,n,l.getNode().getChild(n),r,s,a,o);if(!t2(n))return t;{let h=new n2(null);return l.getNode().forEachChild(ns,(e,t)=>{h=h.set(new tK(e),t)}),iE(e,t,n,h,r,s,a,o)}}{let u=new n2(null);return i.foreach((e,t)=>{let i=t1(n,e);l.isCompleteForPath(i)&&(u=u.set(e,l.getNode().getChild(i)))}),iE(e,t,n,u,r,s,a,o)}}(e,t,n.path,n.affectedTree,i,r,s);else if(n.type===c.LISTEN_COMPLETE)o=function(e,t,n,i,r){let s=t.serverCache,o=nX(t,s.getNode(),s.isFullyInitialized()||t2(n),s.isFiltered());return iv(e,o,n,i,i_,r)}(e,t,n.path,i,s);else throw(0,p.g5)("Unknown operation type: "+n.type);let y=s.getChanges();return function(e,t,n){let i=t.eventCache;if(i.isFullyInitialized()){let r=i.getNode().isLeafNode()||i.getNode().isEmpty(),s=nJ(e);if(n.length>0||!e.eventCache.isFullyInitialized()||r&&!i.getNode().equals(s)||!i.getNode().getPriority().equals(s.getPriority())){var o;n.push((o=nJ(t),{type:"value",snapshotNode:o}))}}}(t,o,y),{viewCache:o,changes:y}}(e.processor_,o,t,n,i);return r=e.processor_,s=a.viewCache,(0,p.hu)(s.eventCache.getNode().isIndexed(r.filter.getIndex()),"Event snap not indexed"),(0,p.hu)(s.serverCache.getNode().isIndexed(r.filter.getIndex()),"Server snap not indexed"),(0,p.hu)(a.viewCache.serverCache.isFullyInitialized()||!o.serverCache.isFullyInitialized(),"Once a server snap is complete, it should never go back"),e.viewCache_=a.viewCache,function(e,t,n,i){let r=i?[i]:e.eventRegistrations_;return function(e,t,n,i){let r=[],s=[];return t.forEach(t=>{if("child_changed"===t.type&&e.index_.indexedValueChanged(t.oldSnap,t.snapshotNode)){var n,i;s.push((n=t.childName,i=t.snapshotNode,{type:"child_moved",snapshotNode:i,childName:n}))}}),nG(e,r,"child_removed",t,i,n),nG(e,r,"child_added",t,i,n),nG(e,r,"child_moved",s,i,n),nG(e,r,"child_changed",t,i,n),nG(e,r,"value",t,i,n),r}(e.eventGenerator_,t,n,r)}(e,a.changes,a.viewCache.eventCache.getNode(),null)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ik;function iN(e,t,n,i){let r=t.source.queryId;if(null!==r){let s=e.views.get(r);return(0,p.hu)(null!=s,"SyncTree gave us an op for an invalid query."),iS(s,t,n,i)}{let o=[];for(let a of e.views.values())o=o.concat(iS(a,t,n,i));return o}}function iR(e,t){let n=null;for(let i of e.views.values())n=n||iC(i,t);return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let iA;class iD{constructor(e){this.listenProvider_=e,this.syncPointTree_=new n2(null),this.pendingWriteTree_={visibleWrites:n4.empty(),allWrites:[],lastWriteId:-1},this.tagToQueryMap=new Map,this.queryToTagMap=new Map}}function iP(e,t,n,i,r){var s,o,a,l,h;return(s=e.pendingWriteTree_,h=r,(0,p.hu)(i>s.lastWriteId,"Stacking an older write on top of newer ones"),void 0===h&&(h=!0),s.allWrites.push({path:t,snap:n,writeId:i,visible:h}),h&&(s.visibleWrites=n9(s.visibleWrites,t,n)),s.lastWriteId=i,r)?iM(e,new nW(nq(),t,n)):[]}function iO(e,t,n=!1){let i=function(e,t){for(let n=0;n<e.allWrites.length;n++){let i=e.allWrites[n];if(i.writeId===t)return i}return null}(e.pendingWriteTree_,t),r=function(e,t){let n=e.allWrites.findIndex(e=>e.writeId===t);(0,p.hu)(n>=0,"removeWrite called with nonexistent writeId.");let i=e.allWrites[n];e.allWrites.splice(n,1);let r=i.visible,s=!1,o=e.allWrites.length-1;for(;r&&o>=0;){let a=e.allWrites[o];a.visible&&(o>=n&&ir(a,i.path)?r=!1:t6(i.path,a.path)&&(s=!0)),o--}if(!r)return!1;if(s){var l;return(l=e).visibleWrites=io(l.allWrites,is,tG()),l.allWrites.length>0?l.lastWriteId=l.allWrites[l.allWrites.length-1].writeId:l.lastWriteId=-1,!0}if(i.snap)e.visibleWrites=n5(e.visibleWrites,i.path);else{let h=i.children;t_(h,t=>{e.visibleWrites=n5(e.visibleWrites,t1(i.path,t))})}return!0}(e.pendingWriteTree_,t);if(!r)return[];{let s=new n2(null);return null!=i.snap?s=s.set(tG(),!0):t_(i.children,e=>{s=s.set(new tK(e),!0)}),iM(e,new n$(i.path,s,n))}}function ix(e,t,n){return iM(e,new nW(nB(),t,n))}function iL(e,t,n){let i=e.pendingWriteTree_,r=e.syncPointTree_.findOnPath(t,(e,n)=>{let i=t4(e,t),r=iR(n,i);if(r)return r});return ia(i,t,r,n,!0)}function iM(e,t){var n,i;return function e(t,n,i,r){if(t2(t.path))return function e(t,n,i,r){let s=n.get(tG());null==i&&null!=s&&(i=iR(s,tG()));let o=[];return n.children.inorderTraversal((n,s)=>{let a=i?i.getImmediateChild(n):null,l=ip(r,n),h=t.operationForChild(n);h&&(o=o.concat(e(h,s,a,l)))}),s&&(o=o.concat(iN(s,t,r,i))),o}(t,n,i,r);{let s=n.get(tG());null==i&&null!=s&&(i=iR(s,tG()));let o=[],a=tQ(t.path),l=t.operationForChild(a),h=n.children.get(a);if(h&&l){let u=i?i.getImmediateChild(a):null,c=ip(r,a);o=o.concat(e(l,h,u,c))}return s&&(o=o.concat(iN(s,t,r,i))),o}}(t,e.syncPointTree_,null,(n=e.pendingWriteTree_,i=tG(),ig(i,n)))}function iF(e,t){return e.tagToQueryMap.get(t)}function iU(e){let t=e.indexOf("$");return(0,p.hu)(-1!==t&&t<e.length-1,"Bad queryKey."),{queryId:e.substr(t+1),path:new tK(e.substr(0,t))}}function iV(e,t,n){var i,r;let s=e.syncPointTree_.get(t);(0,p.hu)(s,"Missing sync point for query tag that we're tracking");let o=ig(t,i=e.pendingWriteTree_);return iN(s,n,o,null)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ij{constructor(e){this.node_=e}getImmediateChild(e){let t=this.node_.getImmediateChild(e);return new ij(t)}node(){return this.node_}}class iq{constructor(e,t){this.syncTree_=e,this.path_=t}getImmediateChild(e){let t=t1(this.path_,e);return new iq(this.syncTree_,t)}node(){return iL(this.syncTree_,this.path_)}}let iB=function(e,t,n){return e&&"object"==typeof e?((0,p.hu)(".sv"in e,"Unexpected leaf node or priority contents"),"string"==typeof e[".sv"])?iz(e[".sv"],t,n):"object"==typeof e[".sv"]?i$(e[".sv"],t):void(0,p.hu)(!1,"Unexpected server value: "+JSON.stringify(e,null,2)):e},iz=function(e,t,n){if("timestamp"===e)return n.timestamp;(0,p.hu)(!1,"Unexpected server value: "+e)},i$=function(e,t,n){e.hasOwnProperty("increment")||(0,p.hu)(!1,"Unexpected server value: "+JSON.stringify(e,null,2));let i=e.increment;"number"!=typeof i&&(0,p.hu)(!1,"Unexpected increment value: "+i);let r=t.node();if((0,p.hu)(null!=r,"Expected ChildrenNode.EMPTY_NODE for nulls"),!r.isLeafNode())return i;let s=r.getValue();return"number"!=typeof s?i:s+i};function iW(e,t,n){let i=e.getPriority().val(),r=iB(i,t.getImmediateChild(".priority"),n),s;if(!e.isLeafNode())return s=e,r!==e.getPriority().val()&&(s=s.updatePriority(new ng(r))),e.forEachChild(ny,(e,i)=>{let r=iW(i,t.getImmediateChild(e),n);r!==i&&(s=s.updateImmediateChild(e,r))}),s;{let o=iB(e.getValue(),t,n);return o!==e.getValue()||r!==e.getPriority().val()?new ng(o,nN(r)):e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iH{constructor(e="",t=null,n={children:{},childCount:0}){this.name=e,this.parent=t,this.node=n}}function iK(e,t){let n=t instanceof tK?t:new tK(t),i=e,r=tQ(n);for(;null!==r;){let s=(0,p.DV)(i.node.children,r)||{children:{},childCount:0};i=new iH(r,i,s),n=tX(n),r=tQ(n)}return i}function iG(e){return e.node.value}function iQ(e,t){e.node.value=t,function e(t){null!==t.parent&&function(t,n,i){var r;let s=void 0===iG(i)&&!iY(i),o=(0,p.r3)(t.node.children,n);s&&o?(delete t.node.children[n],t.node.childCount--,e(t)):s||o||(t.node.children[n]=i.node,t.node.childCount++,e(t))}(t.parent,t.name,t)}(e)}function iY(e){return e.node.childCount>0}function iX(e,t){t_(e.node.children,(n,i)=>{t(new iH(n,e,i))})}function iJ(e){return new tK(null===e.parent?e.name:iJ(e.parent)+"/"+e.name)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let iZ=/[\[\].#$\/\u0000-\u001F\u007F]/,i0=/[\[\].#$\u0000-\u001F\u007F]/,i1=function(e){return"string"==typeof e&&0!==e.length&&!iZ.test(e)},i2=function(e){var t;return e&&(e=e.replace(/^\/*\.info(\/|$)/,"/")),"string"==typeof(t=e)&&0!==t.length&&!i0.test(t)},i4=function(e,t,n){let i=n instanceof tK?new t5(n,e):n;if(void 0===t)throw Error(e+"contains undefined "+t7(i));if("function"==typeof t)throw Error(e+"contains a function "+t7(i)+" with contents = "+t.toString());if(tl(t))throw Error(e+"contains "+t.toString()+" "+t7(i));if("string"==typeof t&&t.length>3495253.3333333335&&(0,p.ug)(t)>10485760)throw Error(e+"contains a string greater than 10485760 utf8 bytes "+t7(i)+" ('"+t.substring(0,50)+"...')");if(t&&"object"==typeof t){let r=!1,s=!1;if(t_(t,(t,n)=>{var o,a;if(".value"===t)r=!0;else if(".priority"!==t&&".sv"!==t&&(s=!0,!i1(t)))throw Error(e+" contains an invalid key ("+t+") "+t7(i)+'.  Keys must be non-empty strings and can\'t contain ".", "#", "$", "/", "[", or "]"');(o=i).parts_.length>0&&(o.byteLength_+=1),o.parts_.push(t),o.byteLength_+=(0,p.ug)(t),t3(o),i4(e,n,i),function(e){let t=e.parts_.pop();e.byteLength_-=(0,p.ug)(t),e.parts_.length>0&&(e.byteLength_-=1)}(i)}),r&&s)throw Error(e+' contains ".value" child '+t7(i)+" in addition to actual children.")}},i9=function(e,t){let n=t.path.toString();if("string"!=typeof t.repoInfo.host||0===t.repoInfo.host.length||!i1(t.repoInfo.namespace)&&"localhost"!==t.repoInfo.host.split(":")[0]||0!==n.length&&!i2(n))throw Error((0,p.gK)(e,"url")+'must be a valid firebase URL and the path can\'t contain ".", "#", "$", "[", or "]".')};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class i6{constructor(){this.eventLists_=[],this.recursionDepth_=0}}function i5(e,t,n){!function(e,t){let n=null;for(let i=0;i<t.length;i++){let r=t[i],s=r.getPath();null===n||t9(s,n.path)||(e.eventLists_.push(n),n=null),null===n&&(n={events:[],path:s}),n.events.push(r)}n&&e.eventLists_.push(n)}(e,n),function(e,t){e.recursionDepth_++;let n=!0;for(let i=0;i<e.eventLists_.length;i++){let r=e.eventLists_[i];if(r){let s=r.path;t(s)?(i3(e.eventLists_[i]),e.eventLists_[i]=null):n=!1}}n&&(e.eventLists_=[]),e.recursionDepth_--}(e,e=>t6(e,t)||t6(t,e))}function i3(e){for(let t=0;t<e.events.length;t++){let n=e.events[t];if(null!==n){e.events[t]=null;let i=n.getEventRunner();e8&&tn("event: "+n.toString()),tb(i)}}}class i7{constructor(e,t,n,i){this.repoInfo_=e,this.forceRestClient_=t,this.authTokenProvider_=n,this.appCheckProvider_=i,this.dataUpdateCount=0,this.statsListener_=null,this.eventQueue_=new i6,this.nextWriteId_=1,this.interceptServerDataCallback_=null,this.onDisconnect_=nF(),this.transactionQueueTree_=new iH,this.persistentConnection_=null,this.key=this.repoInfo_.toURLString()}toString(){return(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host}}function i8(e){var t;return(t=t={timestamp:function(e){let t=e.infoData_.getNode(new tK(".info/serverTimeOffset")),n=t.val()||0;return new Date().getTime()+n}(e)}).timestamp=t.timestamp||new Date().getTime(),t}function re(e,t,n,i,r){e.dataUpdateCount++;let s=new tK(t);n=e.interceptServerDataCallback_?e.interceptServerDataCallback_(t,n):n;let o=[];if(r){if(i){let a=(0,p.UI)(n,e=>nN(e));o=function(e,t,n,i){let r=iF(e,i);if(!r)return[];{let s=iU(r),o=s.path,a=s.queryId,l=t4(o,t),h=n2.fromObject(n),u=new nH(nz(a),l,h);return iV(e,o,u)}}(e.serverSyncTree_,s,a,r)}else{let l=nN(n);o=function(e,t,n,i){let r=iF(e,i);if(null==r)return[];{let s=iU(r),o=s.path,a=s.queryId,l=t4(o,t),h=new nW(nz(a),l,n);return iV(e,o,h)}}(e.serverSyncTree_,s,l,r)}}else if(i){let h=(0,p.UI)(n,e=>nN(e));o=function(e,t,n){let i=n2.fromObject(n);return iM(e,new nH(nB(),t,i))}(e.serverSyncTree_,s,h)}else{let u=nN(n);o=ix(e.serverSyncTree_,s,u)}let c=s;o.length>0&&(c=ro(e,s)),i5(e.eventQueue_,c,o)}function rt(e,t){rn(e,"connected",t),!1===t&&function(e){rr(e,"onDisconnectEvents");let t=i8(e),n=nF();nU(e.onDisconnect_,tG(),(i,r)=>{var s,o,a,l;let h=(a=e.serverSyncTree_,iW(r,new iq(a,i),t));!function e(t,n,i){if(t2(n))t.value=i,t.children.clear();else if(null!==t.value)t.value=t.value.updateChild(n,i);else{let r=tQ(n);t.children.has(r)||t.children.set(r,nF());let s=t.children.get(r);n=tX(n),e(s,n,i)}}(n,i,h)});let i=[];nU(n,tG(),(t,n)=>{i=i.concat(ix(e.serverSyncTree_,t,n));let r=function(e,t){let n=iJ(ra(e,t)),i=iK(e.transactionQueueTree_,t);return function(e,t,n){let i=e.parent;for(;null!==i;){if(t(i))return!0;i=i.parent}}(i,t=>{ru(e,t)}),ru(e,i),function e(t,n,i,r){i&&!r&&n(t),iX(t,t=>{e(t,n,!0,r)}),i&&r&&n(t)}(i,t=>{ru(e,t)}),n}(e,t);ro(e,r)}),e.onDisconnect_=nF(),i5(e.eventQueue_,tG(),i)}(e)}function rn(e,t,n){let i=new tK("/.info/"+t),r=nN(n);e.infoData_.updateSnapshot(i,r);let s=ix(e.infoSyncTree_,i,r);i5(e.eventQueue_,i,s)}function ri(e){return e.nextWriteId_++}function rr(e,...t){let n="";e.persistentConnection_&&(n=e.persistentConnection_.id+":"),tn(n,...t)}function rs(e,t,n){return iL(e.serverSyncTree_,t,n)||nS.EMPTY_NODE}function ro(e,t){let n=ra(e,t),i=iJ(n),r=rl(e,n);return function(e,t,n){if(0===t.length)return;let i=[],r=[],s=t.filter(e=>0===e.status),o=s.map(e=>e.currentWriteId);for(let a=0;a<t.length;a++){var l,h,u,c;let d=t[a],f=t4(n,d.path),g=!1,m;if((0,p.hu)(null!==f,"rerunTransactionsUnderNode_: relativePath should not be null."),4===d.status)g=!0,m=d.abortReason,r=r.concat(iO(e.serverSyncTree_,d.currentWriteId,!0));else if(0===d.status){if(d.retryCount>=25)g=!0,m="maxretry",r=r.concat(iO(e.serverSyncTree_,d.currentWriteId,!0));else{let _=rs(e,d.path,o);d.currentInputSnapshot=_;let y=t[a].update(_.val());if(void 0!==y){i4("transaction failed: Data returned ",y,d.path);let v=nN(y),w="object"==typeof y&&null!=y&&(0,p.r3)(y,".priority");w||(v=v.updatePriority(_.getPriority()));let b=d.currentWriteId,T=i8(e),I=(l=v,h=_,u=T,iW(l,new ij(h),u));d.currentOutputSnapshotRaw=v,d.currentOutputSnapshotResolved=I,d.currentWriteId=ri(e),o.splice(o.indexOf(b),1),r=(r=r.concat(iP(e.serverSyncTree_,d.path,I,d.currentWriteId,d.applyLocally))).concat(iO(e.serverSyncTree_,b,!0))}else g=!0,m="nodata",r=r.concat(iO(e.serverSyncTree_,d.currentWriteId,!0))}}i5(e.eventQueue_,n,r),r=[],g&&(t[a].status=2,setTimeout(c=t[a].unwatcher,Math.floor(0)),t[a].onComplete&&("nodata"===m?i.push(()=>t[a].onComplete(null,!1,t[a].currentInputSnapshot)):i.push(()=>t[a].onComplete(Error(m),!1,null))))}rh(e,e.transactionQueueTree_);for(let E=0;E<i.length;E++)tb(i[E]);(function e(t,n=t.transactionQueueTree_){if(n||rh(t,n),iG(n)){let i=rl(t,n);(0,p.hu)(i.length>0,"Sending zero length transaction queue");let r=i.every(e=>0===e.status);r&&function(t,n,i){let r=i.map(e=>e.currentWriteId),s=rs(t,n,r),o=s,a=s.hash();for(let l=0;l<i.length;l++){let h=i[l];(0,p.hu)(0===h.status,"tryToSendTransactionQueue_: items in queue should all be run."),h.status=1,h.retryCount++;let u=t4(n,h.path);o=o.updateChild(u,h.currentOutputSnapshotRaw)}let c=o.val(!0);t.server_.put(n.toString(),c,r=>{rr(t,"transaction put response",{path:n.toString(),status:r});let s=[];if("ok"===r){let o=[];for(let a=0;a<i.length;a++)i[a].status=2,s=s.concat(iO(t.serverSyncTree_,i[a].currentWriteId)),i[a].onComplete&&o.push(()=>i[a].onComplete(null,!0,i[a].currentOutputSnapshotResolved)),i[a].unwatcher();rh(t,iK(t.transactionQueueTree_,n)),e(t,t.transactionQueueTree_),i5(t.eventQueue_,n,s);for(let l=0;l<o.length;l++)tb(o[l])}else{if("datastale"===r)for(let h=0;h<i.length;h++)3===i[h].status?i[h].status=4:i[h].status=0;else{to("transaction at "+n.toString()+" failed: "+r);for(let u=0;u<i.length;u++)i[u].status=4,i[u].abortReason=r}ro(t,n)}},a)}(t,iJ(n),i)}else iY(n)&&iX(n,n=>{e(t,n)})})(e,e.transactionQueueTree_)}(e,r,i),i}function ra(e,t){let n,i=e.transactionQueueTree_;for(n=tQ(t);null!==n&&void 0===iG(i);)i=iK(i,n),t=tX(t),n=tQ(t);return i}function rl(e,t){let n=[];return function e(t,n,i){let r=iG(n);if(r)for(let s=0;s<r.length;s++)i.push(r[s]);iX(n,n=>{e(t,n,i)})}(e,t,n),n.sort((e,t)=>e.order-t.order),n}function rh(e,t){let n=iG(t);if(n){let i=0;for(let r=0;r<n.length;r++)2!==n[r].status&&(n[i]=n[r],i++);n.length=i,iQ(t,n.length>0?n:void 0)}iX(t,t=>{rh(e,t)})}function ru(e,t){let n=iG(t);if(n){let i=[],r=[],s=-1;for(let o=0;o<n.length;o++)3===n[o].status||(1===n[o].status?((0,p.hu)(s===o-1,"All SENT items should be at beginning of queue."),s=o,n[o].status=3,n[o].abortReason="set"):((0,p.hu)(0===n[o].status,"Unexpected transaction status in abort"),n[o].unwatcher(),r=r.concat(iO(e.serverSyncTree_,n[o].currentWriteId,!0)),n[o].onComplete&&i.push(n[o].onComplete.bind(null,Error("set"),!1,null))));-1===s?iQ(t,void 0):n.length=s+1,i5(e.eventQueue_,iJ(t),r);for(let a=0;a<i.length;a++)tb(i[a])}}let rc=function(e,t){let n=rd(e),i=n.namespace;"firebase.com"===n.domain&&ts(n.host+" is no longer supported. Please use <YOUR FIREBASE>.firebaseio.com instead"),i&&"undefined"!==i||"localhost"===n.domain||ts("Cannot parse Firebase url. Please use https://<YOUR FIREBASE>.firebaseio.com"),n.secure||ta();let r="ws"===n.scheme||"wss"===n.scheme;return{repoInfo:new tA(n.host,n.secure,i,r,t,"",i!==n.subdomain),path:new tK(n.pathString)}},rd=function(e){let t="",n="",i="",r="",s="",o=!0,a="https",l=443;if("string"==typeof e){let h=e.indexOf("//");h>=0&&(a=e.substring(0,h-1),e=e.substring(h+2));let u=e.indexOf("/");-1===u&&(u=e.length);let c=e.indexOf("?");-1===c&&(c=e.length),t=e.substring(0,Math.min(u,c)),u<c&&(r=/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){let t="",n=e.split("/");for(let i=0;i<n.length;i++)if(n[i].length>0){let r=n[i];try{r=decodeURIComponent(r.replace(/\+/g," "))}catch(s){}t+="/"+r}return t}(e.substring(u,c)));let d=function(e){let t={};for(let n of("?"===e.charAt(0)&&(e=e.substring(1)),e.split("&"))){if(0===n.length)continue;let i=n.split("=");2===i.length?t[decodeURIComponent(i[0])]=decodeURIComponent(i[1]):to(`Invalid query segment '${n}' in query '${e}'`)}return t}(e.substring(Math.min(e.length,c)));(h=t.indexOf(":"))>=0?(o="https"===a||"wss"===a,l=parseInt(t.substring(h+1),10)):h=t.length;let f=t.slice(0,h);if("localhost"===f.toLowerCase())n="localhost";else if(f.split(".").length<=2)n=f;else{let p=t.indexOf(".");i=t.substring(0,p).toLowerCase(),n=t.substring(p+1),s=i}"ns"in d&&(s=d.ns)}return{host:t,port:l,domain:n,subdomain:i,secure:o,scheme:a,pathString:r,namespace:s}},rf="-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz";!function(){let e=0,t=[];return function(n){let i=n===e;e=n;let r,s=Array(8);for(r=7;r>=0;r--)s[r]=rf.charAt(n%64),n=Math.floor(n/64);(0,p.hu)(0===n,"Cannot push at time == 0");let o=s.join("");if(i){for(r=11;r>=0&&63===t[r];r--)t[r]=0;t[r]++}else for(r=0;r<12;r++)t[r]=Math.floor(64*Math.random());for(r=0;r<12;r++)o+=rf.charAt(t[r]);return(0,p.hu)(20===o.length,"nextPushId: Length should be 20."),o}}();/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rp{constructor(e,t,n,i){this._repo=e,this._path=t,this._queryParams=n,this._orderByCalled=i}get key(){return t2(this._path)?null:tJ(this._path)}get ref(){return new rg(this._repo,this._path)}get _queryIdentifier(){let e=nx(this._queryParams),t=tg(e);return"{}"===t?"default":t}get _queryObject(){return nx(this._queryParams)}isEqual(e){if(!((e=(0,p.m9)(e))instanceof rp))return!1;let t=this._repo===e._repo,n=t9(this._path,e._path),i=this._queryIdentifier===e._queryIdentifier;return t&&n&&i}toJSON(){return this.toString()}toString(){return this._repo.toString()+function(e){let t="";for(let n=e.pieceNum_;n<e.pieces_.length;n++)""!==e.pieces_[n]&&(t+="/"+encodeURIComponent(String(e.pieces_[n])));return t||"/"}(this._path)}}class rg extends rp{constructor(e,t){super(e,t,new nP,!1)}get parent(){let e=t0(this._path);return null===e?null:new rg(this._repo,e)}get root(){let e=this;for(;null!==e.parent;)e=e.parent;return e}}(0,p.hu)(!ik,"__referenceConstructor has already been defined"),ik=rg,(0,p.hu)(!iA,"__referenceConstructor has already been defined"),iA=rg;let rm={};class r_{constructor(e,t){this._repoInternal=e,this.app=t,this.type="database",this._instanceStarted=!1}get _repo(){return this._instanceStarted||(function(e,t,n){if(e.stats_=tL(e.repoInfo_),e.forceRestClient_||tT())e.server_=new nL(e.repoInfo_,(t,n,i,r)=>{re(e,t,n,i,r)},e.authTokenProvider_,e.appCheckProvider_),setTimeout(()=>rt(e,!0),0);else{if(null!=n){if("object"!=typeof n)throw Error("Only objects are supported for option databaseAuthVariableOverride");try{(0,p.Wl)(n)}catch(i){throw Error("Invalid authOverride provided: "+i)}}e.persistentConnection_=new ne(e.repoInfo_,t,(t,n,i,r)=>{re(e,t,n,i,r)},t=>{rt(e,t)},t=>{var n,i;n=e,i=t,t_(i,(e,t)=>{rn(n,e,t)})},e.authTokenProvider_,e.appCheckProvider_,n),e.server_=e.persistentConnection_}e.authTokenProvider_.addTokenChangeListener(t=>{e.server_.refreshAuthToken(t)}),e.appCheckProvider_.addTokenChangeListener(t=>{e.server_.refreshAppCheckToken(t.token)}),e.statsReporter_=function(e,t){let n=e.toString();return tx[n]||(tx[n]=t()),tx[n]}(e.repoInfo_,()=>new nj(e.stats_,e.server_)),e.infoData_=new nM,e.infoSyncTree_=new iD({startListening(t,n,i,r){let s=[],o=e.infoData_.getNode(t._path);return o.isEmpty()||(s=ix(e.infoSyncTree_,t._path,o),setTimeout(()=>{r("ok")},0)),s},stopListening(){}}),rn(e,"connected",!1),e.serverSyncTree_=new iD({startListening:(t,n,i,r)=>(e.server_.listen(t,i,n,(n,i)=>{let s=r(n,i);i5(e.eventQueue_,t._path,s)}),[]),stopListening(t,n){e.server_.unlisten(t,n)}})}(this._repoInternal,this.app.options.appId,this.app.options.databaseAuthVariableOverride),this._instanceStarted=!0),this._repoInternal}get _root(){return this._rootInternal||(this._rootInternal=new rg(this._repo,tG())),this._rootInternal}_delete(){return null!==this._rootInternal&&(function(e,t){var n;let i=rm[t];i&&i[e.key]===e||ts(`Database ${t}(${e.repoInfo_}) has already been deleted.`),e.persistentConnection_&&e.persistentConnection_.interrupt("repo_interrupt"),delete i[e.key]}(this._repo,this.app.name),this._repoInternal=null,this._rootInternal=null),Promise.resolve()}_checkNotDeleted(e){null===this._rootInternal&&ts("Cannot call "+e+" on a deleted database.")}}ne.prototype.simpleListen=function(e,t){this.sendRequest("q",{p:e},t)},ne.prototype.echo=function(e,t){this.sendRequest("echo",{d:e},t)},eJ=u=d.Jn,(0,d.Xd)(new g.wA("database",(e,{instanceIdentifier:t})=>{let n=e.getProvider("app").getImmediate(),i=e.getProvider("auth-internal"),r=e.getProvider("app-check-internal");return function(e,t,n,i,r){var s,o,a,l;let h=i||e.options.databaseURL;void 0===h&&(e.options.projectId||ts("Can't determine Firebase Database URL. Be sure to include  a Project ID when calling firebase.initializeApp()."),tn("Using default host for project ",e.options.projectId),h=`${e.options.projectId}-default-rtdb.firebaseio.com`);let u=rc(h,r),c=u.repoInfo,d,f;void 0!==eQ&&eQ.env&&(f=eQ.env.FIREBASE_DATABASE_EMULATOR_HOST),f?(d=!0,c=(u=rc(h=`http://${f}?ns=${c.namespace}`,r)).repoInfo):d=!u.repoInfo.secure;let p=r&&d?new tS(tS.OWNER):new tC(e.name,e.options,t);i9("Invalid Firebase Database URL",u),t2(u.path)||ts("Database URL must point to the root of a Firebase Database (not including a child path).");let g,m,_=(s=c,o=e,a=p,l=new tE(e.name,n),g=rm[o.name],g||(g={},rm[o.name]=g),m=g[s.toURLString()],m&&ts("Database initialized multiple times. Please make sure the format of the database URL matches with each database() call."),m=new i7(s,!1,a,l),g[s.toURLString()]=m,m);return new r_(_,e)}(n,i,r,t)},"PUBLIC").setMultipleInstances(!0)),(0,d.KN)(eY,eX,void 0),(0,d.KN)(eY,eX,"esm2017");var ry=n(6100),rv=n(6650),rw=(0,d.ZF)({apiKey:"AIzaSyApVndG5ivlqqQI4S51jGe62HFb86dkqCI",authDomain:"obuobafm-a1c6c.firebaseapp.com",projectId:"obuobafm-a1c6c",storageBucket:"obuobafm-a1c6c.appspot.com",messagingSenderId:"490975383648",appId:"1:490975383648:web:2d8e96cda3da559f3af305",measurementId:"G-SGS0Q50J9V"}),rb=(0,eG.v0)(rw);!function(e=(0,d.Mq)(),t){let n=(0,d.qX)(e,"database").getImmediate({identifier:void 0});if(!n._instanceStarted){let i=(0,p.P0)("database");i&&function(e,t,n,i={}){var r,s,o,a;(e=(0,p.m9)(e))._checkNotDeleted("useEmulator"),e._instanceStarted&&ts("Cannot call useEmulator() after instance has already been initialized.");let l=e._repoInternal,h;if(l.repoInfo_.nodeAdmin)i.mockUserToken&&ts('mockUserToken is not supported by the Admin SDK. For client access with mock users, please use the "firebase" package instead of "firebase-admin".'),h=new tS(tS.OWNER);else if(i.mockUserToken){let u="string"==typeof i.mockUserToken?i.mockUserToken:(0,p.Sg)(i.mockUserToken,e.app.options.projectId);h=new tS(u)}r=l,a=h,r.repoInfo_=new tA(`${t}:${n}`,!1,r.repoInfo_.namespace,r.repoInfo_.webSocketOnly,r.repoInfo_.nodeAdmin,r.repoInfo_.persistenceKey,r.repoInfo_.includeNamespaceInQueryParams,!0),a&&(r.authTokenProvider_=a)}(n,...i)}return n}(rw);var rT=(0,ry.ad)(rw),rI=(0,rv.cF)(rw)},608:function(e,t,n){"use strict";n.r(t);var i=n(5893),r=n(2373),s=function(){var e=(0,r.useLoader)().loader;return(0,i.jsx)("section",{style:e?{display:"flex"}:{display:"none"},className:"loader",children:(0,i.jsxs)("div",{children:[(0,i.jsx)("small",{}),(0,i.jsx)("small",{}),(0,i.jsx)("small",{})]})})};t.default=s},2373:function(e,t,n){"use strict";function i(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}n.r(t),n.d(t,{LoaderProvider:function(){return u},PlayingProvider:function(){return f},default:function(){return g},useLoader:function(){return c},usePlaying:function(){return p}});var r=n(5893),s=n(9008),o=n.n(s);n(906);var a=n(608),l=n(7294);n(9915),n(6786);var h=(0,l.createContext)(),u=function(e){var t=e.children,n=(0,l.useState)(!0),i=n[0],s=n[1];return(0,r.jsx)(h.Provider,{value:{loader:i,setLoader:s},children:t})},c=function(){return(0,l.useContext)(h)},d=(0,l.createContext)(),f=function(e){var t=e.children,n=(0,l.useState)(!1),i=n[0],s=n[1];return(0,r.jsx)(d.Provider,{value:{playing:i,setPlaying:s},children:t})},p=function(){return(0,l.useContext)(d)},g=function(e){var t=e.Component,n=e.pageProps;return(0,r.jsx)(u,{children:(0,r.jsxs)(f,{children:[(0,r.jsxs)(o(),{children:[(0,r.jsx)("script",{src:"https://it.fontawesome.com/eb75260fb3.js",crossorigin:"anonymous",async:!0}),(0,r.jsx)("link",{rel:"stylesheet",href:"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0"})]}),(0,r.jsx)(a.default,{}),(0,r.jsx)(t,function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){i(e,t,n[t])})}return e}({},n))]})})}},906:function(){},7663:function(e){!function(){var t={229:function(e){var t,n,i,r=e.exports={};function s(){throw Error("setTimeout has not been defined")}function o(){throw Error("clearTimeout has not been defined")}function a(e){if(t===setTimeout)return setTimeout(e,0);if((t===s||!t)&&setTimeout)return t=setTimeout,setTimeout(e,0);try{return t(e,0)}catch(i){try{return t.call(null,e,0)}catch(n){return t.call(this,e,0)}}}!function(){try{t="function"==typeof setTimeout?setTimeout:s}catch(e){t=s}try{n="function"==typeof clearTimeout?clearTimeout:o}catch(i){n=o}}();var l=[],h=!1,u=-1;function c(){h&&i&&(h=!1,i.length?l=i.concat(l):u=-1,l.length&&d())}function d(){if(!h){var e=a(c);h=!0;for(var t=l.length;t;){for(i=l,l=[];++u<t;)i&&i[u].run();u=-1,t=l.length}i=null,h=!1,function(e){if(n===clearTimeout)return clearTimeout(e);if((n===o||!n)&&clearTimeout)return n=clearTimeout,clearTimeout(e);try{n(e)}catch(i){try{return n.call(null,e)}catch(t){return n.call(this,e)}}}(e)}}function f(e,t){this.fun=e,this.array=t}function p(){}r.nextTick=function(e){var t=Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n];l.push(new f(e,t)),1!==l.length||h||a(d)},f.prototype.run=function(){this.fun.apply(null,this.array)},r.title="browser",r.browser=!0,r.env={},r.argv=[],r.version="",r.versions={},r.on=p,r.addListener=p,r.once=p,r.off=p,r.removeListener=p,r.removeAllListeners=p,r.emit=p,r.prependListener=p,r.prependOnceListener=p,r.listeners=function(e){return[]},r.binding=function(e){throw Error("process.binding is not supported")},r.cwd=function(){return"/"},r.chdir=function(e){throw Error("process.chdir is not supported")},r.umask=function(){return 0}}},n={};function i(e){var r=n[e];if(void 0!==r)return r.exports;var s=n[e]={exports:{}},o=!0;try{t[e](s,s.exports,i),o=!1}finally{o&&delete n[e]}return s.exports}i.ab="//";var r=i(229);e.exports=r}()},9008:function(e,t,n){e.exports=n(5443)},5816:function(e,t,n){"use strict";n.d(t,{Jn:function(){return L},qX:function(){return P},Xd:function(){return D},Mq:function(){return F},ZF:function(){return M},KN:function(){return U}});var i,r=n(8463),s=n(3333),o=n(4444);let a=(e,t)=>t.some(t=>e instanceof t),l,h,u=new WeakMap,c=new WeakMap,d=new WeakMap,f=new WeakMap,p=new WeakMap,g={get(e,t,n){if(e instanceof IDBTransaction){if("done"===t)return c.get(e);if("objectStoreNames"===t)return e.objectStoreNames||d.get(e);if("store"===t)return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return m(e[t])},set:(e,t,n)=>(e[t]=n,!0),has:(e,t)=>e instanceof IDBTransaction&&("done"===t||"store"===t)||t in e};function m(e){if(e instanceof IDBRequest)return function(e){let t=new Promise((t,n)=>{let i=()=>{e.removeEventListener("success",r),e.removeEventListener("error",s)},r=()=>{t(m(e.result)),i()},s=()=>{n(e.error),i()};e.addEventListener("success",r),e.addEventListener("error",s)});return t.then(t=>{t instanceof IDBCursor&&u.set(t,e)}).catch(()=>{}),p.set(t,e),t}(e);if(f.has(e))return f.get(e);let t=function(e){if("function"==typeof e){var t;return e!==IDBDatabase.prototype.transaction||"objectStoreNames"in IDBTransaction.prototype?(h||(h=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey,])).includes(e)?function(...t){return e.apply(_(this),t),m(u.get(this))}:function(...t){return m(e.apply(_(this),t))}:function(t,...n){let i=e.call(_(this),t,...n);return d.set(i,t.sort?t.sort():[t]),m(i)}}return(e instanceof IDBTransaction&&function(e){if(c.has(e))return;let t=new Promise((t,n)=>{let i=()=>{e.removeEventListener("complete",r),e.removeEventListener("error",s),e.removeEventListener("abort",s)},r=()=>{t(),i()},s=()=>{n(e.error||new DOMException("AbortError","AbortError")),i()};e.addEventListener("complete",r),e.addEventListener("error",s),e.addEventListener("abort",s)});c.set(e,t)}(e),a(e,l||(l=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction,])))?new Proxy(e,g):e}(e);return t!==e&&(f.set(e,t),p.set(t,e)),t}let _=e=>p.get(e),y=["get","getKey","getAll","getAllKeys","count"],v=["put","add","delete","clear"],w=new Map;function b(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&"string"==typeof t))return;if(w.get(t))return w.get(t);let n=t.replace(/FromIndex$/,""),i=t!==n,r=v.includes(n);if(!(n in(i?IDBIndex:IDBObjectStore).prototype)||!(r||y.includes(n)))return;let s=async function(e,...t){let s=this.transaction(e,r?"readwrite":"readonly"),o=s.store;return i&&(o=o.index(t.shift())),(await Promise.all([o[n](...t),r&&s.done,]))[0]};return w.set(t,s),s}g=(i=e=>({...e,get:(t,n,i)=>b(t,n)||e.get(t,n,i),has:(t,n)=>!!b(t,n)||e.has(t,n)}))(g);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class T{constructor(e){this.container=e}getPlatformInfoString(){let e=this.container.getProviders();return e.map(e=>{if(!function(e){let t=e.getComponent();return(null==t?void 0:t.type)==="VERSION"}(e))return null;{let t=e.getImmediate();return`${t.library}/${t.version}`}}).filter(e=>e).join(" ")}}let I="@firebase/app",E="0.9.20",C=new s.Yd("@firebase/app"),S="[DEFAULT]",k={[I]:"fire-core","@firebase/app-compat":"fire-core-compat","@firebase/analytics":"fire-analytics","@firebase/analytics-compat":"fire-analytics-compat","@firebase/app-check":"fire-app-check","@firebase/app-check-compat":"fire-app-check-compat","@firebase/auth":"fire-auth","@firebase/auth-compat":"fire-auth-compat","@firebase/database":"fire-rtdb","@firebase/database-compat":"fire-rtdb-compat","@firebase/functions":"fire-fn","@firebase/functions-compat":"fire-fn-compat","@firebase/installations":"fire-iid","@firebase/installations-compat":"fire-iid-compat","@firebase/messaging":"fire-fcm","@firebase/messaging-compat":"fire-fcm-compat","@firebase/performance":"fire-perf","@firebase/performance-compat":"fire-perf-compat","@firebase/remote-config":"fire-rc","@firebase/remote-config-compat":"fire-rc-compat","@firebase/storage":"fire-gcs","@firebase/storage-compat":"fire-gcs-compat","@firebase/firestore":"fire-fst","@firebase/firestore-compat":"fire-fst-compat","fire-js":"fire-js",firebase:"fire-js-all"},N=new Map,R=new Map;function A(e,t){try{e.container.addComponent(t)}catch(n){C.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function D(e){let t=e.name;if(R.has(t))return C.debug(`There were multiple attempts to register component ${t}.`),!1;for(let n of(R.set(t,e),N.values()))A(n,e);return!0}function P(e,t){let n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}let O=new o.LL("app","Firebase",{"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}."});/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class x{constructor(e,t,n){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new r.wA("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw O.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let L="10.5.0";function M(e,t={}){let n=e;if("object"!=typeof t){let i=t;t={name:i}}let s=Object.assign({name:S,automaticDataCollectionEnabled:!1},t),a=s.name;if("string"!=typeof a||!a)throw O.create("bad-app-name",{appName:String(a)});if(n||(n=(0,o.aH)()),!n)throw O.create("no-options");let l=N.get(a);if(l){if((0,o.vZ)(n,l.options)&&(0,o.vZ)(s,l.config))return l;throw O.create("duplicate-app",{appName:a})}let h=new r.H0(a);for(let u of R.values())h.addComponent(u);let c=new x(n,s,h);return N.set(a,c),c}function F(e=S){let t=N.get(e);if(!t&&e===S&&(0,o.aH)())return M();if(!t)throw O.create("no-app",{appName:e});return t}function U(e,t,n){var i;let s=null!==(i=k[e])&&void 0!==i?i:e;n&&(s+=`-${n}`);let o=s.match(/\s|\//),a=t.match(/\s|\//);if(o||a){let l=[`Unable to register library "${s}" with version "${t}":`];o&&l.push(`library name "${s}" contains illegal characters (whitespace or "/")`),o&&a&&l.push("and"),a&&l.push(`version name "${t}" contains illegal characters (whitespace or "/")`),C.warn(l.join(" "));return}D(new r.wA(`${s}-version`,()=>({library:s,version:t}),"VERSION"))}let V="firebase-heartbeat-store",j=null;function q(){return j||(j=(function(e,t,{blocked:n,upgrade:i,blocking:r,terminated:s}={}){let o=indexedDB.open(e,1),a=m(o);return i&&o.addEventListener("upgradeneeded",e=>{i(m(o.result),e.oldVersion,e.newVersion,m(o.transaction),e)}),n&&o.addEventListener("blocked",e=>n(e.oldVersion,e.newVersion,e)),a.then(e=>{s&&e.addEventListener("close",()=>s()),r&&e.addEventListener("versionchange",e=>r(e.oldVersion,e.newVersion,e))}).catch(()=>{}),a})("firebase-heartbeat-database",1,{upgrade(e,t){0===t&&e.createObjectStore(V)}}).catch(e=>{throw O.create("idb-open",{originalErrorMessage:e.message})})),j}async function B(e){try{let t=await q(),n=await t.transaction(V).objectStore(V).get($(e));return n}catch(r){if(r instanceof o.ZR)C.warn(r.message);else{let i=O.create("idb-get",{originalErrorMessage:null==r?void 0:r.message});C.warn(i.message)}}}async function z(e,t){try{let n=await q(),i=n.transaction(V,"readwrite"),r=i.objectStore(V);await r.put(t,$(e)),await i.done}catch(a){if(a instanceof o.ZR)C.warn(a.message);else{let s=O.create("idb-set",{originalErrorMessage:null==a?void 0:a.message});C.warn(s.message)}}}function $(e){return`${e.name}!${e.options.appId}`}class W{constructor(e){this.container=e,this._heartbeatsCache=null;let t=this.container.getProvider("app").getImmediate();this._storage=new K(t),this._heartbeatsCachePromise=this._storage.read().then(e=>(this._heartbeatsCache=e,e))}async triggerHeartbeat(){let e=this.container.getProvider("platform-logger").getImmediate(),t=e.getPlatformInfoString(),n=H();return(null===this._heartbeatsCache&&(this._heartbeatsCache=await this._heartbeatsCachePromise),this._heartbeatsCache.lastSentHeartbeatDate===n||this._heartbeatsCache.heartbeats.some(e=>e.date===n))?void 0:(this._heartbeatsCache.heartbeats.push({date:n,agent:t}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(e=>{let t=new Date(e.date).valueOf(),n=Date.now();return n-t<=2592e6}),this._storage.overwrite(this._heartbeatsCache))}async getHeartbeatsHeader(){if(null===this._heartbeatsCache&&await this._heartbeatsCachePromise,null===this._heartbeatsCache||0===this._heartbeatsCache.heartbeats.length)return"";let e=H(),{heartbeatsToSend:t,unsentEntries:n}=function(e,t=1024){let n=[],i=e.slice();for(let r of e){let s=n.find(e=>e.agent===r.agent);if(s){if(s.dates.push(r.date),G(n)>t){s.dates.pop();break}}else if(n.push({agent:r.agent,dates:[r.date]}),G(n)>t){n.pop();break}i=i.slice(1)}return{heartbeatsToSend:n,unsentEntries:i}}(this._heartbeatsCache.heartbeats),i=(0,o.L)(JSON.stringify({version:2,heartbeats:t}));return this._heartbeatsCache.lastSentHeartbeatDate=e,n.length>0?(this._heartbeatsCache.heartbeats=n,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}}function H(){let e=new Date;return e.toISOString().substring(0,10)}class K{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return!!(0,o.hl)()&&(0,o.eu)().then(()=>!0).catch(()=>!1)}async read(){let e=await this._canUseIndexedDBPromise;if(!e)return{heartbeats:[]};{let t=await B(this.app);return t||{heartbeats:[]}}}async overwrite(e){var t;let n=await this._canUseIndexedDBPromise;if(n){let i=await this.read();return z(this.app,{lastSentHeartbeatDate:null!==(t=e.lastSentHeartbeatDate)&&void 0!==t?t:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}}async add(e){var t;let n=await this._canUseIndexedDBPromise;if(n){let i=await this.read();return z(this.app,{lastSentHeartbeatDate:null!==(t=e.lastSentHeartbeatDate)&&void 0!==t?t:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}}}function G(e){return(0,o.L)(JSON.stringify({version:2,heartbeats:e})).length}D(new r.wA("platform-logger",e=>new T(e),"PRIVATE")),D(new r.wA("heartbeat",e=>new W(e),"PRIVATE")),U(I,E,""),U(I,E,"esm2017"),U("fire-js","")},8463:function(e,t,n){"use strict";n.d(t,{H0:function(){return a},wA:function(){return r}});var i=n(4444);class r{constructor(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let s="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class o{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){let t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){let n=new i.BH;if(this.instancesDeferred.set(t,n),this.isInitialized(t)||this.shouldAutoInitialize())try{let r=this.getOrInitializeService({instanceIdentifier:t});r&&n.resolve(r)}catch(s){}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;let n=this.normalizeInstanceIdentifier(null==e?void 0:e.identifier),i=null!==(t=null==e?void 0:e.optional)&&void 0!==t&&t;if(this.isInitialized(n)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:n})}catch(r){if(i)return null;throw r}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,this.shouldAutoInitialize()){var t;if(t=e,"EAGER"===t.instantiationMode)try{this.getOrInitializeService({instanceIdentifier:s})}catch(n){}for(let[i,r]of this.instancesDeferred.entries()){let o=this.normalizeInstanceIdentifier(i);try{let a=this.getOrInitializeService({instanceIdentifier:o});r.resolve(a)}catch(l){}}}}clearInstance(e=s){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){let e=Array.from(this.instances.values());await Promise.all([...e.filter(e=>"INTERNAL"in e).map(e=>e.INTERNAL.delete()),...e.filter(e=>"_delete"in e).map(e=>e._delete())])}isComponentSet(){return null!=this.component}isInitialized(e=s){return this.instances.has(e)}getOptions(e=s){return this.instancesOptions.get(e)||{}}initialize(e={}){let{options:t={}}=e,n=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);let i=this.getOrInitializeService({instanceIdentifier:n,options:t});for(let[r,s]of this.instancesDeferred.entries()){let o=this.normalizeInstanceIdentifier(r);n===o&&s.resolve(i)}return i}onInit(e,t){var n;let i=this.normalizeInstanceIdentifier(t),r=null!==(n=this.onInitCallbacks.get(i))&&void 0!==n?n:new Set;r.add(e),this.onInitCallbacks.set(i,r);let s=this.instances.get(i);return s&&e(s,i),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){let n=this.onInitCallbacks.get(t);if(n)for(let i of n)try{i(e,t)}catch(r){}}getOrInitializeService({instanceIdentifier:e,options:t={}}){var n;let i=this.instances.get(e);if(!i&&this.component&&(i=this.component.instanceFactory(this.container,{instanceIdentifier:(n=e,n===s?void 0:n),options:t}),this.instances.set(e,i),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(i,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,i)}catch(r){}return i||null}normalizeInstanceIdentifier(e=s){return this.component?this.component.multipleInstances?e:s:e}shouldAutoInitialize(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class a{constructor(e){this.name=e,this.providers=new Map}addComponent(e){let t=this.getProvider(e.name);if(t.isComponentSet())throw Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){let t=this.getProvider(e.name);t.isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);let t=new o(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}},3333:function(e,t,n){"use strict";var i,r;n.d(t,{Yd:function(){return u},in:function(){return i}});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let s=[];(r=i||(i={}))[r.DEBUG=0]="DEBUG",r[r.VERBOSE=1]="VERBOSE",r[r.INFO=2]="INFO",r[r.WARN=3]="WARN",r[r.ERROR=4]="ERROR",r[r.SILENT=5]="SILENT";let o={debug:i.DEBUG,verbose:i.VERBOSE,info:i.INFO,warn:i.WARN,error:i.ERROR,silent:i.SILENT},a=i.INFO,l={[i.DEBUG]:"log",[i.VERBOSE]:"log",[i.INFO]:"info",[i.WARN]:"warn",[i.ERROR]:"error"},h=(e,t,...n)=>{if(t<e.logLevel)return;let i=new Date().toISOString(),r=l[t];if(r)console[r](`[${i}]  ${e.name}:`,...n);else throw Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class u{constructor(e){this.name=e,this._logLevel=a,this._logHandler=h,this._userLogHandler=null,s.push(this)}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in i))throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel="string"==typeof e?o[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if("function"!=typeof e)throw TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,i.DEBUG,...e),this._logHandler(this,i.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,i.VERBOSE,...e),this._logHandler(this,i.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,i.INFO,...e),this._logHandler(this,i.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,i.WARN,...e),this._logHandler(this,i.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,i.ERROR,...e),this._logHandler(this,i.ERROR,...e)}}},9915:function(e,t,n){"use strict";n.d(t,{v0:function(){return t2},Aj:function(){return e4},e5:function(){return e2},w7:function(){return e9}});var i,r=n(4444),s=n(5816),o=n(3333),a=n(7582),l=n(8463);function h(e){return void 0!==e&&void 0!==e.enterprise}class u{constructor(e){if(this.siteKey="",this.emailPasswordEnabled=!1,void 0===e.recaptchaKey)throw Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.emailPasswordEnabled=e.recaptchaEnforcementState.some(e=>"EMAIL_PASSWORD_PROVIDER"===e.provider&&"OFF"!==e.enforcementState)}}function c(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}let d=new r.LL("auth","Firebase",c()),f=new o.Yd("@firebase/auth");function p(e,...t){f.logLevel<=o.in.ERROR&&f.error(`Auth (${s.Jn}): ${e}`,...t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function g(e,...t){throw _(e,...t)}function m(e,...t){return _(e,...t)}function _(e,...t){if("string"!=typeof e){let n=t[0],i=[...t.slice(1)];return i[0]&&(i[0].appName=e.name),e._errorFactory.create(n,...i)}return d.create(e,...t)}function y(e,t,...n){if(!e)throw _(t,...n)}function v(e){let t="INTERNAL ASSERTION FAILED: "+e;throw p(t),Error(t)}function w(e,t){e||v(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function b(){var e;return"undefined"!=typeof self&&(null===(e=self.location)||void 0===e?void 0:e.href)||""}function T(){var e;return"undefined"!=typeof self&&(null===(e=self.location)||void 0===e?void 0:e.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class I{constructor(e,t){this.shortDelay=e,this.longDelay=t,w(t>e,"Short delay should be less than long delay!"),this.isMobile=(0,r.uI)()||(0,r.b$)()}get(){return!("undefined"!=typeof navigator&&navigator&&"onLine"in navigator&&"boolean"==typeof navigator.onLine&&("http:"===T()||"https:"===T()||(0,r.ru)()||"connection"in navigator))||navigator.onLine?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function E(e,t){w(e.emulator,"Emulator should always be set here");let{url:n}=e.emulator;return t?`${n}${t.startsWith("/")?t.slice(1):t}`:n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class C{static initialize(e,t,n){this.fetchImpl=e,t&&(this.headersImpl=t),n&&(this.responseImpl=n)}static fetch(){return this.fetchImpl?this.fetchImpl:"undefined"!=typeof self&&"fetch"in self?self.fetch:void v("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){return this.headersImpl?this.headersImpl:"undefined"!=typeof self&&"Headers"in self?self.Headers:void v("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){return this.responseImpl?this.responseImpl:"undefined"!=typeof self&&"Response"in self?self.Response:void v("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let S={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"},k=new I(3e4,6e4);function N(e,t){return e.tenantId&&!t.tenantId?Object.assign(Object.assign({},t),{tenantId:e.tenantId}):t}async function R(e,t,n,i,s={}){return A(e,s,async()=>{let s={},o={};i&&("GET"===t?o=i:s={body:JSON.stringify(i)});let a=(0,r.xO)(Object.assign({key:e.config.apiKey},o)).slice(1),l=await e._getAdditionalHeaders();return l["Content-Type"]="application/json",e.languageCode&&(l["X-Firebase-Locale"]=e.languageCode),C.fetch()(P(e,e.config.apiHost,n,a),Object.assign({method:t,headers:l,referrerPolicy:"no-referrer"},s))})}async function A(e,t,n){e._canInitEmulator=!1;let i=Object.assign(Object.assign({},S),t);try{let s=new O(e),o=await Promise.race([n(),s.promise]);s.clearNetworkTimeout();let a=await o.json();if("needConfirmation"in a)throw x(e,"account-exists-with-different-credential",a);if(o.ok&&!("errorMessage"in a))return a;{let l=o.ok?a.errorMessage:a.error.message,[h,u]=l.split(" : ");if("FEDERATED_USER_ID_ALREADY_LINKED"===h)throw x(e,"credential-already-in-use",a);if("EMAIL_EXISTS"===h)throw x(e,"email-already-in-use",a);if("USER_DISABLED"===h)throw x(e,"user-disabled",a);let d=i[h]||h.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw function(e,t,n){let i=Object.assign(Object.assign({},c()),{[t]:n}),s=new r.LL("auth","Firebase",i);return s.create(t,{appName:e.name})}(e,d,u);g(e,d)}}catch(f){if(f instanceof r.ZR)throw f;g(e,"network-request-failed",{message:String(f)})}}async function D(e,t,n,i,r={}){let s=await R(e,t,n,i,r);return"mfaPendingCredential"in s&&g(e,"multi-factor-auth-required",{_serverResponse:s}),s}function P(e,t,n,i){let r=`${t}${n}?${i}`;return e.config.emulator?E(e.config,r):`${e.config.apiScheme}://${r}`}class O{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((e,t)=>{this.timer=setTimeout(()=>t(m(this.auth,"network-request-failed")),k.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function x(e,t,n){let i={appName:e.name};n.email&&(i.email=n.email),n.phoneNumber&&(i.phoneNumber=n.phoneNumber);let r=m(e,t,i);return r.customData._tokenResponse=n,r}async function L(e,t){return R(e,"GET","/v2/recaptchaConfig",N(e,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function M(e,t){return R(e,"POST","/v1/accounts:delete",t)}async function F(e,t){return R(e,"POST","/v1/accounts:lookup",t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function U(e){if(e)try{let t=new Date(Number(e));if(!isNaN(t.getTime()))return t.toUTCString()}catch(n){}}async function V(e,t=!1){let n=(0,r.m9)(e),i=await n.getIdToken(t),s=q(i);y(s&&s.exp&&s.auth_time&&s.iat,n.auth,"internal-error");let o="object"==typeof s.firebase?s.firebase:void 0,a=null==o?void 0:o.sign_in_provider;return{claims:s,token:i,authTime:U(j(s.auth_time)),issuedAtTime:U(j(s.iat)),expirationTime:U(j(s.exp)),signInProvider:a||null,signInSecondFactor:(null==o?void 0:o.sign_in_second_factor)||null}}function j(e){return 1e3*Number(e)}function q(e){let[t,n,i]=e.split(".");if(void 0===t||void 0===n||void 0===i)return p("JWT malformed, contained fewer than 3 sections"),null;try{let s=(0,r.tV)(n);if(!s)return p("Failed to decode base64 JWT payload"),null;return JSON.parse(s)}catch(o){return p("Caught error parsing JWT payload as JSON",null==o?void 0:o.toString()),null}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function B(e,t,n=!1){if(n)return t;try{return await t}catch(i){throw i instanceof r.ZR&&function({code:e}){return"auth/user-disabled"===e||"auth/user-token-expired"===e}(i)&&e.auth.currentUser===e&&await e.auth.signOut(),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class z{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){!this.isRunning&&(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,null!==this.timerId&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){let n=this.errorBackoff;return this.errorBackoff=Math.min(2*this.errorBackoff,96e4),n}{this.errorBackoff=3e4;let i=null!==(t=this.user.stsTokenManager.expirationTime)&&void 0!==t?t:0,r=i-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;let t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(null==e?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ${constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=U(this.lastLoginAt),this.creationTime=U(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function W(e){var t,n;let i=e.auth,r=await e.getIdToken(),s=await B(e,F(i,{idToken:r}));y(null==s?void 0:s.users.length,i,"internal-error");let o=s.users[0];e._notifyReloadListener(o);let l=(null===(t=o.providerUserInfo)||void 0===t?void 0:t.length)?(n=o.providerUserInfo,n.map(e=>{var{providerId:t}=e,n=(0,a.__rest)(e,["providerId"]);return{providerId:t,uid:n.rawId||"",displayName:n.displayName||null,email:n.email||null,phoneNumber:n.phoneNumber||null,photoURL:n.photoUrl||null}})):[],h=function(e,t){let n=e.filter(e=>!t.some(t=>t.providerId===e.providerId));return[...n,...t]}(e.providerData,l),u=e.isAnonymous,c=!(e.email&&o.passwordHash)&&!(null==h?void 0:h.length),d={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:h,metadata:new $(o.createdAt,o.lastLoginAt),isAnonymous:!!u&&c};Object.assign(e,d)}async function H(e){let t=(0,r.m9)(e);await W(t),await t.auth._persistUserIfCurrent(t),t.auth._notifyListenersIfCurrent(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function K(e,t){let n=await A(e,{},async()=>{let n=(0,r.xO)({grant_type:"refresh_token",refresh_token:t}).slice(1),{tokenApiHost:i,apiKey:s}=e.config,o=P(e,i,"/v1/token",`key=${s}`),a=await e._getAdditionalHeaders();return a["Content-Type"]="application/x-www-form-urlencoded",C.fetch()(o,{method:"POST",headers:a,body:n})});return{accessToken:n.access_token,expiresIn:n.expires_in,refreshToken:n.refresh_token}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class G{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){y(e.idToken,"internal-error"),y(void 0!==e.idToken,"internal-error"),y(void 0!==e.refreshToken,"internal-error");let t="expiresIn"in e&&void 0!==e.expiresIn?Number(e.expiresIn):function(e){let t=q(e);return y(t,"internal-error"),y(void 0!==t.exp,"internal-error"),y(void 0!==t.iat,"internal-error"),Number(t.exp)-Number(t.iat)}(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}async getToken(e,t=!1){return(y(!this.accessToken||this.refreshToken,e,"user-token-expired"),t||!this.accessToken||this.isExpired)?this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null:this.accessToken}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){let{accessToken:n,refreshToken:i,expiresIn:r}=await K(e,t);this.updateTokensAndExpiration(n,i,Number(r))}updateTokensAndExpiration(e,t,n){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+1e3*n}static fromJSON(e,t){let{refreshToken:n,accessToken:i,expirationTime:r}=t,s=new G;return n&&(y("string"==typeof n,"internal-error",{appName:e}),s.refreshToken=n),i&&(y("string"==typeof i,"internal-error",{appName:e}),s.accessToken=i),r&&(y("number"==typeof r,"internal-error",{appName:e}),s.expirationTime=r),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new G,this.toJSON())}_performRefresh(){return v("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function Q(e,t){y("string"==typeof e||void 0===e,"internal-error",{appName:t})}class Y{constructor(e){var{uid:t,auth:n,stsTokenManager:i}=e,r=(0,a.__rest)(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new z(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=n,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new $(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(e){let t=await B(this,this.stsTokenManager.getToken(this.auth,e));return y(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return V(this,e)}reload(){return H(this)}_assign(e){this!==e&&(y(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(e=>Object.assign({},e)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){let t=new Y(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){y(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let n=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),n=!0),t&&await W(this),await this.auth._persistUserIfCurrent(this),n&&this.auth._notifyListenersIfCurrent(this)}async delete(){let e=await this.getIdToken();return await B(this,M(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var n,i,r,s,o,a,l,h;let u=null!==(n=t.displayName)&&void 0!==n?n:void 0,c=null!==(i=t.email)&&void 0!==i?i:void 0,d=null!==(r=t.phoneNumber)&&void 0!==r?r:void 0,f=null!==(s=t.photoURL)&&void 0!==s?s:void 0,p=null!==(o=t.tenantId)&&void 0!==o?o:void 0,g=null!==(a=t._redirectEventId)&&void 0!==a?a:void 0,m=null!==(l=t.createdAt)&&void 0!==l?l:void 0,_=null!==(h=t.lastLoginAt)&&void 0!==h?h:void 0,{uid:v,emailVerified:w,isAnonymous:b,providerData:T,stsTokenManager:I}=t;y(v&&I,e,"internal-error");let E=G.fromJSON(this.name,I);y("string"==typeof v,e,"internal-error"),Q(u,e.name),Q(c,e.name),y("boolean"==typeof w,e,"internal-error"),y("boolean"==typeof b,e,"internal-error"),Q(d,e.name),Q(f,e.name),Q(p,e.name),Q(g,e.name),Q(m,e.name),Q(_,e.name);let C=new Y({uid:v,auth:e,email:c,emailVerified:w,displayName:u,isAnonymous:b,photoURL:f,phoneNumber:d,tenantId:p,stsTokenManager:E,createdAt:m,lastLoginAt:_});return T&&Array.isArray(T)&&(C.providerData=T.map(e=>Object.assign({},e))),g&&(C._redirectEventId=g),C}static async _fromIdTokenResponse(e,t,n=!1){let i=new G;i.updateFromServerResponse(t);let r=new Y({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:n});return await W(r),r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let X=new Map;function J(e){w(e instanceof Function,"Expected a class definition");let t=X.get(e);return t?(w(t instanceof e,"Instance stored in cache mismatched with class"),t):(t=new e,X.set(e,t),t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class Z{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){let t=this.storage[e];return void 0===t?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function ee(e,t,n){return`firebase:${e}:${t}:${n}`}Z.type="NONE";class et{constructor(e,t,n){this.persistence=e,this.auth=t,this.userKey=n;let{config:i,name:r}=this.auth;this.fullUserKey=ee(this.userKey,i.apiKey,r),this.fullPersistenceKey=ee("persistence",i.apiKey,r),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){let e=await this.persistence._get(this.fullUserKey);return e?Y._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;let t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,n="authUser"){if(!t.length)return new et(J(Z),e,n);let i=(await Promise.all(t.map(async e=>{if(await e._isAvailable())return e}))).filter(e=>e),r=i[0]||J(Z),s=ee(n,e.config.apiKey,e.name),o=null;for(let a of t)try{let l=await a._get(s);if(l){let h=Y._fromJSON(e,l);a!==r&&(o=h),r=a;break}}catch(u){}let c=i.filter(e=>e._shouldAllowMigration);return r._shouldAllowMigration&&c.length&&(r=c[0],o&&await r._set(s,o.toJSON()),await Promise.all(t.map(async e=>{if(e!==r)try{await e._remove(s)}catch(t){}}))),new et(r,e,n)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function en(e){let t=e.toLowerCase();if(t.includes("opera/")||t.includes("opr/")||t.includes("opios/"))return"Opera";if(eo(t))return"IEMobile";if(t.includes("msie")||t.includes("trident/"))return"IE";{if(t.includes("edge/"))return"Edge";if(ei(t))return"Firefox";if(t.includes("silk/"))return"Silk";if(el(t))return"Blackberry";if(eh(t))return"Webos";if(er(t))return"Safari";if((t.includes("chrome/")||es(t))&&!t.includes("edge/"))return"Chrome";if(ea(t))return"Android";let n=e.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);if((null==n?void 0:n.length)===2)return n[1]}return"Other"}function ei(e=(0,r.z$)()){return/firefox\//i.test(e)}function er(e=(0,r.z$)()){let t=e.toLowerCase();return t.includes("safari/")&&!t.includes("chrome/")&&!t.includes("crios/")&&!t.includes("android")}function es(e=(0,r.z$)()){return/crios\//i.test(e)}function eo(e=(0,r.z$)()){return/iemobile/i.test(e)}function ea(e=(0,r.z$)()){return/android/i.test(e)}function el(e=(0,r.z$)()){return/blackberry/i.test(e)}function eh(e=(0,r.z$)()){return/webos/i.test(e)}function eu(e=(0,r.z$)()){return/iphone|ipad|ipod/i.test(e)||/macintosh/i.test(e)&&/mobile/i.test(e)}function ec(e=(0,r.z$)()){return eu(e)||ea(e)||eh(e)||el(e)||/windows phone/i.test(e)||eo(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function ed(e,t=[]){let n;switch(e){case"Browser":n=en((0,r.z$)());break;case"Worker":n=`${en((0,r.z$)())}-${e}`;break;default:n=e}let i=t.length?t.join(","):"FirebaseCore-web";return`${n}/JsCore/${s.Jn}/${i}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ef{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){let n=t=>new Promise((n,i)=>{try{let r=e(t);n(r)}catch(s){i(s)}});n.onAbort=t,this.queue.push(n);let i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;let t=[];try{for(let n of this.queue)await n(e),n.onAbort&&t.push(n.onAbort)}catch(s){for(let i of(t.reverse(),t))try{i()}catch(r){}throw this.auth._errorFactory.create("login-blocked",{originalMessage:null==s?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function ep(e,t={}){return R(e,"GET","/v2/passwordPolicy",N(e,t))}class eg{constructor(e){var t,n,i,r;let s=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=null!==(t=s.minPasswordLength)&&void 0!==t?t:6,s.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=s.maxPasswordLength),void 0!==s.containsLowercaseCharacter&&(this.customStrengthOptions.containsLowercaseLetter=s.containsLowercaseCharacter),void 0!==s.containsUppercaseCharacter&&(this.customStrengthOptions.containsUppercaseLetter=s.containsUppercaseCharacter),void 0!==s.containsNumericCharacter&&(this.customStrengthOptions.containsNumericCharacter=s.containsNumericCharacter),void 0!==s.containsNonAlphanumericCharacter&&(this.customStrengthOptions.containsNonAlphanumericCharacter=s.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,"ENFORCEMENT_STATE_UNSPECIFIED"===this.enforcementState&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=null!==(i=null===(n=e.allowedNonAlphanumericCharacters)||void 0===n?void 0:n.join(""))&&void 0!==i?i:"",this.forceUpgradeOnSignin=null!==(r=e.forceUpgradeOnSignin)&&void 0!==r&&r,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,n,i,r,s,o;let a={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,a),this.validatePasswordCharacterOptions(e,a),a.isValid&&(a.isValid=null===(t=a.meetsMinPasswordLength)||void 0===t||t),a.isValid&&(a.isValid=null===(n=a.meetsMaxPasswordLength)||void 0===n||n),a.isValid&&(a.isValid=null===(i=a.containsLowercaseLetter)||void 0===i||i),a.isValid&&(a.isValid=null===(r=a.containsUppercaseLetter)||void 0===r||r),a.isValid&&(a.isValid=null===(s=a.containsNumericCharacter)||void 0===s||s),a.isValid&&(a.isValid=null===(o=a.containsNonAlphanumericCharacter)||void 0===o||o),a}validatePasswordLengthOptions(e,t){let n=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;n&&(t.meetsMinPasswordLength=e.length>=n),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let n;for(let i=0;i<e.length;i++)n=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,n>="a"&&n<="z",n>="A"&&n<="Z",n>="0"&&n<="9",this.allowedNonAlphanumericCharacters.includes(n))}updatePasswordCharacterOptionsStatuses(e,t,n,i,r){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=n)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class em{constructor(e,t,n,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=n,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new ey(this),this.idTokenSubscription=new ey(this),this.beforeStateQueue=new ef(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=d,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=J(t)),this._initializationPromise=this.queue(async()=>{var n,i;if(!this._deleted&&(this.persistenceManager=await et.create(this,e),!this._deleted)){if(null===(n=this._popupRedirectResolver)||void 0===n?void 0:n._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch(r){}await this.initializeCurrentUser(t),this.lastNotifiedUid=(null===(i=this.currentUser)||void 0===i?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;let e=await this.assertedPersistence.getCurrentUser();if(this.currentUser||e){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUser(e){var t;let n=await this.assertedPersistence.getCurrentUser(),i=n,r=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();let s=null===(t=this.redirectUser)||void 0===t?void 0:t._redirectEventId,o=null==i?void 0:i._redirectEventId,a=await this.tryRedirectSignIn(e);(!s||s===o)&&(null==a?void 0:a.user)&&(i=a.user,r=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(i)}catch(l){i=n,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(l))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return(y(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId)?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch(n){await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await W(e)}catch(t){if((null==t?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=function(){if("undefined"==typeof navigator)return null;let e=navigator;return e.languages&&e.languages[0]||e.language||null}()}async _delete(){this._deleted=!0}async updateCurrentUser(e){let t=e?(0,r.m9)(e):null;return t&&y(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&y(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0)}setPersistence(e){return this.queue(async()=>{await this.assertedPersistence.setPersistence(J(e))})}_getRecaptchaConfig(){return null==this.tenantId?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();let t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return null===this.tenantId?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){let e=await ep(this),t=new eg(e);null===this.tenantId?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new r.LL("auth","Firebase",e())}onAuthStateChanged(e,t,n){return this.registerStateListener(this.authStateSubscription,e,t,n)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,n){return this.registerStateListener(this.idTokenSubscription,e,t,n)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{let n=this.onAuthStateChanged(()=>{n(),e()},t)}})}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:null===(e=this._currentUser)||void 0===e?void 0:e.toJSON()}}async _setRedirectUser(e,t){let n=await this.getOrInitRedirectPersistenceManager(t);return null===e?n.removeCurrentUser():n.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){let t=e&&J(e)||this._popupRedirectResolver;y(t,this,"argument-error"),this.redirectPersistenceManager=await et.create(this,[J(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,n;return(this._isInitialized&&await this.queue(async()=>{}),(null===(t=this._currentUser)||void 0===t?void 0:t._redirectEventId)===e)?this._currentUser:(null===(n=this.redirectUser)||void 0===n?void 0:n._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);let n=null!==(t=null===(e=this.currentUser)||void 0===e?void 0:e.uid)&&void 0!==t?t:null;this.lastNotifiedUid!==n&&(this.lastNotifiedUid=n,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,n,i){if(this._deleted)return()=>{};let r="function"==typeof t?t:t.next.bind(t),s=!1,o=this._isInitialized?Promise.resolve():this._initializationPromise;if(y(o,this,"internal-error"),o.then(()=>{!s&&r(this.currentUser)}),"function"==typeof t){let a=e.addObserver(t,n,i);return()=>{s=!0,a()}}{let l=e.addObserver(t);return()=>{s=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return y(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!(!e||this.frameworks.includes(e))&&(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=ed(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;let t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);let n=await (null===(e=this.heartbeatServiceProvider.getImmediate({optional:!0}))||void 0===e?void 0:e.getHeartbeatsHeader());n&&(t["X-Firebase-Client"]=n);let i=await this._getAppCheckToken();return i&&(t["X-Firebase-AppCheck"]=i),t}async _getAppCheckToken(){var e;let t=await (null===(e=this.appCheckServiceProvider.getImmediate({optional:!0}))||void 0===e?void 0:e.getToken());return(null==t?void 0:t.error)&&function(e,...t){f.logLevel<=o.in.WARN&&f.warn(`Auth (${s.Jn}): ${e}`,...t)}(`Error while retrieving App Check token: ${t.error}`),null==t?void 0:t.token}}function e_(e){return(0,r.m9)(e)}class ey{constructor(e){this.auth=e,this.observer=null,this.addObserver=(0,r.ne)(e=>this.observer=e)}get next(){return y(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}function ev(e){return new Promise((t,n)=>{var i,r;let s=document.createElement("script");s.setAttribute("src",e),s.onload=t,s.onerror=e=>{let t=m("internal-error");t.customData=e,n(t)},s.type="text/javascript",s.charset="UTF-8",(null!==(r=null===(i=document.getElementsByTagName("head"))||void 0===i?void 0:i[0])&&void 0!==r?r:document).appendChild(s)})}function ew(e){return`__${e}${Math.floor(1e6*Math.random())}`}class eb{constructor(e){this.type="recaptcha-enterprise",this.auth=e_(e)}async verify(e="verify",t=!1){async function n(e){if(!t){if(null==e.tenantId&&null!=e._agentRecaptchaConfig)return e._agentRecaptchaConfig.siteKey;if(null!=e.tenantId&&void 0!==e._tenantRecaptchaConfigs[e.tenantId])return e._tenantRecaptchaConfigs[e.tenantId].siteKey}return new Promise(async(t,n)=>{L(e,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(i=>{if(void 0===i.recaptchaKey)n(Error("recaptcha Enterprise site key undefined"));else{let r=new u(i);return null==e.tenantId?e._agentRecaptchaConfig=r:e._tenantRecaptchaConfigs[e.tenantId]=r,t(r.siteKey)}}).catch(e=>{n(e)})})}function i(t,n,i){let r=window.grecaptcha;h(r)?r.enterprise.ready(()=>{r.enterprise.execute(t,{action:e}).then(e=>{n(e)}).catch(()=>{n("NO_RECAPTCHA")})}):i(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((e,r)=>{n(this.auth).then(n=>{if(!t&&h(window.grecaptcha))i(n,e,r);else{if("undefined"==typeof window){r(Error("RecaptchaVerifier is only supported in browser"));return}ev("https://www.google.com/recaptcha/enterprise.js?render="+n).then(()=>{i(n,e,r)}).catch(e=>{r(e)})}}).catch(e=>{r(e)})})}}async function eT(e,t,n,i=!1){let r=new eb(e),s;try{s=await r.verify(n)}catch(o){s=await r.verify(n,!0)}let a=Object.assign({},t);return i?Object.assign(a,{captchaResp:s}):Object.assign(a,{captchaResponse:s}),Object.assign(a,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(a,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),a}function eI(e){let t=e.indexOf(":");return t<0?"":e.substr(0,t+1)}function eE(e){if(!e)return null;let t=Number(e);return isNaN(t)?null:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eC{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return v("not implemented")}_getIdTokenResponse(e){return v("not implemented")}_linkToIdToken(e,t){return v("not implemented")}_getReauthenticationResolver(e){return v("not implemented")}}async function eS(e,t){return R(e,"POST","/v1/accounts:update",t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function ek(e,t){return D(e,"POST","/v1/accounts:signInWithPassword",N(e,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function eN(e,t){return D(e,"POST","/v1/accounts:signInWithEmailLink",N(e,t))}async function eR(e,t){return D(e,"POST","/v1/accounts:signInWithEmailLink",N(e,t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eA extends eC{constructor(e,t,n,i=null){super("password",n),this._email=e,this._password=t,this._tenantId=i}static _fromEmailAndPassword(e,t){return new eA(e,t,"password")}static _fromEmailAndCode(e,t,n=null){return new eA(e,t,"emailLink",n)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){let t="string"==typeof e?JSON.parse(e):e;if((null==t?void 0:t.email)&&(null==t?void 0:t.password)){if("password"===t.signInMethod)return this._fromEmailAndPassword(t.email,t.password);if("emailLink"===t.signInMethod)return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){var t;switch(this.signInMethod){case"password":let n={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};if(null===(t=e._getRecaptchaConfig())||void 0===t||!t.emailPasswordEnabled)return ek(e,n).catch(async t=>{if("auth/missing-recaptcha-token"!==t.code)return Promise.reject(t);{console.log("Sign-in with email address and password is protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the sign-in flow.");let i=await eT(e,n,"signInWithPassword");return ek(e,i)}});{let i=await eT(e,n,"signInWithPassword");return ek(e,i)}case"emailLink":return eN(e,{email:this._email,oobCode:this._password});default:g(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":return eS(e,{idToken:t,returnSecureToken:!0,email:this._email,password:this._password});case"emailLink":return eR(e,{idToken:t,email:this._email,oobCode:this._password});default:g(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function eD(e,t){return D(e,"POST","/v1/accounts:signInWithIdp",N(e,t))}class eP extends eC{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){let t=new eP(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):g("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){let t="string"==typeof e?JSON.parse(e):e,{providerId:n,signInMethod:i}=t,r=(0,a.__rest)(t,["providerId","signInMethod"]);if(!n||!i)return null;let s=new eP(n,i);return s.idToken=r.idToken||void 0,s.accessToken=r.accessToken||void 0,s.secret=r.secret,s.nonce=r.nonce,s.pendingToken=r.pendingToken||null,s}_getIdTokenResponse(e){let t=this.buildRequest();return eD(e,t)}_linkToIdToken(e,t){let n=this.buildRequest();return n.idToken=t,eD(e,n)}_getReauthenticationResolver(e){let t=this.buildRequest();return t.autoCreate=!1,eD(e,t)}buildRequest(){let e={requestUri:"http://localhost",returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{let t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=(0,r.xO)(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function eO(e,t){return R(e,"POST","/v1/accounts:sendVerificationCode",N(e,t))}async function ex(e,t){return D(e,"POST","/v1/accounts:signInWithPhoneNumber",N(e,t))}async function eL(e,t){let n=await D(e,"POST","/v1/accounts:signInWithPhoneNumber",N(e,t));if(n.temporaryProof)throw x(e,"account-exists-with-different-credential",n);return n}let eM={USER_NOT_FOUND:"user-not-found"};async function eF(e,t){let n=Object.assign(Object.assign({},t),{operation:"REAUTH"});return D(e,"POST","/v1/accounts:signInWithPhoneNumber",N(e,n),eM)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eU extends eC{constructor(e){super("phone","phone"),this.params=e}static _fromVerification(e,t){return new eU({verificationId:e,verificationCode:t})}static _fromTokenResponse(e,t){return new eU({phoneNumber:e,temporaryProof:t})}_getIdTokenResponse(e){return ex(e,this._makeVerificationRequest())}_linkToIdToken(e,t){return eL(e,Object.assign({idToken:t},this._makeVerificationRequest()))}_getReauthenticationResolver(e){return eF(e,this._makeVerificationRequest())}_makeVerificationRequest(){let{temporaryProof:e,phoneNumber:t,verificationId:n,verificationCode:i}=this.params;return e&&t?{temporaryProof:e,phoneNumber:t}:{sessionInfo:n,code:i}}toJSON(){let e={providerId:this.providerId};return this.params.phoneNumber&&(e.phoneNumber=this.params.phoneNumber),this.params.temporaryProof&&(e.temporaryProof=this.params.temporaryProof),this.params.verificationCode&&(e.verificationCode=this.params.verificationCode),this.params.verificationId&&(e.verificationId=this.params.verificationId),e}static fromJSON(e){"string"==typeof e&&(e=JSON.parse(e));let{verificationId:t,verificationCode:n,phoneNumber:i,temporaryProof:r}=e;return n||t||i||r?new eU({verificationId:t,verificationCode:n,phoneNumber:i,temporaryProof:r}):null}}class eV{constructor(e){var t,n,i,s,o,a;let l=(0,r.zd)((0,r.pd)(e)),h=null!==(t=l.apiKey)&&void 0!==t?t:null,u=null!==(n=l.oobCode)&&void 0!==n?n:null,c=/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){switch(e){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}(null!==(i=l.mode)&&void 0!==i?i:null);y(h&&u&&c,"argument-error"),this.apiKey=h,this.operation=c,this.code=u,this.continueUrl=null!==(s=l.continueUrl)&&void 0!==s?s:null,this.languageCode=null!==(o=l.languageCode)&&void 0!==o?o:null,this.tenantId=null!==(a=l.tenantId)&&void 0!==a?a:null}static parseLink(e){let t=function(e){let t=(0,r.zd)((0,r.pd)(e)).link,n=t?(0,r.zd)((0,r.pd)(t)).deep_link_id:null,i=(0,r.zd)((0,r.pd)(e)).deep_link_id,s=i?(0,r.zd)((0,r.pd)(i)).link:null;return s||i||n||t||e}(e);try{return new eV(t)}catch(n){return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ej{constructor(){this.providerId=ej.PROVIDER_ID}static credential(e,t){return eA._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){let n=eV.parseLink(t);return y(n,"argument-error"),eA._fromEmailAndCode(e,n.code,n.tenantId)}}ej.PROVIDER_ID="password",ej.EMAIL_PASSWORD_SIGN_IN_METHOD="password",ej.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eq{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eB extends eq{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ez extends eB{constructor(){super("facebook.com")}static credential(e){return eP._fromParams({providerId:ez.PROVIDER_ID,signInMethod:ez.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ez.credentialFromTaggedObject(e)}static credentialFromError(e){return ez.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return ez.credential(e.oauthAccessToken)}catch(t){return null}}}ez.FACEBOOK_SIGN_IN_METHOD="facebook.com",ez.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class e$ extends eB{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return eP._fromParams({providerId:e$.PROVIDER_ID,signInMethod:e$.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return e$.credentialFromTaggedObject(e)}static credentialFromError(e){return e$.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;let{oauthIdToken:t,oauthAccessToken:n}=e;if(!t&&!n)return null;try{return e$.credential(t,n)}catch(i){return null}}}e$.GOOGLE_SIGN_IN_METHOD="google.com",e$.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eW extends eB{constructor(){super("github.com")}static credential(e){return eP._fromParams({providerId:eW.PROVIDER_ID,signInMethod:eW.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return eW.credentialFromTaggedObject(e)}static credentialFromError(e){return eW.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return eW.credential(e.oauthAccessToken)}catch(t){return null}}}eW.GITHUB_SIGN_IN_METHOD="github.com",eW.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eH extends eB{constructor(){super("twitter.com")}static credential(e,t){return eP._fromParams({providerId:eH.PROVIDER_ID,signInMethod:eH.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return eH.credentialFromTaggedObject(e)}static credentialFromError(e){return eH.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;let{oauthAccessToken:t,oauthTokenSecret:n}=e;if(!t||!n)return null;try{return eH.credential(t,n)}catch(i){return null}}}eH.TWITTER_SIGN_IN_METHOD="twitter.com",eH.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eK{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,n,i=!1){let r=await Y._fromIdTokenResponse(e,n,i),s=eG(n),o=new eK({user:r,providerId:s,_tokenResponse:n,operationType:t});return o}static async _forOperation(e,t,n){await e._updateTokensIfNecessary(n,!0);let i=eG(n);return new eK({user:e,providerId:i,_tokenResponse:n,operationType:t})}}function eG(e){return e.providerId?e.providerId:"phoneNumber"in e?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class eQ extends r.ZR{constructor(e,t,n,i){var r;super(t.code,t.message),this.operationType=n,this.user=i,Object.setPrototypeOf(this,eQ.prototype),this.customData={appName:e.name,tenantId:null!==(r=e.tenantId)&&void 0!==r?r:void 0,_serverResponse:t.customData._serverResponse,operationType:n}}static _fromErrorAndOperation(e,t,n,i){return new eQ(e,t,n,i)}}function eY(e,t,n,i){let r="reauthenticate"===t?n._getReauthenticationResolver(e):n._getIdTokenResponse(e);return r.catch(n=>{if("auth/multi-factor-auth-required"===n.code)throw eQ._fromErrorAndOperation(e,n,t,i);throw n})}async function eX(e,t,n=!1){let i=await B(e,t._linkToIdToken(e.auth,await e.getIdToken()),n);return eK._forOperation(e,"link",i)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function eJ(e,t,n=!1){let{auth:i}=e,r="reauthenticate";try{let s=await B(e,eY(i,r,t,e),n);y(s.idToken,i,"internal-error");let o=q(s.idToken);y(o,i,"internal-error");let{sub:a}=o;return y(e.uid===a,i,"user-mismatch"),eK._forOperation(e,r,s)}catch(l){throw(null==l?void 0:l.code)==="auth/user-not-found"&&g(i,"user-mismatch"),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function eZ(e,t,n=!1){let i="signIn",r=await eY(e,i,t),s=await eK._fromIdTokenResponse(e,i,r);return n||await e._updateCurrentUser(s.user),s}async function e0(e,t){return eZ(e_(e),t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function e1(e){let t=e_(e);t._getPasswordPolicyInternal()&&await t._updatePasswordPolicy()}function e2(e,t,n){return e0((0,r.m9)(e),ej.credential(t,n)).catch(async t=>{throw"auth/password-does-not-meet-requirements"===t.code&&e1(e),t})}function e4(e,t,n,i){return(0,r.m9)(e).onAuthStateChanged(t,n,i)}function e9(e){return(0,r.m9)(e).signOut()}new WeakMap;let e6="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class e5{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{if(!this.storage)return Promise.resolve(!1);return this.storage.setItem(e6,"1"),this.storage.removeItem(e6),Promise.resolve(!0)}catch(e){return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){let t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}class e3 extends e5{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(){let e=(0,r.z$)();return er(e)||eu(e)}()&&function(){try{return!!(window&&window!==window.top)}catch(e){return!1}}(),this.fallbackToPolling=ec(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(let t of Object.keys(this.listeners)){let n=this.storage.getItem(t),i=this.localCache[t];n!==i&&e(t,i,n)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((e,t,n)=>{this.notifyListeners(e,n)});return}let n=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){let i=this.storage.getItem(n);if(e.newValue!==i)null!==e.newValue?this.storage.setItem(n,e.newValue):this.storage.removeItem(n);else if(this.localCache[n]===e.newValue&&!t)return}let s=()=>{let e=this.storage.getItem(n);(t||this.localCache[n]!==e)&&this.notifyListeners(n,e)},o=this.storage.getItem(n);(0,r.w1)()&&10===document.documentMode&&o!==e.newValue&&e.newValue!==e.oldValue?setTimeout(s,10):s()}notifyListeners(e,t){this.localCache[e]=t;let n=this.listeners[e];if(n)for(let i of Array.from(n))i(t?JSON.parse(t):t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,n)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:n}),!0)})},1e3)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){0===Object.keys(this.listeners).length&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),0===this.listeners[e].size&&delete this.listeners[e]),0===Object.keys(this.listeners).length&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){let t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}e3.type="LOCAL";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class e7 extends e5{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}e7.type="SESSION";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class e8{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){let t=this.receivers.find(t=>t.isListeningto(e));if(t)return t;let n=new e8(e);return this.receivers.push(n),n}isListeningto(e){return this.eventTarget===e}async handleEvent(e){var t;let{eventId:n,eventType:i,data:r}=e.data,s=this.handlersMap[i];if(!(null==s?void 0:s.size))return;e.ports[0].postMessage({status:"ack",eventId:n,eventType:i});let o=Array.from(s).map(async t=>t(e.origin,r)),a=await Promise.all(o.map(async e=>{try{let t=await e;return{fulfilled:!0,value:t}}catch(n){return{fulfilled:!1,reason:n}}}));e.ports[0].postMessage({status:"done",eventId:n,eventType:i,response:a})}_subscribe(e,t){0===Object.keys(this.handlersMap).length&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),t&&0!==this.handlersMap[e].size||delete this.handlersMap[e],0===Object.keys(this.handlersMap).length&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function te(e="",t=10){let n="";for(let i=0;i<t;i++)n+=Math.floor(10*Math.random());return e+n}e8.receivers=[];/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tt{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,n=50){let i="undefined"!=typeof MessageChannel?new MessageChannel:null;if(!i)throw Error("connection_unavailable");let r,s;return new Promise((o,a)=>{let l=te("",20);i.port1.start();let h=setTimeout(()=>{a(Error("unsupported_event"))},n);s={messageChannel:i,onMessage(e){if(e.data.eventId===l)switch(e.data.status){case"ack":clearTimeout(h),r=setTimeout(()=>{a(Error("timeout"))},3e3);break;case"done":clearTimeout(r),o(e.data.response);break;default:clearTimeout(h),clearTimeout(r),a(Error("invalid_response"))}}},this.handlers.add(s),i.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:e,eventId:l,data:t},[i.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function tn(){return window}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function ti(){return void 0!==tn().WorkerGlobalScope&&"function"==typeof tn().importScripts}async function tr(){if(!(null==navigator?void 0:navigator.serviceWorker))return null;try{let e=await navigator.serviceWorker.ready;return e.active}catch(t){return null}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ts="firebaseLocalStorageDb",to="firebaseLocalStorage",ta="fbase_key";class tl{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function th(e,t){return e.transaction([to],t?"readwrite":"readonly").objectStore(to)}function tu(){let e=indexedDB.open(ts,1);return new Promise((t,n)=>{e.addEventListener("error",()=>{n(e.error)}),e.addEventListener("upgradeneeded",()=>{let t=e.result;try{t.createObjectStore(to,{keyPath:ta})}catch(i){n(i)}}),e.addEventListener("success",async()=>{let n=e.result;n.objectStoreNames.contains(to)?t(n):(n.close(),await function(){let e=indexedDB.deleteDatabase(ts);return new tl(e).toPromise()}(),t(await tu()))})})}async function tc(e,t,n){let i=th(e,!0).put({[ta]:t,value:n});return new tl(i).toPromise()}async function td(e,t){let n=th(e,!1).get(t),i=await new tl(n).toPromise();return void 0===i?null:i.value}function tf(e,t){let n=th(e,!0).delete(t);return new tl(n).toPromise()}class tp{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db||(this.db=await tu()),this.db}async _withRetries(e){let t=0;for(;;)try{let n=await this._openDb();return await e(n)}catch(i){if(t++>3)throw i;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return ti()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=e8._getInstance(ti()?self:null),this.receiver._subscribe("keyChanged",async(e,t)=>{let n=await this._poll();return{keyProcessed:n.includes(t.key)}}),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await tr(),!this.activeServiceWorker)return;this.sender=new tt(this.activeServiceWorker);let n=await this.sender._send("ping",{},800);n&&(null===(e=n[0])||void 0===e?void 0:e.fulfilled)&&(null===(t=n[0])||void 0===t?void 0:t.value.includes("keyChanged"))&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){var t;if(this.sender&&this.activeServiceWorker&&((null===(t=null==navigator?void 0:navigator.serviceWorker)||void 0===t?void 0:t.controller)||null)===this.activeServiceWorker)try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch(n){}}async _isAvailable(){try{if(!indexedDB)return!1;let e=await tu();return await tc(e,e6,"1"),await tf(e,e6),!0}catch(t){}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(n=>tc(n,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){let t=await this._withRetries(t=>td(t,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>tf(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){let e=await this._withRetries(e=>{let t=th(e,!1).getAll();return new tl(t).toPromise()});if(!e||0!==this.pendingWrites)return[];let t=[],n=new Set;for(let{fbase_key:i,value:r}of e)n.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(r)&&(this.notifyListeners(i,r),t.push(i));for(let s of Object.keys(this.localCache))this.localCache[s]&&!n.has(s)&&(this.notifyListeners(s,null),t.push(s));return t}notifyListeners(e,t){this.localCache[e]=t;let n=this.listeners[e];if(n)for(let i of Array.from(n))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),800)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){0===Object.keys(this.listeners).length&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),0===this.listeners[e].size&&delete this.listeners[e]),0===Object.keys(this.listeners).length&&this.stopPolling()}}async function tg(e,t,n){var i,r,s,o,a;let l=await n.verify();try{y("string"==typeof l,e,"argument-error"),y("recaptcha"===n.type,e,"argument-error");let h;if(h="string"==typeof t?{phoneNumber:t}:t,"session"in h){let u=h.session;if("phoneNumber"in h){y("enroll"===u.type,e,"internal-error");let c=await (r=e,s={idToken:u.credential,phoneEnrollmentInfo:{phoneNumber:h.phoneNumber,recaptchaToken:l}},R(r,"POST","/v2/accounts/mfaEnrollment:start",N(r,s)));return c.phoneSessionInfo.sessionInfo}{y("signin"===u.type,e,"internal-error");let d=(null===(i=h.multiFactorHint)||void 0===i?void 0:i.uid)||h.multiFactorUid;y(d,e,"missing-multi-factor-info");let f=await (o=e,a={mfaPendingCredential:u.credential,mfaEnrollmentId:d,phoneSignInInfo:{recaptchaToken:l}},R(o,"POST","/v2/accounts/mfaSignIn:start",N(o,a)));return f.phoneResponseInfo.sessionInfo}}{let{sessionInfo:p}=await eO(e,{phoneNumber:h.phoneNumber,recaptchaToken:l});return p}}finally{n._reset()}}tp.type="LOCAL",ew("rcb"),new I(3e4,6e4);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tm{constructor(e){this.providerId=tm.PROVIDER_ID,this.auth=e_(e)}verifyPhoneNumber(e,t){return tg(this.auth,e,(0,r.m9)(t))}static credential(e,t){return eU._fromVerification(e,t)}static credentialFromResult(e){return tm.credentialFromTaggedObject(e)}static credentialFromError(e){return tm.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;let{phoneNumber:t,temporaryProof:n}=e;return t&&n?eU._fromTokenResponse(t,n):null}}tm.PROVIDER_ID="phone",tm.PHONE_SIGN_IN_METHOD="phone";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class t_ extends eC{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return eD(e,this._buildIdpRequest())}_linkToIdToken(e,t){return eD(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return eD(e,this._buildIdpRequest())}_buildIdpRequest(e){let t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function ty(e){return eZ(e.auth,new t_(e),e.bypassAuthState)}function tv(e){let{auth:t,user:n}=e;return y(n,t,"internal-error"),eJ(n,new t_(e),e.bypassAuthState)}async function tw(e){let{auth:t,user:n}=e;return y(n,t,"internal-error"),eX(n,new t_(e),e.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tb{constructor(e,t,n,i,r=!1){this.auth=e,this.resolver=n,this.user=i,this.bypassAuthState=r,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(n){this.reject(n)}})}async onAuthEvent(e){let{urlResponse:t,sessionId:n,postBody:i,tenantId:r,error:s,type:o}=e;if(s){this.reject(s);return}let a={auth:this.auth,requestUri:t,sessionId:n,tenantId:r||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(o)(a))}catch(l){this.reject(l)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return ty;case"linkViaPopup":case"linkViaRedirect":return tw;case"reauthViaPopup":case"reauthViaRedirect":return tv;default:g(this.auth,"internal-error")}}resolve(e){w(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){w(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let tT=new I(2e3,1e4);class tI extends tb{constructor(e,t,n,i,r){super(e,t,i,r),this.provider=n,this.authWindow=null,this.pollId=null,tI.currentPopupAction&&tI.currentPopupAction.cancel(),tI.currentPopupAction=this}async executeNotNull(){let e=await this.execute();return y(e,this.auth,"internal-error"),e}async onExecution(){w(1===this.filter.length,"Popup operations only handle one event");let e=te();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(e=>{this.reject(e)}),this.resolver._isIframeWebStorageSupported(this.auth,e=>{e||this.reject(m(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return(null===(e=this.authWindow)||void 0===e?void 0:e.associatedEvent)||null}cancel(){this.reject(m(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,tI.currentPopupAction=null}pollUserCancellation(){let e=()=>{var t,n;if(null===(n=null===(t=this.authWindow)||void 0===t?void 0:t.window)||void 0===n?void 0:n.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(m(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,tT.get())};e()}}tI.currentPopupAction=null;let tE=new Map;class tC extends tb{constructor(e,t,n=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,n),this.eventId=null}async execute(){let e=tE.get(this.auth._key());if(!e){try{let t=await tS(this.resolver,this.auth),n=t?await super.execute():null;e=()=>Promise.resolve(n)}catch(i){e=()=>Promise.reject(i)}tE.set(this.auth._key(),e)}return this.bypassAuthState||tE.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if("signInViaRedirect"===e.type)return super.onAuthEvent(e);if("unknown"===e.type){this.resolve(null);return}if(e.eventId){let t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function tS(e,t){var n,i;let r=(n=t,ee("pendingRedirect",n.config.apiKey,n.name)),s=(i=e,J(i._redirectPersistence));if(!await s._isAvailable())return!1;let o=await s._get(r)==="true";return await s._remove(r),o}function tk(e,t){tE.set(e._key(),t)}async function tN(e,t,n=!1){var i,r;let s=e_(e),o=t?J(t):(y(s._popupRedirectResolver,s,"argument-error"),s._popupRedirectResolver),a=new tC(s,o,n),l=await a.execute();return l&&!n&&(delete l.user._redirectEventId,await s._persistUserIfCurrent(l.user),await s._setRedirectUser(null,t)),l}class tR{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(n=>{this.isEventForConsumer(e,n)&&(t=!0,this.sendToConsumer(e,n),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!function(e){switch(e.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return tD(e);default:return!1}}(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var n;if(e.error&&!tD(e)){let i=(null===(n=e.error.code)||void 0===n?void 0:n.split("auth/")[1])||"internal-error";t.onError(m(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){let n=null===t.eventId||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&n}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=6e5&&this.cachedEventUids.clear(),this.cachedEventUids.has(tA(e))}saveEventToCache(e){this.cachedEventUids.add(tA(e)),this.lastProcessedEventTime=Date.now()}}function tA(e){return[e.type,e.eventId,e.sessionId,e.tenantId].filter(e=>e).join("-")}function tD({type:e,error:t}){return"unknown"===e&&(null==t?void 0:t.code)==="auth/no-auth-event"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function tP(e,t={}){return R(e,"GET","/v1/projects",t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let tO=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,tx=/^https?/;async function tL(e){if(e.config.emulator)return;let{authorizedDomains:t}=await tP(e);for(let n of t)try{if(tM(n))return}catch(i){}g(e,"unauthorized-domain")}function tM(e){let t=b(),{protocol:n,hostname:i}=new URL(t);if(e.startsWith("chrome-extension://")){let r=new URL(e);return""===r.hostname&&""===i?"chrome-extension:"===n&&e.replace("chrome-extension://","")===t.replace("chrome-extension://",""):"chrome-extension:"===n&&r.hostname===i}if(!tx.test(n))return!1;if(tO.test(e))return i===e;let s=e.replace(/\./g,"\\."),o=RegExp("^(.+\\."+s+"|"+s+")$","i");return o.test(i)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let tF=new I(3e4,6e4);function tU(){let e=tn().___jsl;if(null==e?void 0:e.H){for(let t of Object.keys(e.H))if(e.H[t].r=e.H[t].r||[],e.H[t].L=e.H[t].L||[],e.H[t].r=[...e.H[t].L],e.CP)for(let n=0;n<e.CP.length;n++)e.CP[n]=null}}let tV=null,tj=new I(5e3,15e3),tq={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},tB=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);async function tz(e){var t,n;let i=await (tV=tV||new Promise((t,n)=>{var i,r,s;function o(){tU(),gapi.load("gapi.iframes",{callback(){t(gapi.iframes.getContext())},ontimeout(){tU(),n(m(e,"network-request-failed"))},timeout:tF.get()})}if(null===(r=null===(i=tn().gapi)||void 0===i?void 0:i.iframes)||void 0===r?void 0:r.Iframe)t(gapi.iframes.getContext());else if(null===(s=tn().gapi)||void 0===s?void 0:s.load)o();else{let a=ew("iframefcb");return tn()[a]=()=>{gapi.load?o():n(m(e,"network-request-failed"))},ev(`https://apis.google.com/js/api.js?onload=${a}`).catch(e=>n(e))}}).catch(e=>{throw tV=null,e})),o=tn().gapi;return y(o,e,"internal-error"),i.open({where:document.body,url:function(e){let t=e.config;y(t.authDomain,e,"auth-domain-config-required");let n=t.emulator?E(t,"emulator/auth/iframe"):`https://${e.config.authDomain}/__/auth/iframe`,i={apiKey:t.apiKey,appName:e.name,v:s.Jn},o=tB.get(e.config.apiHost);o&&(i.eid=o);let a=e._getFrameworks();return a.length&&(i.fw=a.join(",")),`${n}?${(0,r.xO)(i).slice(1)}`}(e),messageHandlersFilter:o.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:tq,dontclear:!0},t=>new Promise(async(n,i)=>{await t.restyle({setHideOnLeave:!1});let r=m(e,"network-request-failed"),s=tn().setTimeout(()=>{i(r)},tj.get());function o(){tn().clearTimeout(s),n(t)}t.ping(o).then(o,()=>{i(r)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let t$={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"};class tW{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch(e){}}}let tH=encodeURIComponent("fac");async function tK(e,t,n,i,o,a){y(e.config.authDomain,e,"auth-domain-config-required"),y(e.config.apiKey,e,"invalid-api-key");let l={apiKey:e.config.apiKey,appName:e.name,authType:n,redirectUrl:i,v:s.Jn,eventId:o};if(t instanceof eq)for(let[h,u]of(t.setDefaultLanguage(e.languageCode),l.providerId=t.providerId||"",(0,r.xb)(t.getCustomParameters())||(l.customParameters=JSON.stringify(t.getCustomParameters())),Object.entries(a||{})))l[h]=u;if(t instanceof eB){let c=t.getScopes().filter(e=>""!==e);c.length>0&&(l.scopes=c.join(","))}for(let d of(e.tenantId&&(l.tid=e.tenantId),Object.keys(l)))void 0===l[d]&&delete l[d];let f=await e._getAppCheckToken(),p=f?`#${tH}=${encodeURIComponent(f)}`:"";return`${function({config:e}){return e.emulator?E(e,"emulator/auth/handler"):`https://${e.authDomain}/__/auth/handler`}(e)}?${(0,r.xO)(l).slice(1)}${p}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let tG="webStorageSupport",tQ=class{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=e7,this._completeRedirectFn=tN,this._overrideRedirectResult=tk}async _openPopup(e,t,n,i){var s;w(null===(s=this.eventManagers[e._key()])||void 0===s?void 0:s.manager,"_initialize() not called before _openPopup()");let o=await tK(e,t,n,b(),i);return function(e,t,n,i=500,s=600){let o=Math.max((window.screen.availHeight-s)/2,0).toString(),a=Math.max((window.screen.availWidth-i)/2,0).toString(),l="",h=Object.assign(Object.assign({},t$),{width:i.toString(),height:s.toString(),top:o,left:a}),u=(0,r.z$)().toLowerCase();n&&(l=es(u)?"_blank":n),ei(u)&&(t=t||"http://localhost",h.scrollbars="yes");let c=Object.entries(h).reduce((e,[t,n])=>`${e}${t}=${n},`,"");if(function(e=(0,r.z$)()){var t;return eu(e)&&!!(null===(t=window.navigator)||void 0===t?void 0:t.standalone)}(u)&&"_self"!==l)return function(e,t){let n=document.createElement("a");n.href=e,n.target=t;let i=document.createEvent("MouseEvent");i.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),n.dispatchEvent(i)}(t||"",l),new tW(null);let d=window.open(t||"",l,c);y(d,e,"popup-blocked");try{d.focus()}catch(f){}return new tW(d)}(e,o,te())}async _openRedirect(e,t,n,i){var r;await this._originValidation(e);let s=await tK(e,t,n,b(),i);return tn().location.href=s,new Promise(()=>{})}_initialize(e){let t=e._key();if(this.eventManagers[t]){let{manager:n,promise:i}=this.eventManagers[t];return n?Promise.resolve(n):(w(i,"If manager is not set, promise should be"),i)}let r=this.initAndGetManager(e);return this.eventManagers[t]={promise:r},r.catch(()=>{delete this.eventManagers[t]}),r}async initAndGetManager(e){let t=await tz(e),n=new tR(e);return t.register("authEvent",t=>{y(null==t?void 0:t.authEvent,e,"invalid-auth-event");let i=n.onEvent(t.authEvent);return{status:i?"ACK":"ERROR"}},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:n},this.iframes[e._key()]=t,n}_isIframeWebStorageSupported(e,t){let n=this.iframes[e._key()];n.send(tG,{type:tG},n=>{var i;let r=null===(i=null==n?void 0:n[0])||void 0===i?void 0:i[tG];void 0!==r&&t(!!r),g(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){let t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=tL(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return ec()||er()||eu()}};var tY="@firebase/auth",tX="1.3.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class tJ{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),(null===(e=this.auth.currentUser)||void 0===e?void 0:e.uid)||null}async getToken(e){if(this.assertAuthConfigured(),await this.auth._initializationPromise,!this.auth.currentUser)return null;let t=await this.auth.currentUser.getIdToken(e);return{accessToken:t}}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;let t=this.auth.onIdTokenChanged(t=>{e((null==t?void 0:t.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();let t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){y(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}let tZ=(0,r.Pz)("authIdTokenMaxAge")||300,t0=null,t1=e=>async t=>{let n=t&&await t.getIdTokenResult(),i=n&&(new Date().getTime()-Date.parse(n.issuedAtTime))/1e3;if(i&&i>tZ)return;let r=null==n?void 0:n.token;t0!==r&&(t0=r,await fetch(e,{method:r?"POST":"DELETE",headers:r?{Authorization:`Bearer ${r}`}:{}}))};function t2(e=(0,s.Mq)()){let t=(0,s.qX)(e,"auth");if(t.isInitialized())return t.getImmediate();let n=/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e,t){let n=(0,s.qX)(e,"auth");if(n.isInitialized()){let i=n.getImmediate(),o=n.getOptions();if((0,r.vZ)(o,null!=t?t:{}))return i;g(i,"already-initialized")}let a=n.initialize({options:t});return a}(e,{popupRedirectResolver:tQ,persistence:[tp,e3,e7]}),i=(0,r.Pz)("authTokenSyncURL");if(i){var o,a,l,h,u;let c=t1(i);l=()=>c(n.currentUser),(0,r.m9)(n).beforeAuthStateChanged(c,l),u=e=>c(e),(0,r.m9)(n).onIdTokenChanged(u,void 0,void 0)}let d=(0,r.q4)("auth");return d&&function(e,t,n){let i=e_(e);y(i._canInitEmulator,i,"emulator-config-failed"),y(/^https?:\/\//.test(t),i,"invalid-emulator-scheme");let r=!!(null==n?void 0:n.disableWarnings),s=eI(t),{host:o,port:a}=function(e){let t=eI(e),n=/(\/\/)?([^?#/]+)/.exec(e.substr(t.length));if(!n)return{host:"",port:null};let i=n[2].split("@").pop()||"",r=/^(\[[^\]]+\])(:|$)/.exec(i);if(r){let s=r[1];return{host:s,port:eE(i.substr(s.length+1))}}{let[o,a]=i.split(":");return{host:o,port:eE(a)}}}(t),l=null===a?"":`:${a}`;i.config.emulator={url:`${s}//${o}${l}/`},i.settings.appVerificationDisabledForTesting=!0,i.emulatorConfig=Object.freeze({host:o,port:a,protocol:s.replace(":",""),options:Object.freeze({disableWarnings:r})}),r||function(){function e(){let e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}"undefined"!=typeof console&&"function"==typeof console.info&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),"undefined"!=typeof window&&"undefined"!=typeof document&&("loading"===document.readyState?window.addEventListener("DOMContentLoaded",e):e())}()}(n,`http://${d}`),n}i="Browser",(0,s.Xd)(new l.wA("auth",(e,{options:t})=>{let n=e.getProvider("app").getImmediate(),r=e.getProvider("heartbeat"),s=e.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=n.options;y(o&&!o.includes(":"),"invalid-api-key",{appName:n.name});let l={apiKey:o,authDomain:a,clientPlatform:i,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:ed(i)},h=new em(n,r,s,l);return function(e,t){let n=(null==t?void 0:t.persistence)||[],i=(Array.isArray(n)?n:[n]).map(J);(null==t?void 0:t.errorMap)&&e._updateErrorMap(t.errorMap),e._initializeWithPersistence(i,null==t?void 0:t.popupRedirectResolver)}(h,t),h},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,n)=>{let i=e.getProvider("auth-internal");i.initialize()})),(0,s.Xd)(new l.wA("auth-internal",e=>{var t;let n=e_(e.getProvider("auth").getImmediate());return new tJ(n)},"PRIVATE").setInstantiationMode("EXPLICIT")),(0,s.KN)(tY,tX,/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){switch(e){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";default:return}}(i)),(0,s.KN)(tY,tX,"esm2017")},6100:function(e,t,n){"use strict";n.d(t,{JU:function(){return lr},QT:function(){return lL},ad:function(){return la},r7:function(){return lF}});var i,r,s,o,a,l,h,u,c=n(5816),d=n(8463),f=n(3333),p=n(4444),g={},m=m||{},_=("undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{})||self;function y(e){var t=typeof e;return"array"==(t="object"!=t?t:e?Array.isArray(e)?"array":t:"null")||"object"==t&&"number"==typeof e.length}function v(e){var t=typeof e;return"object"==t&&null!=e||"function"==t}function w(e,t,n){return e.call.apply(e.bind,arguments)}function b(e,t,n){if(!e)throw Error();if(2<arguments.length){var i=Array.prototype.slice.call(arguments,2);return function(){var n=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(n,i),e.apply(t,n)}}return function(){return e.apply(t,arguments)}}function T(e,t,n){return(T=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?w:b).apply(null,arguments)}function I(e,t){var n=Array.prototype.slice.call(arguments,1);return function(){var t=n.slice();return t.push.apply(t,arguments),e.apply(this,t)}}function E(e,t){function n(){}n.prototype=t.prototype,e.$=t.prototype,e.prototype=new n,e.prototype.constructor=e,e.ac=function(e,n,i){for(var r=Array(arguments.length-2),s=2;s<arguments.length;s++)r[s-2]=arguments[s];return t.prototype[n].apply(e,r)}}function C(){this.s=this.s,this.o=this.o}C.prototype.s=!1,C.prototype.sa=function(){this.s||(this.s=!0,this.N())},C.prototype.N=function(){if(this.o)for(;this.o.length;)this.o.shift()()};let S=Array.prototype.indexOf?function(e,t){return Array.prototype.indexOf.call(e,t,void 0)}:function(e,t){if("string"==typeof e)return"string"!=typeof t||1!=t.length?-1:e.indexOf(t,0);for(let n=0;n<e.length;n++)if(n in e&&e[n]===t)return n;return -1};function k(e){let t=e.length;if(0<t){let n=Array(t);for(let i=0;i<t;i++)n[i]=e[i];return n}return[]}function N(e,t){for(let n=1;n<arguments.length;n++){let i=arguments[n];if(y(i)){let r=e.length||0,s=i.length||0;e.length=r+s;for(let o=0;o<s;o++)e[r+o]=i[o]}else e.push(i)}}function R(e,t){this.type=e,this.g=this.target=t,this.defaultPrevented=!1}R.prototype.h=function(){this.defaultPrevented=!0};var A=function(){if(!_.addEventListener||!Object.defineProperty)return!1;var e=!1,t=Object.defineProperty({},"passive",{get:function(){e=!0}});try{_.addEventListener("test",()=>{},t),_.removeEventListener("test",()=>{},t)}catch(n){}return e}();function D(e){return/^[\s\xa0]*$/.test(e)}function P(){var e=_.navigator;return e&&(e=e.userAgent)?e:""}function O(e){return -1!=P().indexOf(e)}function x(e){return x[" "](e),e}x[" "]=function(){};var L=O("Opera"),M=O("Trident")||O("MSIE"),F=O("Edge"),U=F||M,V=O("Gecko")&&!(-1!=P().toLowerCase().indexOf("webkit")&&!O("Edge"))&&!(O("Trident")||O("MSIE"))&&!O("Edge"),j=-1!=P().toLowerCase().indexOf("webkit")&&!O("Edge");function q(){var e=_.document;return e?e.documentMode:void 0}a:{var B,z="",$=(B=P(),V?/rv:([^\);]+)(\)|;)/.exec(B):F?/Edge\/([\d\.]+)/.exec(B):M?/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(B):j?/WebKit\/(\S+)/.exec(B):L?/(?:Version)[ \/]?(\S+)/.exec(B):void 0);if($&&(z=$?$[1]:""),M){var W=q();if(null!=W&&W>parseFloat(z)){s=String(W);break a}}s=z}if(_.document&&M){o=q()||parseInt(s,10)||void 0}else o=void 0;var H=o;function K(e,t){if(R.call(this,e?e.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,e){var n=this.type=e.type,i=e.changedTouches&&e.changedTouches.length?e.changedTouches[0]:null;if(this.target=e.target||e.srcElement,this.g=t,t=e.relatedTarget){if(V){a:{try{x(t.nodeName);var r=!0;break a}catch(s){}r=!1}r||(t=null)}}else"mouseover"==n?t=e.fromElement:"mouseout"==n&&(t=e.toElement);this.relatedTarget=t,i?(this.clientX=void 0!==i.clientX?i.clientX:i.pageX,this.clientY=void 0!==i.clientY?i.clientY:i.pageY,this.screenX=i.screenX||0,this.screenY=i.screenY||0):(this.clientX=void 0!==e.clientX?e.clientX:e.pageX,this.clientY=void 0!==e.clientY?e.clientY:e.pageY,this.screenX=e.screenX||0,this.screenY=e.screenY||0),this.button=e.button,this.key=e.key||"",this.ctrlKey=e.ctrlKey,this.altKey=e.altKey,this.shiftKey=e.shiftKey,this.metaKey=e.metaKey,this.pointerId=e.pointerId||0,this.pointerType="string"==typeof e.pointerType?e.pointerType:G[e.pointerType]||"",this.state=e.state,this.i=e,e.defaultPrevented&&K.$.h.call(this)}}E(K,R);var G={2:"touch",3:"pen",4:"mouse"};K.prototype.h=function(){K.$.h.call(this);var e=this.i;e.preventDefault?e.preventDefault():e.returnValue=!1};var Q="closure_listenable_"+(1e6*Math.random()|0),Y=0;function X(e,t,n,i,r){this.listener=e,this.proxy=null,this.src=t,this.type=n,this.capture=!!i,this.la=r,this.key=++Y,this.fa=this.ia=!1}function J(e){e.fa=!0,e.listener=null,e.proxy=null,e.src=null,e.la=null}function Z(e,t,n){for(let i in e)t.call(n,e[i],i,e)}function ee(e){let t={};for(let n in e)t[n]=e[n];return t}let et="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function en(e,t){let n,i;for(let r=1;r<arguments.length;r++){for(n in i=arguments[r])e[n]=i[n];for(let s=0;s<et.length;s++)n=et[s],Object.prototype.hasOwnProperty.call(i,n)&&(e[n]=i[n])}}function ei(e){this.src=e,this.g={},this.h=0}function er(e,t){var n=t.type;if(n in e.g){var i,r=e.g[n],s=S(r,t);(i=0<=s)&&Array.prototype.splice.call(r,s,1),i&&(J(t),0==e.g[n].length&&(delete e.g[n],e.h--))}}function es(e,t,n,i){for(var r=0;r<e.length;++r){var s=e[r];if(!s.fa&&s.listener==t&&!!n==s.capture&&s.la==i)return r}return -1}ei.prototype.add=function(e,t,n,i,r){var s=e.toString();(e=this.g[s])||(e=this.g[s]=[],this.h++);var o=es(e,t,i,r);return -1<o?(t=e[o],n||(t.ia=!1)):((t=new X(t,this.src,s,!!i,r)).ia=n,e.push(t)),t};var eo="closure_lm_"+(1e6*Math.random()|0),ea={};function el(e,t,n,i,r){if(i&&i.once)return function e(t,n,i,r,s){if(Array.isArray(n)){for(var o=0;o<n.length;o++)e(t,n[o],i,r,s);return null}return i=eg(i),t&&t[Q]?t.P(n,i,v(r)?!!r.capture:!!r,s):eh(t,n,i,!0,r,s)}(e,t,n,i,r);if(Array.isArray(t)){for(var s=0;s<t.length;s++)el(e,t[s],n,i,r);return null}return n=eg(n),e&&e[Q]?e.O(t,n,v(i)?!!i.capture:!!i,r):eh(e,t,n,!1,i,r)}function eh(e,t,n,i,r,s){if(!t)throw Error("Invalid event type");var o=v(r)?!!r.capture:!!r,a=ef(e);if(a||(e[eo]=a=new ei(e)),(n=a.add(t,n,i,o,s)).proxy)return n;if(i=function(){function e(n){return t.call(e.src,e.listener,n)}let t=ed;return e}(),n.proxy=i,i.src=e,i.listener=n,e.addEventListener)A||(r=o),void 0===r&&(r=!1),e.addEventListener(t.toString(),i,r);else if(e.attachEvent)e.attachEvent(ec(t.toString()),i);else if(e.addListener&&e.removeListener)e.addListener(i);else throw Error("addEventListener and attachEvent are unavailable.");return n}function eu(e){if("number"!=typeof e&&e&&!e.fa){var t=e.src;if(t&&t[Q])er(t.i,e);else{var n=e.type,i=e.proxy;t.removeEventListener?t.removeEventListener(n,i,e.capture):t.detachEvent?t.detachEvent(ec(n),i):t.addListener&&t.removeListener&&t.removeListener(i),(n=ef(t))?(er(n,e),0==n.h&&(n.src=null,t[eo]=null)):J(e)}}}function ec(e){return e in ea?ea[e]:ea[e]="on"+e}function ed(e,t){if(e.fa)e=!0;else{t=new K(t,this);var n=e.listener,i=e.la||e.src;e.ia&&eu(e),e=n.call(i,t)}return e}function ef(e){return(e=e[eo])instanceof ei?e:null}var ep="__closure_events_fn_"+(1e9*Math.random()>>>0);function eg(e){return"function"==typeof e?e:(e[ep]||(e[ep]=function(t){return e.handleEvent(t)}),e[ep])}function em(){C.call(this),this.i=new ei(this),this.S=this,this.J=null}function e_(e,t){var n,i=e.J;if(i)for(n=[];i;i=i.J)n.push(i);if(e=e.S,i=t.type||t,"string"==typeof t)t=new R(t,e);else if(t instanceof R)t.target=t.target||e;else{var r=t;en(t=new R(i,e),r)}if(r=!0,n)for(var s=n.length-1;0<=s;s--){var o=t.g=n[s];r=ey(o,i,!0,t)&&r}if(r=ey(o=t.g=e,i,!0,t)&&r,r=ey(o,i,!1,t)&&r,n)for(s=0;s<n.length;s++)r=ey(o=t.g=n[s],i,!1,t)&&r}function ey(e,t,n,i){if(!(t=e.i.g[String(t)]))return!0;t=t.concat();for(var r=!0,s=0;s<t.length;++s){var o=t[s];if(o&&!o.fa&&o.capture==n){var a=o.listener,l=o.la||o.src;o.ia&&er(e.i,o),r=!1!==a.call(l,i)&&r}}return r&&!i.defaultPrevented}E(em,C),em.prototype[Q]=!0,em.prototype.removeEventListener=function(e,t,n,i){!function e(t,n,i,r,s){if(Array.isArray(n))for(var o=0;o<n.length;o++)e(t,n[o],i,r,s);else(r=v(r)?!!r.capture:!!r,i=eg(i),t&&t[Q])?(t=t.i,(n=String(n).toString())in t.g&&-1<(i=es(o=t.g[n],i,r,s))&&(J(o[i]),Array.prototype.splice.call(o,i,1),0==o.length&&(delete t.g[n],t.h--))):t&&(t=ef(t))&&(n=t.g[n.toString()],t=-1,n&&(t=es(n,i,r,s)),(i=-1<t?n[t]:null)&&eu(i))}(this,e,t,n,i)},em.prototype.N=function(){if(em.$.N.call(this),this.i){var e,t=this.i;for(e in t.g){for(var n=t.g[e],i=0;i<n.length;i++)J(n[i]);delete t.g[e],t.h--}}this.J=null},em.prototype.O=function(e,t,n,i){return this.i.add(String(e),t,!1,n,i)},em.prototype.P=function(e,t,n,i){return this.i.add(String(e),t,!0,n,i)};var ev=_.JSON.stringify;function ew(){var e=ek;let t=null;return e.g&&(t=e.g,e.g=e.g.next,e.g||(e.h=null),t.next=null),t}var eb=new class{constructor(e,t){this.i=e,this.j=t,this.h=0,this.g=null}get(){let e;return 0<this.h?(this.h--,e=this.g,this.g=e.next,e.next=null):e=this.i(),e}}(()=>new eT,e=>e.reset());class eT{constructor(){this.next=this.g=this.h=null}set(e,t){this.h=e,this.g=t,this.next=null}reset(){this.next=this.g=this.h=null}}function eI(e){var t=1;e=e.split(":");let n=[];for(;0<t&&e.length;)n.push(e.shift()),t--;return e.length&&n.push(e.join(":")),n}function eE(e){_.setTimeout(()=>{throw e},0)}let eC,eS=!1,ek=new class{constructor(){this.h=this.g=null}add(e,t){let n=eb.get();n.set(e,t),this.h?this.h.next=n:this.g=n,this.h=n}},eN=()=>{let e=_.Promise.resolve(void 0);eC=()=>{e.then(eR)}};var eR=()=>{for(var e;e=ew();){try{e.h.call(e.g)}catch(t){eE(t)}var n=eb;n.j(e),100>n.h&&(n.h++,e.next=n.g,n.g=e)}eS=!1};function eA(e,t){em.call(this),this.h=e||1,this.g=t||_,this.j=T(this.qb,this),this.l=Date.now()}function eD(e){e.ga=!1,e.T&&(e.g.clearTimeout(e.T),e.T=null)}function eP(e,t,n){if("function"==typeof e)n&&(e=T(e,n));else if(e&&"function"==typeof e.handleEvent)e=T(e.handleEvent,e);else throw Error("Invalid listener argument");return 2147483647<Number(t)?-1:_.setTimeout(e,t||0)}E(eA,em),(u=eA.prototype).ga=!1,u.T=null,u.qb=function(){if(this.ga){var e=Date.now()-this.l;0<e&&e<.8*this.h?this.T=this.g.setTimeout(this.j,this.h-e):(this.T&&(this.g.clearTimeout(this.T),this.T=null),e_(this,"tick"),this.ga&&(eD(this),this.start()))}},u.start=function(){this.ga=!0,this.T||(this.T=this.g.setTimeout(this.j,this.h),this.l=Date.now())},u.N=function(){eA.$.N.call(this),eD(this),delete this.g};class eO extends C{constructor(e,t){super(),this.m=e,this.j=t,this.h=null,this.i=!1,this.g=null}l(e){this.h=arguments,this.g?this.i=!0:function e(t){t.g=eP(()=>{t.g=null,t.i&&(t.i=!1,e(t))},t.j);let n=t.h;t.h=null,t.m.apply(null,n)}(this)}N(){super.N(),this.g&&(_.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function ex(e){C.call(this),this.h=e,this.g={}}E(ex,C);var eL=[];function eM(e,t,n,i){Array.isArray(n)||(n&&(eL[0]=n.toString()),n=eL);for(var r=0;r<n.length;r++){var s=el(t,n[r],i||e.handleEvent,!1,e.h||e);if(!s)break;e.g[s.key]=s}}function eF(e){Z(e.g,function(e,t){this.g.hasOwnProperty(t)&&eu(e)},e),e.g={}}function eU(){this.g=!0}function eV(e,t,n,i){e.info(function(){return"XMLHTTP TEXT ("+t+"): "+function(e,t){if(!e.g)return t;if(!t)return null;try{var n=JSON.parse(t);if(n){for(e=0;e<n.length;e++)if(Array.isArray(n[e])){var i=n[e];if(!(2>i.length)){var r=i[1];if(Array.isArray(r)&&!(1>r.length)){var s=r[0];if("noop"!=s&&"stop"!=s&&"close"!=s)for(var o=1;o<r.length;o++)r[o]=""}}}}return ev(n)}catch(a){return t}}(e,n)+(i?" "+i:"")})}ex.prototype.N=function(){ex.$.N.call(this),eF(this)},ex.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")},eU.prototype.Ea=function(){this.g=!1},eU.prototype.info=function(){};var ej={},eq=null;function eB(){return eq=eq||new em}function ez(e){R.call(this,ej.Ta,e)}function e$(e){let t=eB();e_(t,new ez(t))}function eW(e,t){R.call(this,ej.STAT_EVENT,e),this.stat=t}function eH(e){let t=eB();e_(t,new eW(t,e))}function eK(e,t){R.call(this,ej.Ua,e),this.size=t}function eG(e,t){if("function"!=typeof e)throw Error("Fn must not be null and must be a function");return _.setTimeout(function(){e()},t)}ej.Ta="serverreachability",E(ez,R),ej.STAT_EVENT="statevent",E(eW,R),ej.Ua="timingevent",E(eK,R);var eQ={NO_ERROR:0,rb:1,Eb:2,Db:3,yb:4,Cb:5,Fb:6,Qa:7,TIMEOUT:8,Ib:9},eY={wb:"complete",Sb:"success",Ra:"error",Qa:"abort",Kb:"ready",Lb:"readystatechange",TIMEOUT:"timeout",Gb:"incrementaldata",Jb:"progress",zb:"downloadprogress",$b:"uploadprogress"};function eX(){}function eJ(e){return e.h||(e.h=e.i())}function eZ(){}eX.prototype.h=null;var e0={OPEN:"a",vb:"b",Ra:"c",Hb:"d"};function e1(){R.call(this,"d")}function e2(){R.call(this,"c")}function e4(){}function e9(e,t,n,i){this.l=e,this.j=t,this.m=n,this.W=i||1,this.U=new ex(this),this.P=e5,e=U?125:void 0,this.V=new eA(e),this.I=null,this.i=!1,this.s=this.A=this.v=this.L=this.G=this.Y=this.B=null,this.F=[],this.g=null,this.C=0,this.o=this.u=null,this.ca=-1,this.J=!1,this.O=0,this.M=null,this.ba=this.K=this.aa=this.S=!1,this.h=new e6}function e6(){this.i=null,this.g="",this.h=!1}E(e1,R),E(e2,R),E(e4,eX),e4.prototype.g=function(){return new XMLHttpRequest},e4.prototype.i=function(){return{}},a=new e4;var e5=45e3,e3={},e7={};function e8(e,t,n){e.L=1,e.v=ty(tf(t)),e.s=n,e.S=!0,te(e,null)}function te(e,t){e.G=Date.now(),tr(e),e.A=tf(e.v);var n=e.A,i=e.W;Array.isArray(i)||(i=[String(i)]),tD(n.i,"t",i),e.C=0,n=e.l.J,e.h=new e6,e.g=nb(e.l,n?t:null,!e.s),0<e.O&&(e.M=new eO(T(e.Pa,e,e.g),e.O)),eM(e.U,e.g,"readystatechange",e.nb),t=e.I?ee(e.I):{},e.s?(e.u||(e.u="POST"),t["Content-Type"]="application/x-www-form-urlencoded",e.g.ha(e.A,e.u,e.s,t)):(e.u="GET",e.g.ha(e.A,e.u,null,t)),e$(),function(e,t,n,i,r,s){e.info(function(){if(e.g){if(s)for(var o="",a=s.split("&"),l=0;l<a.length;l++){var h=a[l].split("=");if(1<h.length){var u=h[0];h=h[1];var c=u.split("_");o=2<=c.length&&"type"==c[1]?o+(u+"=")+h+"&":o+(u+"=redacted&")}}else o=null}else o=s;return"XMLHTTP REQ ("+i+") [attempt "+r+"]: "+t+"\n"+n+"\n"+o})}(e.j,e.u,e.A,e.m,e.W,e.s)}function tt(e){return!!e.g&&"GET"==e.u&&2!=e.L&&e.l.Ha}function tn(e,t,n){let i=!0,r;for(;!e.J&&e.C<n.length;)if((r=ti(e,n))==e7){4==t&&(e.o=4,eH(14),i=!1),eV(e.j,e.m,null,"[Incomplete Response]");break}else if(r==e3){e.o=4,eH(15),eV(e.j,e.m,n,"[Invalid Chunk]"),i=!1;break}else eV(e.j,e.m,r,null),th(e,r);tt(e)&&r!=e7&&r!=e3&&(e.h.g="",e.C=0),4!=t||0!=n.length||e.h.h||(e.o=1,eH(16),i=!1),e.i=e.i&&i,i?0<n.length&&!e.ba&&(e.ba=!0,(t=e.l).g==e&&t.ca&&!t.M&&(t.l.info("Great, no buffering proxy detected. Bytes received: "+n.length),nf(t),t.M=!0,eH(11))):(eV(e.j,e.m,n,"[Invalid Chunked Response]"),tl(e),ta(e))}function ti(e,t){var n=e.C,i=t.indexOf("\n",n);return -1==i?e7:isNaN(n=Number(t.substring(n,i)))?e3:(i+=1)+n>t.length?e7:(t=t.slice(i,i+n),e.C=i+n,t)}function tr(e){e.Y=Date.now()+e.P,ts(e,e.P)}function ts(e,t){if(null!=e.B)throw Error("WatchDog timer not null");e.B=eG(T(e.lb,e),t)}function to(e){e.B&&(_.clearTimeout(e.B),e.B=null)}function ta(e){0==e.l.H||e.J||nm(e.l,e)}function tl(e){to(e);var t=e.M;t&&"function"==typeof t.sa&&t.sa(),e.M=null,eD(e.V),eF(e.U),e.g&&(t=e.g,e.g=null,t.abort(),t.sa())}function th(e,t){try{var n=e.l;if(0!=n.H&&(n.g==e||tU(n.i,e))){if(!e.K&&tU(n.i,e)&&3==n.H){try{var i=n.Ja.g.parse(t)}catch(r){i=null}if(Array.isArray(i)&&3==i.length){var s=i;if(0==s[0]){a:if(!n.u){if(n.g){if(n.g.G+3e3<e.G)ng(n),ns(n);else break a}nd(n),eH(18)}}else n.Fa=s[1],0<n.Fa-n.V&&37500>s[2]&&n.G&&0==n.A&&!n.v&&(n.v=eG(T(n.ib,n),6e3));if(1>=tF(n.i)&&n.oa){try{n.oa()}catch(o){}n.oa=void 0}}else ny(n,11)}else if((e.K||n.g==e)&&ng(n),!D(t))for(s=n.Ja.g.parse(t),t=0;t<s.length;t++){let a=s[t];if(n.V=a[0],a=a[1],2==n.H){if("c"==a[0]){n.K=a[1],n.pa=a[2];let l=a[3];null!=l&&(n.ra=l,n.l.info("VER="+n.ra));let h=a[4];null!=h&&(n.Ga=h,n.l.info("SVER="+n.Ga));let u=a[5];null!=u&&"number"==typeof u&&0<u&&(i=1.5*u,n.L=i,n.l.info("backChannelRequestTimeoutMs_="+i)),i=n;let c=e.g;if(c){let d=c.g?c.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(d){var f=i.i;f.g||-1==d.indexOf("spdy")&&-1==d.indexOf("quic")&&-1==d.indexOf("h2")||(f.j=f.l,f.g=new Set,f.h&&(tV(f,f.h),f.h=null))}if(i.F){let p=c.g?c.g.getResponseHeader("X-HTTP-Session-Id"):null;p&&(i.Da=p,t_(i.I,i.F,p))}}if(n.H=3,n.h&&n.h.Ba(),n.ca&&(n.S=Date.now()-e.G,n.l.info("Handshake RTT: "+n.S+"ms")),(i=n).wa=nw(i,i.J?i.pa:null,i.Y),e.K){tj(i.i,e);var g=i.L;g&&e.setTimeout(g),e.B&&(to(e),tr(e)),i.g=e}else nc(i);0<n.j.length&&na(n)}else"stop"!=a[0]&&"close"!=a[0]||ny(n,7)}else 3==n.H&&("stop"==a[0]||"close"==a[0]?"stop"==a[0]?ny(n,7):nr(n):"noop"!=a[0]&&n.h&&n.h.Aa(a),n.A=0)}}e$(4)}catch(m){}}function tu(e,t){if(e.forEach&&"function"==typeof e.forEach)e.forEach(t,void 0);else if(y(e)||"string"==typeof e)Array.prototype.forEach.call(e,t,void 0);else for(var n=function(e){if(e.ta&&"function"==typeof e.ta)return e.ta();if(!e.Z||"function"!=typeof e.Z){if("undefined"!=typeof Map&&e instanceof Map)return Array.from(e.keys());if(!("undefined"!=typeof Set&&e instanceof Set)){if(y(e)||"string"==typeof e){var t=[];e=e.length;for(var n=0;n<e;n++)t.push(n);return t}for(let i in t=[],n=0,e)t[n++]=i;return t}}}(e),i=function(e){if(e.Z&&"function"==typeof e.Z)return e.Z();if("undefined"!=typeof Map&&e instanceof Map||"undefined"!=typeof Set&&e instanceof Set)return Array.from(e.values());if("string"==typeof e)return e.split("");if(y(e)){for(var t=[],n=e.length,i=0;i<n;i++)t.push(e[i]);return t}for(i in t=[],n=0,e)t[n++]=e[i];return t}(e),r=i.length,s=0;s<r;s++)t.call(void 0,i[s],n&&n[s],e)}(u=e9.prototype).setTimeout=function(e){this.P=e},u.nb=function(e){e=e.target;let t=this.M;t&&3==t7(e)?t.l():this.Pa(e)},u.Pa=function(e){try{if(e==this.g)a:{let t=t7(this.g);var n=this.g.Ia();let i=this.g.da();if(!(3>t)&&(3!=t||U||this.g&&(this.h.h||this.g.ja()||t8(this.g)))){this.J||4!=t||7==n||(8==n||0>=i?e$(3):e$(2)),to(this);var r=this.g.da();this.ca=r;b:if(tt(this)){var s=t8(this.g);e="";var o=s.length,a=4==t7(this.g);if(!this.h.i){if("undefined"==typeof TextDecoder){tl(this),ta(this);var l="";break b}this.h.i=new _.TextDecoder}for(n=0;n<o;n++)this.h.h=!0,e+=this.h.i.decode(s[n],{stream:a&&n==o-1});s.splice(0,o),this.h.g+=e,this.C=0,l=this.h.g}else l=this.g.ja();if(this.i=200==r,function(e,t,n,i,r,s,o){e.info(function(){return"XMLHTTP RESP ("+i+") [ attempt "+r+"]: "+t+"\n"+n+"\n"+s+" "+o})}(this.j,this.u,this.A,this.m,this.W,t,r),this.i){if(this.aa&&!this.K){b:{if(this.g){var h,u=this.g;if((h=u.g?u.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!D(h)){var c=h;break b}}c=null}if(r=c)eV(this.j,this.m,r,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,th(this,r);else{this.i=!1,this.o=3,eH(12),tl(this),ta(this);break a}}this.S?(tn(this,t,l),U&&this.i&&3==t&&(eM(this.U,this.V,"tick",this.mb),this.V.start())):(eV(this.j,this.m,l,null),th(this,l)),4==t&&tl(this),this.i&&!this.J&&(4==t?nm(this.l,this):(this.i=!1,tr(this)))}else(function(e){let t={};e=(e.g&&2<=t7(e)&&e.g.getAllResponseHeaders()||"").split("\r\n");for(let n=0;n<e.length;n++){if(D(e[n]))continue;var i=eI(e[n]);let r=i[0];if("string"!=typeof(i=i[1]))continue;i=i.trim();let s=t[r]||[];t[r]=s,s.push(i)}!function(e,t){for(let n in e)t.call(void 0,e[n],n,e)}(t,function(e){return e.join(", ")})})(this.g),400==r&&0<l.indexOf("Unknown SID")?(this.o=3,eH(12)):(this.o=0,eH(13)),tl(this),ta(this)}}}catch(d){}finally{}},u.mb=function(){if(this.g){var e=t7(this.g),t=this.g.ja();this.C<t.length&&(to(this),tn(this,e,t),this.i&&4!=e&&tr(this))}},u.cancel=function(){this.J=!0,tl(this)},u.lb=function(){this.B=null;let e=Date.now();0<=e-this.Y?(function(e,t){e.info(function(){return"TIMEOUT: "+t})}(this.j,this.A),2!=this.L&&(e$(),eH(17)),tl(this),this.o=2,ta(this)):ts(this,this.Y-e)};var tc=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function td(e){if(this.g=this.s=this.j="",this.m=null,this.o=this.l="",this.h=!1,e instanceof td){this.h=e.h,tp(this,e.j),this.s=e.s,this.g=e.g,tg(this,e.m),this.l=e.l;var t=e.i,n=new tk;n.i=t.i,t.g&&(n.g=new Map(t.g),n.h=t.h),tm(this,n),this.o=e.o}else e&&(t=String(e).match(tc))?(this.h=!1,tp(this,t[1]||"",!0),this.s=tv(t[2]||""),this.g=tv(t[3]||"",!0),tg(this,t[4]),this.l=tv(t[5]||"",!0),tm(this,t[6]||"",!0),this.o=tv(t[7]||"")):(this.h=!1,this.i=new tk(null,this.h))}function tf(e){return new td(e)}function tp(e,t,n){e.j=n?tv(t,!0):t,e.j&&(e.j=e.j.replace(/:$/,""))}function tg(e,t){if(t){if(isNaN(t=Number(t))||0>t)throw Error("Bad port number "+t);e.m=t}else e.m=null}function tm(e,t,n){var i,r;t instanceof tk?(e.i=t,i=e.i,(r=e.h)&&!i.j&&(tN(i),i.i=null,i.g.forEach(function(e,t){var n=t.toLowerCase();t!=n&&(tR(this,t),tD(this,n,e))},i)),i.j=r):(n||(t=tw(t,tC)),e.i=new tk(t,e.h))}function t_(e,t,n){e.i.set(t,n)}function ty(e){return t_(e,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),e}function tv(e,t){return e?t?decodeURI(e.replace(/%25/g,"%2525")):decodeURIComponent(e):""}function tw(e,t,n){return"string"==typeof e?(e=encodeURI(e).replace(t,tb),n&&(e=e.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),e):null}function tb(e){return"%"+((e=e.charCodeAt(0))>>4&15).toString(16)+(15&e).toString(16)}td.prototype.toString=function(){var e=[],t=this.j;t&&e.push(tw(t,tT,!0),":");var n=this.g;return(n||"file"==t)&&(e.push("//"),(t=this.s)&&e.push(tw(t,tT,!0),"@"),e.push(encodeURIComponent(String(n)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),null!=(n=this.m)&&e.push(":",String(n))),(n=this.l)&&(this.g&&"/"!=n.charAt(0)&&e.push("/"),e.push(tw(n,"/"==n.charAt(0)?tE:tI,!0))),(n=this.i.toString())&&e.push("?",n),(n=this.o)&&e.push("#",tw(n,tS)),e.join("")};var tT=/[#\/\?@]/g,tI=/[#\?:]/g,tE=/[#\?]/g,tC=/[#\?@]/g,tS=/#/g;function tk(e,t){this.h=this.g=null,this.i=e||null,this.j=!!t}function tN(e){e.g||(e.g=new Map,e.h=0,e.i&&function(e,t){if(e){e=e.split("&");for(var n=0;n<e.length;n++){var i=e[n].indexOf("="),r=null;if(0<=i){var s=e[n].substring(0,i);r=e[n].substring(i+1)}else s=e[n];t(s,r?decodeURIComponent(r.replace(/\+/g," ")):"")}}}(e.i,function(t,n){e.add(decodeURIComponent(t.replace(/\+/g," ")),n)}))}function tR(e,t){tN(e),t=tP(e,t),e.g.has(t)&&(e.i=null,e.h-=e.g.get(t).length,e.g.delete(t))}function tA(e,t){return tN(e),t=tP(e,t),e.g.has(t)}function tD(e,t,n){tR(e,t),0<n.length&&(e.i=null,e.g.set(tP(e,t),k(n)),e.h+=n.length)}function tP(e,t){return t=String(t),e.j&&(t=t.toLowerCase()),t}(u=tk.prototype).add=function(e,t){tN(this),this.i=null,e=tP(this,e);var n=this.g.get(e);return n||this.g.set(e,n=[]),n.push(t),this.h+=1,this},u.forEach=function(e,t){tN(this),this.g.forEach(function(n,i){n.forEach(function(n){e.call(t,n,i,this)},this)},this)},u.ta=function(){tN(this);let e=Array.from(this.g.values()),t=Array.from(this.g.keys()),n=[];for(let i=0;i<t.length;i++){let r=e[i];for(let s=0;s<r.length;s++)n.push(t[i])}return n},u.Z=function(e){tN(this);let t=[];if("string"==typeof e)tA(this,e)&&(t=t.concat(this.g.get(tP(this,e))));else{e=Array.from(this.g.values());for(let n=0;n<e.length;n++)t=t.concat(e[n])}return t},u.set=function(e,t){return tN(this),this.i=null,tA(this,e=tP(this,e))&&(this.h-=this.g.get(e).length),this.g.set(e,[t]),this.h+=1,this},u.get=function(e,t){return e&&0<(e=this.Z(e)).length?String(e[0]):t},u.toString=function(){if(this.i)return this.i;if(!this.g)return"";let e=[],t=Array.from(this.g.keys());for(var n=0;n<t.length;n++){var i=t[n];let r=encodeURIComponent(String(i)),s=this.Z(i);for(i=0;i<s.length;i++){var o=r;""!==s[i]&&(o+="="+encodeURIComponent(String(s[i]))),e.push(o)}}return this.i=e.join("&")};var tO=class{constructor(e,t){this.g=e,this.map=t}};function tx(e){this.l=e||tL,e=_.PerformanceNavigationTiming?0<(e=_.performance.getEntriesByType("navigation")).length&&("hq"==e[0].nextHopProtocol||"h2"==e[0].nextHopProtocol):!!(_.g&&_.g.Ka&&_.g.Ka()&&_.g.Ka().dc),this.j=e?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}var tL=10;function tM(e){return!!e.h||!!e.g&&e.g.size>=e.j}function tF(e){return e.h?1:e.g?e.g.size:0}function tU(e,t){return e.h?e.h==t:!!e.g&&e.g.has(t)}function tV(e,t){e.g?e.g.add(t):e.h=t}function tj(e,t){e.h&&e.h==t?e.h=null:e.g&&e.g.has(t)&&e.g.delete(t)}function tq(e){if(null!=e.h)return e.i.concat(e.h.F);if(null!=e.g&&0!==e.g.size){let t=e.i;for(let n of e.g.values())t=t.concat(n.F);return t}return k(e.i)}tx.prototype.cancel=function(){if(this.i=tq(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&0!==this.g.size){for(let e of this.g.values())e.cancel();this.g.clear()}};var tB=class{stringify(e){return _.JSON.stringify(e,void 0)}parse(e){return _.JSON.parse(e,void 0)}};function tz(){this.g=new tB}function t$(e,t,n){let i=n||"";try{tu(e,function(e,n){let r=e;v(e)&&(r=ev(e)),t.push(i+n+"="+encodeURIComponent(r))})}catch(r){throw t.push(i+"type="+encodeURIComponent("_badmap")),r}}function tW(e,t,n,i,r){try{t.onload=null,t.onerror=null,t.onabort=null,t.ontimeout=null,r(i)}catch(s){}}function tH(e){this.l=e.ec||null,this.j=e.ob||!1}function tK(e,t){em.call(this),this.F=e,this.u=t,this.m=void 0,this.readyState=tG,this.status=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.v=new Headers,this.h=null,this.C="GET",this.B="",this.g=!1,this.A=this.j=this.l=null}E(tH,eX),tH.prototype.g=function(){return new tK(this.l,this.j)},tH.prototype.i=(r={},function(){return r}),E(tK,em);var tG=0;function tQ(e){e.j.read().then(e.Xa.bind(e)).catch(e.ka.bind(e))}function tY(e){e.readyState=4,e.l=null,e.j=null,e.A=null,tX(e)}function tX(e){e.onreadystatechange&&e.onreadystatechange.call(e)}(u=tK.prototype).open=function(e,t){if(this.readyState!=tG)throw this.abort(),Error("Error reopening a connection");this.C=e,this.B=t,this.readyState=1,tX(this)},u.send=function(e){if(1!=this.readyState)throw this.abort(),Error("need to call open() first. ");this.g=!0;let t={headers:this.v,method:this.C,credentials:this.m,cache:void 0};e&&(t.body=e),(this.F||_).fetch(new Request(this.B,t)).then(this.$a.bind(this),this.ka.bind(this))},u.abort=function(){this.response=this.responseText="",this.v=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&4!=this.readyState&&(this.g=!1,tY(this)),this.readyState=tG},u.$a=function(e){if(this.g&&(this.l=e,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=e.headers,this.readyState=2,tX(this)),this.g&&(this.readyState=3,tX(this),this.g))){if("arraybuffer"===this.responseType)e.arrayBuffer().then(this.Ya.bind(this),this.ka.bind(this));else if(void 0!==_.ReadableStream&&"body"in e){if(this.j=e.body.getReader(),this.u){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.A=new TextDecoder;tQ(this)}else e.text().then(this.Za.bind(this),this.ka.bind(this))}},u.Xa=function(e){if(this.g){if(this.u&&e.value)this.response.push(e.value);else if(!this.u){var t=e.value?e.value:new Uint8Array(0);(t=this.A.decode(t,{stream:!e.done}))&&(this.response=this.responseText+=t)}e.done?tY(this):tX(this),3==this.readyState&&tQ(this)}},u.Za=function(e){this.g&&(this.response=this.responseText=e,tY(this))},u.Ya=function(e){this.g&&(this.response=e,tY(this))},u.ka=function(){this.g&&tY(this)},u.setRequestHeader=function(e,t){this.v.append(e,t)},u.getResponseHeader=function(e){return this.h&&this.h.get(e.toLowerCase())||""},u.getAllResponseHeaders=function(){if(!this.h)return"";let e=[],t=this.h.entries();for(var n=t.next();!n.done;)e.push((n=n.value)[0]+": "+n[1]),n=t.next();return e.join("\r\n")},Object.defineProperty(tK.prototype,"withCredentials",{get:function(){return"include"===this.m},set:function(e){this.m=e?"include":"same-origin"}});var tJ=_.JSON.parse;function tZ(e){em.call(this),this.headers=new Map,this.u=e||null,this.h=!1,this.C=this.g=null,this.I="",this.m=0,this.j="",this.l=this.G=this.v=this.F=!1,this.B=0,this.A=null,this.K=t0,this.L=this.M=!1}E(tZ,em);var t0="",t1=/^https?$/i,t2=["POST","PUT"];function t4(e,t){e.h=!1,e.g&&(e.l=!0,e.g.abort(),e.l=!1),e.j=t,e.m=5,t9(e),t5(e)}function t9(e){e.F||(e.F=!0,e_(e,"complete"),e_(e,"error"))}function t6(e){if(e.h&&void 0!==m&&(!e.C[1]||4!=t7(e)||2!=e.da())){if(e.v&&4==t7(e))eP(e.La,0,e);else if(e_(e,"readystatechange"),4==t7(e)){e.h=!1;try{let t=e.da();a:switch(t){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var n,i,r=!0;break a;default:r=!1}if(!(n=r)){if(i=0===t){var s=String(e.I).match(tc)[1]||null;!s&&_.self&&_.self.location&&(s=_.self.location.protocol.slice(0,-1)),i=!t1.test(s?s.toLowerCase():"")}n=i}if(n)e_(e,"complete"),e_(e,"success");else{e.m=6;try{var o=2<t7(e)?e.g.statusText:""}catch(a){o=""}e.j=o+" ["+e.da()+"]",t9(e)}}finally{t5(e)}}}}function t5(e,t){if(e.g){t3(e);let n=e.g,i=e.C[0]?()=>{}:null;e.g=null,e.C=null,t||e_(e,"ready");try{n.onreadystatechange=i}catch(r){}}}function t3(e){e.g&&e.L&&(e.g.ontimeout=null),e.A&&(_.clearTimeout(e.A),e.A=null)}function t7(e){return e.g?e.g.readyState:0}function t8(e){try{if(!e.g)return null;if("response"in e.g)return e.g.response;switch(e.K){case t0:case"text":return e.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in e.g)return e.g.mozResponseArrayBuffer}return null}catch(t){return null}}function ne(e){let t="";return Z(e,function(e,n){t+=n,t+=":",t+=e,t+="\r\n"}),t}function nt(e,t,n){a:{for(i in n){var i=!1;break a}i=!0}i||(n=ne(n),"string"==typeof e?null!=n&&encodeURIComponent(String(n)):t_(e,t,n))}function nn(e,t,n){return n&&n.internalChannelParams&&n.internalChannelParams[e]||t}function ni(e){this.Ga=0,this.j=[],this.l=new eU,this.pa=this.wa=this.I=this.Y=this.g=this.Da=this.F=this.na=this.o=this.U=this.s=null,this.fb=this.W=0,this.cb=nn("failFast",!1,e),this.G=this.v=this.u=this.m=this.h=null,this.aa=!0,this.Fa=this.V=-1,this.ba=this.A=this.C=0,this.ab=nn("baseRetryDelayMs",5e3,e),this.hb=nn("retryDelaySeedMs",1e4,e),this.eb=nn("forwardChannelMaxRetries",2,e),this.xa=nn("forwardChannelRequestTimeoutMs",2e4,e),this.va=e&&e.xmlHttpFactory||void 0,this.Ha=e&&e.useFetchStreams||!1,this.L=void 0,this.J=e&&e.supportsCrossDomainXhr||!1,this.K="",this.i=new tx(e&&e.concurrentRequestLimit),this.Ja=new tz,this.P=e&&e.fastHandshake||!1,this.O=e&&e.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.bb=e&&e.bc||!1,e&&e.Ea&&this.l.Ea(),e&&e.forceLongPolling&&(this.aa=!1),this.ca=!this.P&&this.aa&&e&&e.detectBufferingProxy||!1,this.qa=void 0,e&&e.longPollingTimeout&&0<e.longPollingTimeout&&(this.qa=e.longPollingTimeout),this.oa=void 0,this.S=0,this.M=!1,this.ma=this.B=null}function nr(e){if(no(e),3==e.H){var t=e.W++,n=tf(e.I);if(t_(n,"SID",e.K),t_(n,"RID",t),t_(n,"TYPE","terminate"),nh(e,n),(t=new e9(e,e.l,t)).L=2,t.v=ty(tf(n)),n=!1,_.navigator&&_.navigator.sendBeacon)try{n=_.navigator.sendBeacon(t.v.toString(),"")}catch(i){}!n&&_.Image&&((new Image).src=t.v,n=!0),n||(t.g=nb(t.l,null),t.g.ha(t.v)),t.G=Date.now(),tr(t)}nv(e)}function ns(e){e.g&&(nf(e),e.g.cancel(),e.g=null)}function no(e){ns(e),e.u&&(_.clearTimeout(e.u),e.u=null),ng(e),e.i.cancel(),e.m&&("number"==typeof e.m&&_.clearTimeout(e.m),e.m=null)}function na(e){if(!tM(e.i)&&!e.m){e.m=!0;var t=e.Na;eC||eN(),eS||(eC(),eS=!0),ek.add(t,e),e.C=0}}function nl(e,t){var n;n=t?t.m:e.W++;let i=tf(e.I);t_(i,"SID",e.K),t_(i,"RID",n),t_(i,"AID",e.V),nh(e,i),e.o&&e.s&&nt(i,e.o,e.s),n=new e9(e,e.l,n,e.C+1),null===e.o&&(n.I=e.s),t&&(e.j=t.F.concat(e.j)),t=nu(e,n,1e3),n.setTimeout(Math.round(.5*e.xa)+Math.round(.5*e.xa*Math.random())),tV(e.i,n),e8(n,i,t)}function nh(e,t){e.na&&Z(e.na,function(e,n){t_(t,n,e)}),e.h&&tu({},function(e,n){t_(t,n,e)})}function nu(e,t,n){n=Math.min(e.j.length,n);var i=e.h?T(e.h.Va,e.h,e):null;a:{var r=e.j;let s=-1;for(;;){let o=["count="+n];-1==s?0<n?(s=r[0].g,o.push("ofs="+s)):s=0:o.push("ofs="+s);let a=!0;for(let l=0;l<n;l++){let h=r[l].g,u=r[l].map;if(0>(h-=s))s=Math.max(0,r[l].g-100),a=!1;else try{t$(u,o,"req"+h+"_")}catch(c){i&&i(u)}}if(a){i=o.join("&");break a}}}return e=e.j.splice(0,n),t.F=e,i}function nc(e){if(!e.g&&!e.u){e.ba=1;var t=e.Ma;eC||eN(),eS||(eC(),eS=!0),ek.add(t,e),e.A=0}}function nd(e){return!e.g&&!e.u&&!(3<=e.A)&&(e.ba++,e.u=eG(T(e.Ma,e),n_(e,e.A)),e.A++,!0)}function nf(e){null!=e.B&&(_.clearTimeout(e.B),e.B=null)}function np(e){e.g=new e9(e,e.l,"rpc",e.ba),null===e.o&&(e.g.I=e.s),e.g.O=0;var t=tf(e.wa);t_(t,"RID","rpc"),t_(t,"SID",e.K),t_(t,"AID",e.V),t_(t,"CI",e.G?"0":"1"),!e.G&&e.qa&&t_(t,"TO",e.qa),t_(t,"TYPE","xmlhttp"),nh(e,t),e.o&&e.s&&nt(t,e.o,e.s),e.L&&e.g.setTimeout(e.L);var n=e.g;e=e.pa,n.L=1,n.v=ty(tf(t)),n.s=null,n.S=!0,te(n,e)}function ng(e){null!=e.v&&(_.clearTimeout(e.v),e.v=null)}function nm(e,t){var n=null;if(e.g==t){ng(e),nf(e),e.g=null;var i=2}else{if(!tU(e.i,t))return;n=t.F,tj(e.i,t),i=1}if(0!=e.H){if(t.i){if(1==i){n=t.s?t.s.length:0,t=Date.now()-t.G;var r,s,o=e.C;e_(i=eB(),new eK(i,n)),na(e)}else nc(e)}else if(3==(o=t.o)||0==o&&0<t.ca||!(1==i&&(r=e,s=t,!(tF(r.i)>=r.i.j-(r.m?1:0))&&(r.m?(r.j=s.F.concat(r.j),!0):1!=r.H&&2!=r.H&&!(r.C>=(r.cb?0:r.eb))&&(r.m=eG(T(r.Na,r,s),n_(r,r.C)),r.C++,!0)))||2==i&&nd(e)))switch(n&&0<n.length&&((t=e.i).i=t.i.concat(n)),o){case 1:ny(e,5);break;case 4:ny(e,10);break;case 3:ny(e,6);break;default:ny(e,2)}}}function n_(e,t){let n=e.ab+Math.floor(Math.random()*e.hb);return e.isActive()||(n*=2),n*t}function ny(e,t){if(e.l.info("Error code "+t),2==t){var n=null;e.h&&(n=null);var i=T(e.pb,e);n||(n=new td("//www.google.com/images/cleardot.gif"),_.location&&"http"==_.location.protocol||tp(n,"https"),ty(n)),function(e,t){let n=new eU;if(_.Image){let i=new Image;i.onload=I(tW,n,i,"TestLoadImage: loaded",!0,t),i.onerror=I(tW,n,i,"TestLoadImage: error",!1,t),i.onabort=I(tW,n,i,"TestLoadImage: abort",!1,t),i.ontimeout=I(tW,n,i,"TestLoadImage: timeout",!1,t),_.setTimeout(function(){i.ontimeout&&i.ontimeout()},1e4),i.src=e}else t(!1)}(n.toString(),i)}else eH(2);e.H=0,e.h&&e.h.za(t),nv(e),no(e)}function nv(e){if(e.H=0,e.ma=[],e.h){let t=tq(e.i);(0!=t.length||0!=e.j.length)&&(N(e.ma,t),N(e.ma,e.j),e.i.i.length=0,k(e.j),e.j.length=0),e.h.ya()}}function nw(e,t,n){var i=n instanceof td?tf(n):new td(n);if(""!=i.g)t&&(i.g=t+"."+i.g),tg(i,i.m);else{var r=_.location;i=r.protocol,t=t?t+"."+r.hostname:r.hostname,r=+r.port;var s=new td(null);i&&tp(s,i),t&&(s.g=t),r&&tg(s,r),n&&(s.l=n),i=s}return n=e.F,t=e.Da,n&&t&&t_(i,n,t),t_(i,"VER",e.ra),nh(e,i),i}function nb(e,t,n){if(t&&!e.J)throw Error("Can't create secondary domain capable XhrIo object.");return(t=new tZ(n&&e.Ha&&!e.va?new tH({ob:!0}):e.va)).Oa(e.J),t}function nT(){}function nI(){if(M&&!(10<=Number(H)))throw Error("Environmental error: no available transport.")}function nE(e,t){em.call(this),this.g=new ni(t),this.l=e,this.h=t&&t.messageUrlParams||null,e=t&&t.messageHeaders||null,t&&t.clientProtocolHeaderRequired&&(e?e["X-Client-Protocol"]="webchannel":e={"X-Client-Protocol":"webchannel"}),this.g.s=e,e=t&&t.initMessageHeaders||null,t&&t.messageContentType&&(e?e["X-WebChannel-Content-Type"]=t.messageContentType:e={"X-WebChannel-Content-Type":t.messageContentType}),t&&t.Ca&&(e?e["X-WebChannel-Client-Profile"]=t.Ca:e={"X-WebChannel-Client-Profile":t.Ca}),this.g.U=e,(e=t&&t.cc)&&!D(e)&&(this.g.o=e),this.A=t&&t.supportsCrossDomainXhr||!1,this.v=t&&t.sendRawJson||!1,(t=t&&t.httpSessionIdParam)&&!D(t)&&(this.g.F=t,null!==(e=this.h)&&t in e&&t in(e=this.h)&&delete e[t]),this.j=new nk(this)}function nC(e){e1.call(this),e.__headers__&&(this.headers=e.__headers__,this.statusCode=e.__status__,delete e.__headers__,delete e.__status__);var t=e.__sm__;if(t){a:{for(let n in t){e=n;break a}e=void 0}(this.i=e)&&(e=this.i,t=null!==t&&e in t?t[e]:void 0),this.data=t}else this.data=e}function nS(){e2.call(this),this.status=1}function nk(e){this.g=e}function nN(){this.blockSize=-1,this.blockSize=64,this.g=[,,,,],this.m=Array(this.blockSize),this.i=this.h=0,this.reset()}function nR(e,t,n){n||(n=0);var i=Array(16);if("string"==typeof t)for(var r=0;16>r;++r)i[r]=t.charCodeAt(n++)|t.charCodeAt(n++)<<8|t.charCodeAt(n++)<<16|t.charCodeAt(n++)<<24;else for(r=0;16>r;++r)i[r]=t[n++]|t[n++]<<8|t[n++]<<16|t[n++]<<24;t=e.g[0],n=e.g[1],r=e.g[2];var s=e.g[3],o=t+(s^n&(r^s))+i[0]+3614090360&4294967295;o=s+(r^(t=n+(o<<7&4294967295|o>>>25))&(n^r))+i[1]+3905402710&4294967295,o=r+(n^(s=t+(o<<12&4294967295|o>>>20))&(t^n))+i[2]+606105819&4294967295,o=n+(t^(r=s+(o<<17&4294967295|o>>>15))&(s^t))+i[3]+3250441966&4294967295,o=t+(s^(n=r+(o<<22&4294967295|o>>>10))&(r^s))+i[4]+4118548399&4294967295,o=s+(r^(t=n+(o<<7&4294967295|o>>>25))&(n^r))+i[5]+1200080426&4294967295,o=r+(n^(s=t+(o<<12&4294967295|o>>>20))&(t^n))+i[6]+2821735955&4294967295,o=n+(t^(r=s+(o<<17&4294967295|o>>>15))&(s^t))+i[7]+4249261313&4294967295,o=t+(s^(n=r+(o<<22&4294967295|o>>>10))&(r^s))+i[8]+1770035416&4294967295,o=s+(r^(t=n+(o<<7&4294967295|o>>>25))&(n^r))+i[9]+2336552879&4294967295,o=r+(n^(s=t+(o<<12&4294967295|o>>>20))&(t^n))+i[10]+4294925233&4294967295,o=n+(t^(r=s+(o<<17&4294967295|o>>>15))&(s^t))+i[11]+2304563134&4294967295,o=t+(s^(n=r+(o<<22&4294967295|o>>>10))&(r^s))+i[12]+1804603682&4294967295,o=s+(r^(t=n+(o<<7&4294967295|o>>>25))&(n^r))+i[13]+4254626195&4294967295,o=r+(n^(s=t+(o<<12&4294967295|o>>>20))&(t^n))+i[14]+2792965006&4294967295,o=n+(t^(r=s+(o<<17&4294967295|o>>>15))&(s^t))+i[15]+1236535329&4294967295,n=r+(o<<22&4294967295|o>>>10),o=t+(r^s&(n^r))+i[1]+4129170786&4294967295,t=n+(o<<5&4294967295|o>>>27),o=s+(n^r&(t^n))+i[6]+3225465664&4294967295,s=t+(o<<9&4294967295|o>>>23),o=r+(t^n&(s^t))+i[11]+643717713&4294967295,r=s+(o<<14&4294967295|o>>>18),o=n+(s^t&(r^s))+i[0]+3921069994&4294967295,n=r+(o<<20&4294967295|o>>>12),o=t+(r^s&(n^r))+i[5]+3593408605&4294967295,t=n+(o<<5&4294967295|o>>>27),o=s+(n^r&(t^n))+i[10]+38016083&4294967295,s=t+(o<<9&4294967295|o>>>23),o=r+(t^n&(s^t))+i[15]+3634488961&4294967295,r=s+(o<<14&4294967295|o>>>18),o=n+(s^t&(r^s))+i[4]+3889429448&4294967295,n=r+(o<<20&4294967295|o>>>12),o=t+(r^s&(n^r))+i[9]+568446438&4294967295,t=n+(o<<5&4294967295|o>>>27),o=s+(n^r&(t^n))+i[14]+3275163606&4294967295,s=t+(o<<9&4294967295|o>>>23),o=r+(t^n&(s^t))+i[3]+4107603335&4294967295,r=s+(o<<14&4294967295|o>>>18),o=n+(s^t&(r^s))+i[8]+1163531501&4294967295,n=r+(o<<20&4294967295|o>>>12),o=t+(r^s&(n^r))+i[13]+2850285829&4294967295,t=n+(o<<5&4294967295|o>>>27),o=s+(n^r&(t^n))+i[2]+4243563512&4294967295,s=t+(o<<9&4294967295|o>>>23),o=r+(t^n&(s^t))+i[7]+1735328473&4294967295,r=s+(o<<14&4294967295|o>>>18),o=n+(s^t&(r^s))+i[12]+2368359562&4294967295,o=t+((n=r+(o<<20&4294967295|o>>>12))^r^s)+i[5]+4294588738&4294967295,o=s+((t=n+(o<<4&4294967295|o>>>28))^n^r)+i[8]+2272392833&4294967295,o=r+((s=t+(o<<11&4294967295|o>>>21))^t^n)+i[11]+1839030562&4294967295,o=n+((r=s+(o<<16&4294967295|o>>>16))^s^t)+i[14]+4259657740&4294967295,o=t+((n=r+(o<<23&4294967295|o>>>9))^r^s)+i[1]+2763975236&4294967295,o=s+((t=n+(o<<4&4294967295|o>>>28))^n^r)+i[4]+1272893353&4294967295,o=r+((s=t+(o<<11&4294967295|o>>>21))^t^n)+i[7]+4139469664&4294967295,o=n+((r=s+(o<<16&4294967295|o>>>16))^s^t)+i[10]+3200236656&4294967295,o=t+((n=r+(o<<23&4294967295|o>>>9))^r^s)+i[13]+681279174&4294967295,o=s+((t=n+(o<<4&4294967295|o>>>28))^n^r)+i[0]+3936430074&4294967295,o=r+((s=t+(o<<11&4294967295|o>>>21))^t^n)+i[3]+3572445317&4294967295,o=n+((r=s+(o<<16&4294967295|o>>>16))^s^t)+i[6]+76029189&4294967295,o=t+((n=r+(o<<23&4294967295|o>>>9))^r^s)+i[9]+3654602809&4294967295,o=s+((t=n+(o<<4&4294967295|o>>>28))^n^r)+i[12]+3873151461&4294967295,o=r+((s=t+(o<<11&4294967295|o>>>21))^t^n)+i[15]+530742520&4294967295,o=n+((r=s+(o<<16&4294967295|o>>>16))^s^t)+i[2]+3299628645&4294967295,n=r+(o<<23&4294967295|o>>>9),o=t+(r^(n|~s))+i[0]+4096336452&4294967295,t=n+(o<<6&4294967295|o>>>26),o=s+(n^(t|~r))+i[7]+1126891415&4294967295,s=t+(o<<10&4294967295|o>>>22),o=r+(t^(s|~n))+i[14]+2878612391&4294967295,r=s+(o<<15&4294967295|o>>>17),o=n+(s^(r|~t))+i[5]+4237533241&4294967295,n=r+(o<<21&4294967295|o>>>11),o=t+(r^(n|~s))+i[12]+1700485571&4294967295,t=n+(o<<6&4294967295|o>>>26),o=s+(n^(t|~r))+i[3]+2399980690&4294967295,s=t+(o<<10&4294967295|o>>>22),o=r+(t^(s|~n))+i[10]+4293915773&4294967295,r=s+(o<<15&4294967295|o>>>17),o=n+(s^(r|~t))+i[1]+2240044497&4294967295,n=r+(o<<21&4294967295|o>>>11),o=t+(r^(n|~s))+i[8]+1873313359&4294967295,t=n+(o<<6&4294967295|o>>>26),o=s+(n^(t|~r))+i[15]+4264355552&4294967295,s=t+(o<<10&4294967295|o>>>22),o=r+(t^(s|~n))+i[6]+2734768916&4294967295,r=s+(o<<15&4294967295|o>>>17),o=n+(s^(r|~t))+i[13]+1309151649&4294967295,n=r+(o<<21&4294967295|o>>>11),o=t+(r^(n|~s))+i[4]+4149444226&4294967295,t=n+(o<<6&4294967295|o>>>26),o=s+(n^(t|~r))+i[11]+3174756917&4294967295,s=t+(o<<10&4294967295|o>>>22),o=r+(t^(s|~n))+i[2]+718787259&4294967295,r=s+(o<<15&4294967295|o>>>17),o=n+(s^(r|~t))+i[9]+3951481745&4294967295,e.g[0]=e.g[0]+t&4294967295,e.g[1]=e.g[1]+(r+(o<<21&4294967295|o>>>11))&4294967295,e.g[2]=e.g[2]+r&4294967295,e.g[3]=e.g[3]+s&4294967295}function nA(e,t){this.h=t;for(var n=[],i=!0,r=e.length-1;0<=r;r--){var s=0|e[r];i&&s==t||(n[r]=s,i=!1)}this.g=n}(u=tZ.prototype).Oa=function(e){this.M=e},u.ha=function(e,t,n,i){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.I+"; newUri="+e);t=t?t.toUpperCase():"GET",this.I=e,this.j="",this.m=0,this.F=!1,this.h=!0,this.g=this.u?this.u.g():a.g(),this.C=this.u?eJ(this.u):eJ(a),this.g.onreadystatechange=T(this.La,this);try{this.G=!0,this.g.open(t,String(e),!0),this.G=!1}catch(r){t4(this,r);return}if(e=n||"",n=new Map(this.headers),i){if(Object.getPrototypeOf(i)===Object.prototype)for(var s in i)n.set(s,i[s]);else if("function"==typeof i.keys&&"function"==typeof i.get)for(let o of i.keys())n.set(o,i.get(o));else throw Error("Unknown input type for opt_headers: "+String(i))}for(let[l,h]of(i=Array.from(n.keys()).find(e=>"content-type"==e.toLowerCase()),s=_.FormData&&e instanceof _.FormData,!(0<=S(t2,t))||i||s||n.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8"),n))this.g.setRequestHeader(l,h);this.K&&(this.g.responseType=this.K),"withCredentials"in this.g&&this.g.withCredentials!==this.M&&(this.g.withCredentials=this.M);try{var u;t3(this),0<this.B&&((this.L=(u=this.g,M&&"number"==typeof u.timeout&&void 0!==u.ontimeout))?(this.g.timeout=this.B,this.g.ontimeout=T(this.ua,this)):this.A=eP(this.ua,this.B,this)),this.v=!0,this.g.send(e),this.v=!1}catch(c){t4(this,c)}},u.ua=function(){void 0!==m&&this.g&&(this.j="Timed out after "+this.B+"ms, aborting",this.m=8,e_(this,"timeout"),this.abort(8))},u.abort=function(e){this.g&&this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1,this.m=e||7,e_(this,"complete"),e_(this,"abort"),t5(this))},u.N=function(){this.g&&(this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1),t5(this,!0)),tZ.$.N.call(this)},u.La=function(){this.s||(this.G||this.v||this.l?t6(this):this.kb())},u.kb=function(){t6(this)},u.isActive=function(){return!!this.g},u.da=function(){try{return 2<t7(this)?this.g.status:-1}catch(e){return -1}},u.ja=function(){try{return this.g?this.g.responseText:""}catch(e){return""}},u.Wa=function(e){if(this.g){var t=this.g.responseText;return e&&0==t.indexOf(e)&&(t=t.substring(e.length)),tJ(t)}},u.Ia=function(){return this.m},u.Sa=function(){return"string"==typeof this.j?this.j:String(this.j)},(u=ni.prototype).ra=8,u.H=1,u.Na=function(e){if(this.m){if(this.m=null,1==this.H){if(!e){this.W=Math.floor(1e5*Math.random()),e=this.W++;let t=new e9(this,this.l,e),n=this.s;if(this.U&&(n?en(n=ee(n),this.U):n=this.U),null!==this.o||this.O||(t.I=n,n=null),this.P)a:{for(var i=0,r=0;r<this.j.length;r++){b:{var s=this.j[r];if("__data__"in s.map&&"string"==typeof(s=s.map.__data__)){s=s.length;break b}s=void 0}if(void 0===s)break;if(4096<(i+=s)){i=r;break a}if(4096===i||r===this.j.length-1){i=r+1;break a}}i=1e3}else i=1e3;i=nu(this,t,i),r=tf(this.I),t_(r,"RID",e),t_(r,"CVER",22),this.F&&t_(r,"X-HTTP-Session-Id",this.F),nh(this,r),n&&(this.O?i="headers="+encodeURIComponent(String(ne(n)))+"&"+i:this.o&&nt(r,this.o,n)),tV(this.i,t),this.bb&&t_(r,"TYPE","init"),this.P?(t_(r,"$req",i),t_(r,"SID","null"),t.aa=!0,e8(t,r,null)):e8(t,r,i),this.H=2}}else 3==this.H&&(e?nl(this,e):0==this.j.length||tM(this.i)||nl(this))}},u.Ma=function(){if(this.u=null,np(this),this.ca&&!(this.M||null==this.g||0>=this.S)){var e=2*this.S;this.l.info("BP detection timer enabled: "+e),this.B=eG(T(this.jb,this),e)}},u.jb=function(){this.B&&(this.B=null,this.l.info("BP detection timeout reached."),this.l.info("Buffering proxy detected and switch to long-polling!"),this.G=!1,this.M=!0,eH(10),ns(this),np(this))},u.ib=function(){null!=this.v&&(this.v=null,ns(this),nd(this),eH(19))},u.pb=function(e){e?(this.l.info("Successfully pinged google.com"),eH(2)):(this.l.info("Failed to ping google.com"),eH(1))},u.isActive=function(){return!!this.h&&this.h.isActive(this)},(u=nT.prototype).Ba=function(){},u.Aa=function(){},u.za=function(){},u.ya=function(){},u.isActive=function(){return!0},u.Va=function(){},nI.prototype.g=function(e,t){return new nE(e,t)},E(nE,em),nE.prototype.m=function(){this.g.h=this.j,this.A&&(this.g.J=!0);var e=this.g,t=this.l,n=this.h||void 0;eH(0),e.Y=t,e.na=n||{},e.G=e.aa,e.I=nw(e,null,e.Y),na(e)},nE.prototype.close=function(){nr(this.g)},nE.prototype.u=function(e){var t=this.g;if("string"==typeof e){var n={};n.__data__=e,e=n}else this.v&&((n={}).__data__=ev(e),e=n);t.j.push(new tO(t.fb++,e)),3==t.H&&na(t)},nE.prototype.N=function(){this.g.h=null,delete this.j,nr(this.g),delete this.g,nE.$.N.call(this)},E(nC,e1),E(nS,e2),E(nk,nT),nk.prototype.Ba=function(){e_(this.g,"a")},nk.prototype.Aa=function(e){e_(this.g,new nC(e))},nk.prototype.za=function(e){e_(this.g,new nS)},nk.prototype.ya=function(){e_(this.g,"b")},E(nN,function(){this.blockSize=-1}),nN.prototype.reset=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.i=this.h=0},nN.prototype.j=function(e,t){void 0===t&&(t=e.length);for(var n=t-this.blockSize,i=this.m,r=this.h,s=0;s<t;){if(0==r)for(;s<=n;)nR(this,e,s),s+=this.blockSize;if("string"==typeof e){for(;s<t;)if(i[r++]=e.charCodeAt(s++),r==this.blockSize){nR(this,i),r=0;break}}else for(;s<t;)if(i[r++]=e[s++],r==this.blockSize){nR(this,i),r=0;break}}this.h=r,this.i+=t},nN.prototype.l=function(){var e=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);e[0]=128;for(var t=1;t<e.length-8;++t)e[t]=0;var n=8*this.i;for(t=e.length-8;t<e.length;++t)e[t]=255&n,n/=256;for(this.j(e),e=Array(16),t=n=0;4>t;++t)for(var i=0;32>i;i+=8)e[n++]=this.g[t]>>>i&255;return e};var nD={};function nP(e){var t,n,i;return -128<=e&&128>e?(n=function(e){return new nA([0|e],0>e?-1:0)},i=nD,Object.prototype.hasOwnProperty.call(i,e)?i[e]:i[e]=n(e)):new nA([0|e],0>e?-1:0)}function nO(e){if(isNaN(e)||!isFinite(e))return nL;if(0>e)return nj(nO(-e));for(var t=[],n=1,i=0;e>=n;i++)t[i]=e/n|0,n*=nx;return new nA(t,0)}var nx=4294967296,nL=nP(0),nM=nP(1),nF=nP(16777216);function nU(e){if(0!=e.h)return!1;for(var t=0;t<e.g.length;t++)if(0!=e.g[t])return!1;return!0}function nV(e){return -1==e.h}function nj(e){for(var t=e.g.length,n=[],i=0;i<t;i++)n[i]=~e.g[i];return new nA(n,~e.h).add(nM)}function nq(e,t){return e.add(nj(t))}function nB(e,t){for(;(65535&e[t])!=e[t];)e[t+1]+=e[t]>>>16,e[t]&=65535,t++}function nz(e,t){this.g=e,this.h=t}function n$(e,t){if(nU(t))throw Error("division by zero");if(nU(e))return new nz(nL,nL);if(nV(e))return t=n$(nj(e),t),new nz(nj(t.g),nj(t.h));if(nV(t))return t=n$(e,nj(t)),new nz(nj(t.g),t.h);if(30<e.g.length){if(nV(e)||nV(t))throw Error("slowDivide_ only works with positive integers.");for(var n=nM,i=t;0>=i.X(e);)n=nW(n),i=nW(i);var r=nH(n,1),s=nH(i,1);for(i=nH(i,2),n=nH(n,2);!nU(i);){var o=s.add(i);0>=o.X(e)&&(r=r.add(n),s=o),i=nH(i,1),n=nH(n,1)}return t=nq(e,r.R(t)),new nz(r,t)}for(r=nL;0<=e.X(t);){for(i=48>=(i=Math.ceil(Math.log(n=Math.max(1,Math.floor(e.ea()/t.ea())))/Math.LN2))?1:Math.pow(2,i-48),o=(s=nO(n)).R(t);nV(o)||0<o.X(e);)n-=i,o=(s=nO(n)).R(t);nU(s)&&(s=nM),r=r.add(s),e=nq(e,o)}return new nz(r,e)}function nW(e){for(var t=e.g.length+1,n=[],i=0;i<t;i++)n[i]=e.D(i)<<1|e.D(i-1)>>>31;return new nA(n,e.h)}function nH(e,t){var n=t>>5;t%=32;for(var i=e.g.length-n,r=[],s=0;s<i;s++)r[s]=0<t?e.D(s+n)>>>t|e.D(s+n+1)<<32-t:e.D(s+n);return new nA(r,e.h)}(u=nA.prototype).ea=function(){if(nV(this))return-nj(this).ea();for(var e=0,t=1,n=0;n<this.g.length;n++){var i=this.D(n);e+=(0<=i?i:nx+i)*t,t*=nx}return e},u.toString=function(e){if(2>(e=e||10)||36<e)throw Error("radix out of range: "+e);if(nU(this))return"0";if(nV(this))return"-"+nj(this).toString(e);for(var t=nO(Math.pow(e,6)),n=this,i="";;){var r=n$(n,t).g,s=((0<(n=nq(n,r.R(t))).g.length?n.g[0]:n.h)>>>0).toString(e);if(n=r,nU(n))return s+i;for(;6>s.length;)s="0"+s;i=s+i}},u.D=function(e){return 0>e?0:e<this.g.length?this.g[e]:this.h},u.X=function(e){return nV(e=nq(this,e))?-1:nU(e)?0:1},u.abs=function(){return nV(this)?nj(this):this},u.add=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],i=0,r=0;r<=t;r++){var s=i+(65535&this.D(r))+(65535&e.D(r)),o=(s>>>16)+(this.D(r)>>>16)+(e.D(r)>>>16);i=o>>>16,s&=65535,o&=65535,n[r]=o<<16|s}return new nA(n,-2147483648&n[n.length-1]?-1:0)},u.R=function(e){if(nU(this)||nU(e))return nL;if(nV(this))return nV(e)?nj(this).R(nj(e)):nj(nj(this).R(e));if(nV(e))return nj(this.R(nj(e)));if(0>this.X(nF)&&0>e.X(nF))return nO(this.ea()*e.ea());for(var t=this.g.length+e.g.length,n=[],i=0;i<2*t;i++)n[i]=0;for(i=0;i<this.g.length;i++)for(var r=0;r<e.g.length;r++){var s=this.D(i)>>>16,o=65535&this.D(i),a=e.D(r)>>>16,l=65535&e.D(r);n[2*i+2*r]+=o*l,nB(n,2*i+2*r),n[2*i+2*r+1]+=s*l,nB(n,2*i+2*r+1),n[2*i+2*r+1]+=o*a,nB(n,2*i+2*r+1),n[2*i+2*r+2]+=s*a,nB(n,2*i+2*r+2)}for(i=0;i<t;i++)n[i]=n[2*i+1]<<16|n[2*i];for(i=t;i<2*t;i++)n[i]=0;return new nA(n,0)},u.gb=function(e){return n$(this,e).h},u.and=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],i=0;i<t;i++)n[i]=this.D(i)&e.D(i);return new nA(n,this.h&e.h)},u.or=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],i=0;i<t;i++)n[i]=this.D(i)|e.D(i);return new nA(n,this.h|e.h)},u.xor=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],i=0;i<t;i++)n[i]=this.D(i)^e.D(i);return new nA(n,this.h^e.h)},nI.prototype.createWebChannel=nI.prototype.g,nE.prototype.send=nE.prototype.u,nE.prototype.open=nE.prototype.m,nE.prototype.close=nE.prototype.close,eQ.NO_ERROR=0,eQ.TIMEOUT=8,eQ.HTTP_ERROR=6,eY.COMPLETE="complete",eZ.EventType=e0,e0.OPEN="a",e0.CLOSE="b",e0.ERROR="c",e0.MESSAGE="d",em.prototype.listen=em.prototype.O,tZ.prototype.listenOnce=tZ.prototype.P,tZ.prototype.getLastError=tZ.prototype.Sa,tZ.prototype.getLastErrorCode=tZ.prototype.Ia,tZ.prototype.getStatus=tZ.prototype.da,tZ.prototype.getResponseJson=tZ.prototype.Wa,tZ.prototype.getResponseText=tZ.prototype.ja,tZ.prototype.send=tZ.prototype.ha,tZ.prototype.setWithCredentials=tZ.prototype.Oa,nN.prototype.digest=nN.prototype.l,nN.prototype.reset=nN.prototype.reset,nN.prototype.update=nN.prototype.j,nA.prototype.add=nA.prototype.add,nA.prototype.multiply=nA.prototype.R,nA.prototype.modulo=nA.prototype.gb,nA.prototype.compare=nA.prototype.X,nA.prototype.toNumber=nA.prototype.ea,nA.prototype.toString=nA.prototype.toString,nA.prototype.getBits=nA.prototype.D,nA.fromNumber=nO,nA.fromString=function e(t,n){if(0==t.length)throw Error("number format error: empty string");if(2>(n=n||10)||36<n)throw Error("radix out of range: "+n);if("-"==t.charAt(0))return nj(e(t.substring(1),n));if(0<=t.indexOf("-"))throw Error('number format error: interior "-" character');for(var i=nO(Math.pow(n,8)),r=nL,s=0;s<t.length;s+=8){var o=Math.min(8,t.length-s),a=parseInt(t.substring(s,s+o),n);8>o?(o=nO(Math.pow(n,o)),r=r.R(o).add(nO(a))):r=(r=r.R(i)).add(nO(a))}return r};var nK=g.createWebChannelTransport=function(){return new nI},nG=g.getStatEventTarget=function(){return eB()},nQ=g.ErrorCode=eQ,nY=g.EventType=eY,nX=g.Event=ej,nJ=g.Stat={xb:0,Ab:1,Bb:2,Ub:3,Zb:4,Wb:5,Xb:6,Vb:7,Tb:8,Yb:9,PROXY:10,NOPROXY:11,Rb:12,Nb:13,Ob:14,Mb:15,Pb:16,Qb:17,tb:18,sb:19,ub:20};g.FetchXmlHttpFactory=tH;var nZ=g.WebChannel=eZ,n0=g.XhrIo=tZ,n1=g.Md5=nN,n2=g.Integer=nA;n(3454);let n4="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class n9{constructor(e){this.uid=e}isAuthenticated(){return null!=this.uid}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}n9.UNAUTHENTICATED=new n9(null),n9.GOOGLE_CREDENTIALS=new n9("google-credentials-uid"),n9.FIRST_PARTY=new n9("first-party-uid"),n9.MOCK_USER=new n9("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let n6="10.5.0",n5=new f.Yd("@firebase/firestore");function n3(){return n5.logLevel}function n7(e,...t){if(n5.logLevel<=f.in.DEBUG){let n=t.map(it);n5.debug(`Firestore (${n6}): ${e}`,...n)}}function n8(e,...t){if(n5.logLevel<=f.in.ERROR){let n=t.map(it);n5.error(`Firestore (${n6}): ${e}`,...n)}}function ie(e,...t){if(n5.logLevel<=f.in.WARN){let n=t.map(it);n5.warn(`Firestore (${n6}): ${e}`,...n)}}function it(e){if("string"==typeof e)return e;try{var t;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ return JSON.stringify(e)}catch(n){return e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function ii(e="Unexpected state"){let t=`FIRESTORE (${n6}) INTERNAL ASSERTION FAILED: `+e;throw n8(t),Error(t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ir={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class is extends p.ZR{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class io{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ia{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class il{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(n9.UNAUTHENTICATED))}shutdown(){}}class ih{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class iu{constructor(e){this.t=e,this.currentUser=n9.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let n=this.i,i=e=>this.i!==n?(n=this.i,t(e)):Promise.resolve(),r=new io;this.o=()=>{this.i++,this.currentUser=this.u(),r.resolve(),r=new io,e.enqueueRetryable(()=>i(this.currentUser))};let s=()=>{let t=r;e.enqueueRetryable(async()=>{await t.promise,await i(this.currentUser)})},o=e=>{n7("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=e,this.auth.addAuthTokenListener(this.o),s()};this.t.onInit(e=>o(e)),setTimeout(()=>{if(!this.auth){let e=this.t.getImmediate({optional:!0});e?o(e):(n7("FirebaseAuthCredentialsProvider","Auth not yet detected"),r.resolve(),r=new io)}},0),s()}getToken(){let e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(t=>{var n;return this.i!==e?(n7("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):t?("string"==typeof t.accessToken||ii(),new ia(t.accessToken,this.currentUser)):null}):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){let e=this.auth&&this.auth.getUid();return null===e||"string"==typeof e||ii(),new n9(e)}}class ic{constructor(e,t,n){this.l=e,this.h=t,this.P=n,this.type="FirstParty",this.user=n9.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);let e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class id{constructor(e,t,n){this.l=e,this.h=t,this.P=n}getToken(){return Promise.resolve(new ic(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(n9.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class ip{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class ig{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,t){let n=e=>{null!=e.error&&n7("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${e.error.message}`);let n=e.token!==this.R;return this.R=e.token,n7("FirebaseAppCheckTokenProvider",`Received ${n?"new":"existing"} token.`),n?t(e.token):Promise.resolve()};this.o=t=>{e.enqueueRetryable(()=>n(t))};let i=e=>{n7("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=e,this.appCheck.addTokenListener(this.o)};this.A.onInit(e=>i(e)),setTimeout(()=>{if(!this.appCheck){let e=this.A.getImmediate({optional:!0});e?i(e):n7("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){let e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(e=>{var t;return e?("string"==typeof e.token||ii(),this.R=e.token,new ip(e.token)):null}):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function im(e){let t="undefined"!=typeof self&&(self.crypto||self.msCrypto),n=new Uint8Array(e);if(t&&"function"==typeof t.getRandomValues)t.getRandomValues(n);else for(let i=0;i<e;i++)n[i]=Math.floor(256*Math.random());return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class i_{static V(){let e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length,n="";for(;n.length<20;){let i=im(40);for(let r=0;r<i.length;++r)n.length<20&&i[r]<t&&(n+=e.charAt(i[r]%e.length))}return n}}function iy(e,t){return e<t?-1:e>t?1:0}function iv(e,t,n){return e.length===t.length&&e.every((e,i)=>n(e,t[i]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iw{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0||t>=1e9)throw new is(ir.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800||e>=253402300800)throw new is(ir.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return iw.fromMillis(Date.now())}static fromDate(e){return iw.fromMillis(e.getTime())}static fromMillis(e){let t=Math.floor(e/1e3);return new iw(t,Math.floor(1e6*(e-1e3*t)))}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?iy(this.nanoseconds,e.nanoseconds):iy(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){let e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ib{constructor(e){this.timestamp=e}static fromTimestamp(e){return new ib(e)}static min(){return new ib(new iw(0,0))}static max(){return new ib(new iw(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iT{constructor(e,t,n){void 0===t?t=0:t>e.length&&ii(),void 0===n?n=e.length-t:n>e.length-t&&ii(),this.segments=e,this.offset=t,this.len=n}get length(){return this.len}isEqual(e){return 0===iT.comparator(this,e)}child(e){let t=this.segments.slice(this.offset,this.limit());return e instanceof iT?e.forEach(e=>{t.push(e)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=void 0===e?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return 0===this.length}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,n=this.limit();t<n;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){let n=Math.min(e.length,t.length);for(let i=0;i<n;i++){let r=e.get(i),s=t.get(i);if(r<s)return -1;if(r>s)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class iI extends iT{construct(e,t,n){return new iI(e,t,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}static fromString(...e){let t=[];for(let n of e){if(n.indexOf("//")>=0)throw new is(ir.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);t.push(...n.split("/").filter(e=>e.length>0))}return new iI(t)}static emptyPath(){return new iI([])}}let iE=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class iC extends iT{construct(e,t,n){return new iC(e,t,n)}static isValidIdentifier(e){return iE.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),iC.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return 1===this.length&&"__name__"===this.get(0)}static keyField(){return new iC(["__name__"])}static fromServerFormat(e){let t=[],n="",i=0,r=()=>{if(0===n.length)throw new is(ir.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(n),n=""},s=!1;for(;i<e.length;){let o=e[i];if("\\"===o){if(i+1===e.length)throw new is(ir.INVALID_ARGUMENT,"Path has trailing escape character: "+e);let a=e[i+1];if("\\"!==a&&"."!==a&&"`"!==a)throw new is(ir.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);n+=a,i+=2}else"`"===o?(s=!s,i++):"."!==o||s?(n+=o,i++):(r(),i++)}if(r(),s)throw new is(ir.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new iC(t)}static emptyPath(){return new iC([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iS{constructor(e){this.path=e}static fromPath(e){return new iS(iI.fromString(e))}static fromName(e){return new iS(iI.fromString(e).popFirst(5))}static empty(){return new iS(iI.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return null!==e&&0===iI.comparator(this.path,e.path)}toString(){return this.path.toString()}static comparator(e,t){return iI.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new iS(new iI(e.slice()))}}function ik(e){return new iN(e.readTime,e.key,-1)}class iN{constructor(e,t,n){this.readTime=e,this.documentKey=t,this.largestBatchId=n}static min(){return new iN(ib.min(),iS.empty(),-1)}static max(){return new iN(ib.max(),iS.empty(),-1)}}function iR(e,t){let n=e.readTime.compareTo(t.readTime);return 0!==n?n:0!==(n=iS.comparator(e.documentKey,t.documentKey))?n:iy(e.largestBatchId,t.largestBatchId)}class iA{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ async function iD(e){if(e.code!==ir.FAILED_PRECONDITION||"The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab."!==e.message)throw e;n7("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iP{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(e=>{this.isDone=!0,this.result=e,this.nextCallback&&this.nextCallback(e)},e=>{this.isDone=!0,this.error=e,this.catchCallback&&this.catchCallback(e)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&ii(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new iP((n,i)=>{this.nextCallback=t=>{this.wrapSuccess(e,t).next(n,i)},this.catchCallback=e=>{this.wrapFailure(t,e).next(n,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{let t=e();return t instanceof iP?t:iP.resolve(t)}catch(n){return iP.reject(n)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):iP.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):iP.reject(t)}static resolve(e){return new iP((t,n)=>{t(e)})}static reject(e){return new iP((t,n)=>{n(e)})}static waitFor(e){return new iP((t,n)=>{let i=0,r=0,s=!1;e.forEach(e=>{++i,e.next(()=>{++r,s&&r===i&&t()},e=>n(e))}),s=!0,r===i&&t()})}static or(e){let t=iP.resolve(!1);for(let n of e)t=t.next(e=>e?iP.resolve(e):n());return t}static forEach(e,t){let n=[];return e.forEach((e,i)=>{n.push(t.call(this,e,i))}),this.waitFor(n)}static mapArray(e,t){return new iP((n,i)=>{let r=e.length,s=Array(r),o=0;for(let a=0;a<r;a++){let l=a;t(e[l]).next(e=>{s[l]=e,++o===r&&n(s)},e=>i(e))}})}static doWhile(e,t){return new iP((n,i)=>{let r=()=>{!0===e()?t().next(()=>{r()},i):n()};r()})}}function iO(e){return"IndexedDbTransactionError"===e.name}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ix{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=e=>this.oe(e),this._e=e=>t.writeSequenceNumber(e))}oe(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){let e=++this.previousValue;return this._e&&this._e(e),e}}function iL(e){return null==e}function iM(e){return 0===e&&1/e==-1/0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function iF(e){let t=0;for(let n in e)Object.prototype.hasOwnProperty.call(e,n)&&t++;return t}function iU(e,t){for(let n in e)Object.prototype.hasOwnProperty.call(e,n)&&t(n,e[n])}function iV(e){for(let t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1;return!0}ix.ae=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ij{constructor(e,t){this.comparator=e,this.root=t||iB.EMPTY}insert(e,t){return new ij(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,iB.BLACK,null,null))}remove(e){return new ij(this.comparator,this.root.remove(e,this.comparator).copy(null,null,iB.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){let n=this.comparator(e,t.key);if(0===n)return t.value;n<0?t=t.left:n>0&&(t=t.right)}return null}indexOf(e){let t=0,n=this.root;for(;!n.isEmpty();){let i=this.comparator(e,n.key);if(0===i)return t+n.left.size;i<0?n=n.left:(t+=n.left.size+1,n=n.right)}return -1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,n)=>(e(t,n),!1))}toString(){let e=[];return this.inorderTraversal((t,n)=>(e.push(`${t}:${n}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new iq(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new iq(this.root,e,this.comparator,!1)}getReverseIterator(){return new iq(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new iq(this.root,e,this.comparator,!0)}}class iq{constructor(e,t,n,i){this.isReverse=i,this.nodeStack=[];let r=1;for(;!e.isEmpty();)if(r=t?n(e.key,t):1,t&&i&&(r*=-1),r<0)e=this.isReverse?e.left:e.right;else{if(0===r){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop(),t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(0===this.nodeStack.length)return null;let e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class iB{constructor(e,t,n,i,r){this.key=e,this.value=t,this.color=null!=n?n:iB.RED,this.left=null!=i?i:iB.EMPTY,this.right=null!=r?r:iB.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,n,i,r){return new iB(null!=e?e:this.key,null!=t?t:this.value,null!=n?n:this.color,null!=i?i:this.left,null!=r?r:this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let i=this,r=n(e,i.key);return(i=r<0?i.copy(null,null,null,i.left.insert(e,t,n),null):0===r?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,n))).fixUp()}removeMin(){if(this.left.isEmpty())return iB.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),(e=e.copy(null,null,null,e.left.removeMin(),null)).fixUp()}remove(e,t){let n,i=this;if(0>t(e,i.key))i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),0===t(e,i.key)){if(i.right.isEmpty())return iB.EMPTY;n=i.right.min(),i=i.copy(n.key,n.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=(e=(e=e.copy(null,null,null,null,e.right.rotateRight())).rotateLeft()).colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=(e=e.rotateRight()).colorFlip()),e}rotateLeft(){let e=this.copy(null,null,iB.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){let e=this.copy(null,null,iB.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){let e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){let e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw ii();let e=this.left.check();if(e!==this.right.check())throw ii();return e+(this.isRed()?0:1)}}iB.EMPTY=null,iB.RED=!0,iB.BLACK=!1,iB.EMPTY=new class{constructor(){this.size=0}get key(){throw ii()}get value(){throw ii()}get color(){throw ii()}get left(){throw ii()}get right(){throw ii()}copy(e,t,n,i,r){return this}insert(e,t,n){return new iB(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iz{constructor(e){this.comparator=e,this.data=new ij(this.comparator)}has(e){return null!==this.data.get(e)}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,n)=>(e(t),!1))}forEachInRange(e,t){let n=this.data.getIteratorFrom(e[0]);for(;n.hasNext();){let i=n.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let n;for(n=void 0!==t?this.data.getIteratorFrom(t):this.data.getIterator();n.hasNext();)if(!e(n.getNext().key))return}firstAfterOrEqual(e){let t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new i$(this.data.getIterator())}getIteratorFrom(e){return new i$(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(e=>{t=t.add(e)}),t}isEqual(e){if(!(e instanceof iz)||this.size!==e.size)return!1;let t=this.data.getIterator(),n=e.data.getIterator();for(;t.hasNext();){let i=t.getNext().key,r=n.getNext().key;if(0!==this.comparator(i,r))return!1}return!0}toArray(){let e=[];return this.forEach(t=>{e.push(t)}),e}toString(){let e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){let t=new iz(this.comparator);return t.data=e,t}}class i${constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iW{constructor(e){this.fields=e,e.sort(iC.comparator)}static empty(){return new iW([])}unionWith(e){let t=new iz(iC.comparator);for(let n of this.fields)t=t.add(n);for(let i of e)t=t.add(i);return new iW(t.toArray())}covers(e){for(let t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return iv(this.fields,e.fields,(e,t)=>e.isEqual(t))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iH extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class iK{constructor(e){this.binaryString=e}static fromBase64String(e){let t=function(e){try{return atob(e)}catch(t){throw"undefined"!=typeof DOMException&&t instanceof DOMException?new iH("Invalid base64 string: "+t):t}}(e);return new iK(t)}static fromUint8Array(e){let t=function(e){let t="";for(let n=0;n<e.length;++n)t+=String.fromCharCode(e[n]);return t}(e);return new iK(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){var e;return btoa(e=this.binaryString)}toUint8Array(){return function(e){let t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return t}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return iy(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}iK.EMPTY_BYTE_STRING=new iK("");let iG=RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function iQ(e){if(!e&&ii(),"string"==typeof e){let t=0,n=iG.exec(e);if(!n&&ii(),n[1]){let i=n[1];t=Number(i=(i+"000000000").substr(0,9))}let r=new Date(e);return{seconds:Math.floor(r.getTime()/1e3),nanos:t}}return{seconds:iY(e.seconds),nanos:iY(e.nanos)}}function iY(e){return"number"==typeof e?e:"string"==typeof e?Number(e):0}function iX(e){return"string"==typeof e?iK.fromBase64String(e):iK.fromUint8Array(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function iJ(e){var t,n;return"server_timestamp"===(null===(n=((null===(t=null==e?void 0:e.mapValue)||void 0===t?void 0:t.fields)||{}).__type__)||void 0===n?void 0:n.stringValue)}function iZ(e){let t=e.mapValue.fields.__previous_value__;return iJ(t)?iZ(t):t}function i0(e){let t=iQ(e.mapValue.fields.__local_write_time__.timestampValue);return new iw(t.seconds,t.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class i1{constructor(e,t,n,i,r,s,o,a,l){this.databaseId=e,this.appId=t,this.persistenceKey=n,this.host=i,this.ssl=r,this.forceLongPolling=s,this.autoDetectLongPolling=o,this.longPollingOptions=a,this.useFetchStreams=l}}class i2{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new i2("","")}get isDefaultDatabase(){return"(default)"===this.database}isEqual(e){return e instanceof i2&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let i4={mapValue:{fields:{__type__:{stringValue:"__max__"}}}};function i9(e){return"nullValue"in e?0:"booleanValue"in e?1:"integerValue"in e||"doubleValue"in e?2:"timestampValue"in e?3:"stringValue"in e?5:"bytesValue"in e?6:"referenceValue"in e?7:"geoPointValue"in e?8:"arrayValue"in e?9:"mapValue"in e?iJ(e)?4:ro(e)?9007199254740991:10:ii()}function i6(e,t){var n,i,r,s;if(e===t)return!0;let o=i9(e);if(o!==i9(t))return!1;switch(o){case 0:case 9007199254740991:return!0;case 1:return e.booleanValue===t.booleanValue;case 4:return i0(e).isEqual(i0(t));case 3:return function(e,t){if("string"==typeof e.timestampValue&&"string"==typeof t.timestampValue&&e.timestampValue.length===t.timestampValue.length)return e.timestampValue===t.timestampValue;let n=iQ(e.timestampValue),i=iQ(t.timestampValue);return n.seconds===i.seconds&&n.nanos===i.nanos}(e,t);case 5:return e.stringValue===t.stringValue;case 6:return iX(e.bytesValue).isEqual(iX(t.bytesValue));case 7:return e.referenceValue===t.referenceValue;case 8:return iY(e.geoPointValue.latitude)===iY(t.geoPointValue.latitude)&&iY(e.geoPointValue.longitude)===iY(t.geoPointValue.longitude);case 2:return function(e,t){if("integerValue"in e&&"integerValue"in t)return iY(e.integerValue)===iY(t.integerValue);if("doubleValue"in e&&"doubleValue"in t){let n=iY(e.doubleValue),i=iY(t.doubleValue);return n===i?iM(n)===iM(i):isNaN(n)&&isNaN(i)}return!1}(e,t);case 9:return iv(e.arrayValue.values||[],t.arrayValue.values||[],i6);case 10:return function(e,t){let n=e.mapValue.fields||{},i=t.mapValue.fields||{};if(iF(n)!==iF(i))return!1;for(let r in n)if(n.hasOwnProperty(r)&&(void 0===i[r]||!i6(n[r],i[r])))return!1;return!0}(e,t);default:return ii()}}function i5(e,t){return void 0!==(e.values||[]).find(e=>i6(e,t))}function i3(e,t){if(e===t)return 0;let n=i9(e),i=i9(t);if(n!==i)return iy(n,i);switch(n){case 0:case 9007199254740991:return 0;case 1:return iy(e.booleanValue,t.booleanValue);case 2:return function(e,t){let n=iY(e.integerValue||e.doubleValue),i=iY(t.integerValue||t.doubleValue);return n<i?-1:n>i?1:n===i?0:isNaN(n)?isNaN(i)?0:-1:1}(e,t);case 3:return i7(e.timestampValue,t.timestampValue);case 4:return i7(i0(e),i0(t));case 5:return iy(e.stringValue,t.stringValue);case 6:return function(e,t){let n=iX(e),i=iX(t);return n.compareTo(i)}(e.bytesValue,t.bytesValue);case 7:return function(e,t){let n=e.split("/"),i=t.split("/");for(let r=0;r<n.length&&r<i.length;r++){let s=iy(n[r],i[r]);if(0!==s)return s}return iy(n.length,i.length)}(e.referenceValue,t.referenceValue);case 8:return function(e,t){let n=iy(iY(e.latitude),iY(t.latitude));return 0!==n?n:iy(iY(e.longitude),iY(t.longitude))}(e.geoPointValue,t.geoPointValue);case 9:return function(e,t){let n=e.values||[],i=t.values||[];for(let r=0;r<n.length&&r<i.length;++r){let s=i3(n[r],i[r]);if(s)return s}return iy(n.length,i.length)}(e.arrayValue,t.arrayValue);case 10:return function(e,t){if(e===i4.mapValue&&t===i4.mapValue)return 0;if(e===i4.mapValue)return 1;if(t===i4.mapValue)return -1;let n=e.fields||{},i=Object.keys(n),r=t.fields||{},s=Object.keys(r);i.sort(),s.sort();for(let o=0;o<i.length&&o<s.length;++o){let a=iy(i[o],s[o]);if(0!==a)return a;let l=i3(n[i[o]],r[s[o]]);if(0!==l)return l}return iy(i.length,s.length)}(e.mapValue,t.mapValue);default:throw ii()}}function i7(e,t){if("string"==typeof e&&"string"==typeof t&&e.length===t.length)return iy(e,t);let n=iQ(e),i=iQ(t),r=iy(n.seconds,i.seconds);return 0!==r?r:iy(n.nanos,i.nanos)}function i8(e){var t,n,i;return"nullValue"in e?"null":"booleanValue"in e?""+e.booleanValue:"integerValue"in e?""+e.integerValue:"doubleValue"in e?""+e.doubleValue:"timestampValue"in e?function(e){let t=iQ(e);return`time(${t.seconds},${t.nanos})`}(e.timestampValue):"stringValue"in e?e.stringValue:"bytesValue"in e?iX(t=e.bytesValue).toBase64():"referenceValue"in e?(n=e.referenceValue,iS.fromName(n).toString()):"geoPointValue"in e?(i=e.geoPointValue,`geo(${i.latitude},${i.longitude})`):"arrayValue"in e?function(e){let t="[",n=!0;for(let i of e.values||[])n?n=!1:t+=",",t+=i8(i);return t+"]"}(e.arrayValue):"mapValue"in e?function(e){let t=Object.keys(e.fields||{}).sort(),n="{",i=!0;for(let r of t)i?i=!1:n+=",",n+=`${r}:${i8(e.fields[r])}`;return n+"}"}(e.mapValue):ii()}function re(e){return!!e&&"integerValue"in e}function rt(e){return!!e&&"arrayValue"in e}function rn(e){return!!e&&"nullValue"in e}function ri(e){return!!e&&"doubleValue"in e&&isNaN(Number(e.doubleValue))}function rr(e){return!!e&&"mapValue"in e}function rs(e){if(e.geoPointValue)return{geoPointValue:Object.assign({},e.geoPointValue)};if(e.timestampValue&&"object"==typeof e.timestampValue)return{timestampValue:Object.assign({},e.timestampValue)};if(e.mapValue){let t={mapValue:{fields:{}}};return iU(e.mapValue.fields,(e,n)=>t.mapValue.fields[e]=rs(n)),t}if(e.arrayValue){let n={arrayValue:{values:[]}};for(let i=0;i<(e.arrayValue.values||[]).length;++i)n.arrayValue.values[i]=rs(e.arrayValue.values[i]);return n}return Object.assign({},e)}function ro(e){return"__max__"===(((e.mapValue||{}).fields||{}).__type__||{}).stringValue}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ra{constructor(e){this.value=e}static empty(){return new ra({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let n=0;n<e.length-1;++n)if(!rr(t=(t.mapValue.fields||{})[e.get(n)]))return null;return(t=(t.mapValue.fields||{})[e.lastSegment()])||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=rs(t)}setAll(e){let t=iC.emptyPath(),n={},i=[];e.forEach((e,r)=>{if(!t.isImmediateParentOf(r)){let s=this.getFieldsMap(t);this.applyChanges(s,n,i),n={},i=[],t=r.popLast()}e?n[r.lastSegment()]=rs(e):i.push(r.lastSegment())});let r=this.getFieldsMap(t);this.applyChanges(r,n,i)}delete(e){let t=this.field(e.popLast());rr(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return i6(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let n=0;n<e.length;++n){let i=t.mapValue.fields[e.get(n)];rr(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(n)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,n){for(let i of(iU(t,(t,n)=>e[t]=n),n))delete e[i]}clone(){return new ra(rs(this.value))}}function rl(e){let t=[];return iU(e.fields,(e,n)=>{let i=new iC([e]);if(rr(n)){let r=rl(n.mapValue).fields;if(0===r.length)t.push(i);else for(let s of r)t.push(i.child(s))}else t.push(i)}),new iW(t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rh{constructor(e,t,n,i,r,s,o){this.key=e,this.documentType=t,this.version=n,this.readTime=i,this.createTime=r,this.data=s,this.documentState=o}static newInvalidDocument(e){return new rh(e,0,ib.min(),ib.min(),ib.min(),ra.empty(),0)}static newFoundDocument(e,t,n,i){return new rh(e,1,t,ib.min(),n,i,0)}static newNoDocument(e,t){return new rh(e,2,t,ib.min(),ib.min(),ra.empty(),0)}static newUnknownDocument(e,t){return new rh(e,3,t,ib.min(),ib.min(),ra.empty(),2)}convertToFoundDocument(e,t){return this.createTime.isEqual(ib.min())&&(2===this.documentType||0===this.documentType)&&(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=ra.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=ra.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ib.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return 1===this.documentState}get hasCommittedMutations(){return 2===this.documentState}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return 0!==this.documentType}isFoundDocument(){return 1===this.documentType}isNoDocument(){return 2===this.documentType}isUnknownDocument(){return 3===this.documentType}isEqual(e){return e instanceof rh&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new rh(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ru{constructor(e,t){this.position=e,this.inclusive=t}}function rc(e,t,n){let i=0;for(let r=0;r<e.position.length;r++){let s=t[r],o=e.position[r];if(i=s.field.isKeyField()?iS.comparator(iS.fromName(o.referenceValue),n.key):i3(o,n.data.field(s.field)),"desc"===s.dir&&(i*=-1),0!==i)break}return i}function rd(e,t){if(null===e)return null===t;if(null===t||e.inclusive!==t.inclusive||e.position.length!==t.position.length)return!1;for(let n=0;n<e.position.length;n++)if(!i6(e.position[n],t.position[n]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rf{constructor(e,t="asc"){this.field=e,this.dir=t}}function rp(e,t){return e.dir===t.dir&&e.field.isEqual(t.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rg{}class rm extends rg{constructor(e,t,n){super(),this.field=e,this.op=t,this.value=n}static create(e,t,n){return e.isKeyField()?"in"===t||"not-in"===t?this.createKeyFieldInFilter(e,t,n):new rb(e,t,n):"array-contains"===t?new rC(e,n):"in"===t?new rS(e,n):"not-in"===t?new rk(e,n):"array-contains-any"===t?new rN(e,n):new rm(e,t,n)}static createKeyFieldInFilter(e,t,n){return"in"===t?new rT(e,n):new rI(e,n)}matches(e){let t=e.data.field(this.field);return"!="===this.op?null!==t&&this.matchesComparison(i3(t,this.value)):null!==t&&i9(this.value)===i9(t)&&this.matchesComparison(i3(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return 0===e;case"!=":return 0!==e;case">":return e>0;case">=":return e>=0;default:return ii()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class r_ extends rg{constructor(e,t){super(),this.filters=e,this.op=t,this.ce=null}static create(e,t){return new r_(e,t)}matches(e){return ry(this)?void 0===this.filters.find(t=>!t.matches(e)):void 0!==this.filters.find(t=>t.matches(e))}getFlattenedFilters(){return null!==this.ce||(this.ce=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ce}getFilters(){return Object.assign([],this.filters)}}function ry(e){return"and"===e.op}function rv(e){return function(e){for(let t of e.filters)if(t instanceof r_)return!1;return!0}(e)&&ry(e)}function rw(e,t){var n,i,r,s;return e instanceof rm?t instanceof rm&&e.op===t.op&&e.field.isEqual(t.field)&&i6(e.value,t.value):e instanceof r_?t instanceof r_&&e.op===t.op&&e.filters.length===t.filters.length&&e.filters.reduce((e,n,i)=>e&&rw(n,t.filters[i]),!0):void ii()}class rb extends rm{constructor(e,t,n){super(e,t,n),this.key=iS.fromName(n.referenceValue)}matches(e){let t=iS.comparator(e.key,this.key);return this.matchesComparison(t)}}class rT extends rm{constructor(e,t){super(e,"in",t),this.keys=rE("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class rI extends rm{constructor(e,t){super(e,"not-in",t),this.keys=rE("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function rE(e,t){var n;return((null===(n=t.arrayValue)||void 0===n?void 0:n.values)||[]).map(e=>iS.fromName(e.referenceValue))}class rC extends rm{constructor(e,t){super(e,"array-contains",t)}matches(e){let t=e.data.field(this.field);return rt(t)&&i5(t.arrayValue,this.value)}}class rS extends rm{constructor(e,t){super(e,"in",t)}matches(e){let t=e.data.field(this.field);return null!==t&&i5(this.value.arrayValue,t)}}class rk extends rm{constructor(e,t){super(e,"not-in",t)}matches(e){if(i5(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;let t=e.data.field(this.field);return null!==t&&!i5(this.value.arrayValue,t)}}class rN extends rm{constructor(e,t){super(e,"array-contains-any",t)}matches(e){let t=e.data.field(this.field);return!(!rt(t)||!t.arrayValue.values)&&t.arrayValue.values.some(e=>i5(this.value.arrayValue,e))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rR{constructor(e,t=null,n=[],i=[],r=null,s=null,o=null){this.path=e,this.collectionGroup=t,this.orderBy=n,this.filters=i,this.limit=r,this.startAt=s,this.endAt=o,this.le=null}}function rA(e,t=null,n=[],i=[],r=null,s=null,o=null){return new rR(e,t,n,i,r,s,o)}function rD(e){var t;let n=e;if(null===n.le){let i=n.path.canonicalString();null!==n.collectionGroup&&(i+="|cg:"+n.collectionGroup),i+="|f:",i+=n.filters.map(e=>(function e(t){if(t instanceof rm){var n;return t.field.canonicalString()+t.op.toString()+i8(n=t.value)}if(rv(t))return t.filters.map(t=>e(t)).join(",");{let i=t.filters.map(t=>e(t)).join(",");return`${t.op}(${i})`}})(e)).join(","),i+="|ob:",i+=n.orderBy.map(e=>{var t;return e.field.canonicalString()+e.dir}).join(","),iL(n.limit)||(i+="|l:",i+=n.limit),n.startAt&&(i+="|lb:",i+=n.startAt.inclusive?"b:":"a:",i+=n.startAt.position.map(e=>{var t;return i8(e)}).join(",")),n.endAt&&(i+="|ub:",i+=n.endAt.inclusive?"a:":"b:",i+=n.endAt.position.map(e=>{var t;return i8(e)}).join(",")),n.le=i}return n.le}function rP(e,t){if(e.limit!==t.limit||e.orderBy.length!==t.orderBy.length)return!1;for(let n=0;n<e.orderBy.length;n++)if(!rp(e.orderBy[n],t.orderBy[n]))return!1;if(e.filters.length!==t.filters.length)return!1;for(let i=0;i<e.filters.length;i++)if(!rw(e.filters[i],t.filters[i]))return!1;return e.collectionGroup===t.collectionGroup&&!!e.path.isEqual(t.path)&&!!rd(e.startAt,t.startAt)&&rd(e.endAt,t.endAt)}function rO(e){return iS.isDocumentKey(e.path)&&null===e.collectionGroup&&0===e.filters.length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rx{constructor(e,t=null,n=[],i=[],r=null,s="F",o=null,a=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=n,this.filters=i,this.limit=r,this.limitType=s,this.startAt=o,this.endAt=a,this.he=null,this.Pe=null,this.Ie=null,this.startAt,this.endAt}}function rL(e){return new rx(e)}function rM(e){return 0===e.filters.length&&null===e.limit&&null==e.startAt&&null==e.endAt&&(0===e.explicitOrderBy.length||1===e.explicitOrderBy.length&&e.explicitOrderBy[0].field.isKeyField())}function rF(e){var t,n;let i=e;if(null===i.he){i.he=[];let r=new Set;for(let s of i.explicitOrderBy)i.he.push(s),r.add(s.field.canonicalString());let o,a=i.explicitOrderBy.length>0?i.explicitOrderBy[i.explicitOrderBy.length-1].dir:"asc",l=(n=i,o=new iz(iC.comparator),n.filters.forEach(e=>{e.getFlattenedFilters().forEach(e=>{e.isInequality()&&(o=o.add(e.field))})}),o);l.forEach(e=>{r.has(e.canonicalString())||e.isKeyField()||i.he.push(new rf(e,a))}),r.has(iC.keyField().canonicalString())||i.he.push(new rf(iC.keyField(),a))}return i.he}function rU(e){var t;let n=e;return n.Pe||(n.Pe=function(e,t){if("F"===e.limitType)return rA(e.path,e.collectionGroup,t,e.filters,e.limit,e.startAt,e.endAt);{t=t.map(e=>{let t="desc"===e.dir?"asc":"desc";return new rf(e.field,t)});let n=e.endAt?new ru(e.endAt.position,e.endAt.inclusive):null,i=e.startAt?new ru(e.startAt.position,e.startAt.inclusive):null;return rA(e.path,e.collectionGroup,t,e.filters,e.limit,n,i)}}(n,rF(e))),n.Pe}function rV(e,t,n){return new rx(e.path,e.collectionGroup,e.explicitOrderBy.slice(),e.filters.slice(),t,n,e.startAt,e.endAt)}function rj(e,t){return rP(rU(e),rU(t))&&e.limitType===t.limitType}function rq(e){return`${rD(rU(e))}|lt:${e.limitType}`}function rB(e){var t;let n;return`Query(target=${n=(t=rU(e)).path.canonicalString(),null!==t.collectionGroup&&(n+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(n+=`, filters: [${t.filters.map(e=>(function e(t){var n,i,r;return t instanceof rm?`${t.field.canonicalString()} ${t.op} ${i8(i=t.value)}`:t instanceof r_?t.op.toString()+" {"+t.getFilters().map(e).join(" ,")+"}":"Filter"})(e)).join(", ")}]`),iL(t.limit)||(n+=", limit: "+t.limit),t.orderBy.length>0&&(n+=`, orderBy: [${t.orderBy.map(e=>{var t;return`${e.field.canonicalString()} (${e.dir})`}).join(", ")}]`),t.startAt&&(n+=", startAt: ",n+=t.startAt.inclusive?"b:":"a:",n+=t.startAt.position.map(e=>{var t;return i8(e)}).join(",")),t.endAt&&(n+=", endAt: ",n+=t.endAt.inclusive?"a:":"b:",n+=t.endAt.position.map(e=>{var t;return i8(e)}).join(",")),`Target(${n})`}; limitType=${e.limitType})`}function rz(e,t){var n,i;return t.isFoundDocument()&&function(e,t){let n=t.key.path;return null!==e.collectionGroup?t.key.hasCollectionId(e.collectionGroup)&&e.path.isPrefixOf(n):iS.isDocumentKey(e.path)?e.path.isEqual(n):e.path.isImmediateParentOf(n)}(e,t)&&function(e,t){for(let n of rF(e))if(!n.field.isKeyField()&&null===t.data.field(n.field))return!1;return!0}(e,t)&&function(e,t){for(let n of e.filters)if(!n.matches(t))return!1;return!0}(e,t)&&(!e.startAt||!!function(e,t,n){let i=rc(e,t,n);return e.inclusive?i<=0:i<0}(e.startAt,rF(e),t))&&(!e.endAt||!!function(e,t,n){let i=rc(e,t,n);return e.inclusive?i>=0:i>0}(e.endAt,rF(e),t))}function r$(e){return(t,n)=>{let i=!1;for(let r of rF(e)){let s=rW(r,t,n);if(0!==s)return s;i=i||r.field.isKeyField()}return 0}}function rW(e,t,n){let i=e.field.isKeyField()?iS.comparator(t.key,n.key):function(e,t,n){let i=t.data.field(e),r=n.data.field(e);return null!==i&&null!==r?i3(i,r):ii()}(e.field,t,n);switch(e.dir){case"asc":return i;case"desc":return -1*i;default:return ii()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class rH{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){let t=this.mapKeyFn(e),n=this.inner[t];if(void 0!==n){for(let[i,r]of n)if(this.equalsFn(i,e))return r}}has(e){return void 0!==this.get(e)}set(e,t){let n=this.mapKeyFn(e),i=this.inner[n];if(void 0===i)return this.inner[n]=[[e,t]],void this.innerSize++;for(let r=0;r<i.length;r++)if(this.equalsFn(i[r][0],e))return void(i[r]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){let t=this.mapKeyFn(e),n=this.inner[t];if(void 0===n)return!1;for(let i=0;i<n.length;i++)if(this.equalsFn(n[i][0],e))return 1===n.length?delete this.inner[t]:n.splice(i,1),this.innerSize--,!0;return!1}forEach(e){iU(this.inner,(t,n)=>{for(let[i,r]of n)e(i,r)})}isEmpty(){return iV(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let rK=new ij(iS.comparator),rG=new ij(iS.comparator);function rQ(...e){let t=rG;for(let n of e)t=t.insert(n.key,n);return t}function rY(e){let t=rG;return e.forEach((e,n)=>t=t.insert(e,n.overlayedDocument)),t}function rX(){return rZ()}function rJ(){return rZ()}function rZ(){return new rH(e=>e.toString(),(e,t)=>e.isEqual(t))}let r0=new ij(iS.comparator),r1=new iz(iS.comparator);function r2(...e){let t=r1;for(let n of e)t=t.add(n);return t}let r4=new iz(iy);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function r9(e,t){if(e.useProto3Json){if(isNaN(t))return{doubleValue:"NaN"};if(t===1/0)return{doubleValue:"Infinity"};if(t===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:iM(t)?"-0":t}}function r6(e){return{integerValue:""+e}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class r5{constructor(){this._=void 0}}function r3(e,t,n){return e instanceof se?function(e,t){let n={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:e.seconds,nanos:e.nanoseconds}}}};return t&&iJ(t)&&(t=iZ(t)),t&&(n.fields.__previous_value__=t),{mapValue:n}}(n,t):e instanceof st?sn(e,t):e instanceof si?sr(e,t):function(e,t){let n=r8(e,t),i=so(n)+so(e.Te);return re(n)&&re(e.Te)?r6(i):r9(e.serializer,i)}(e,t)}function r7(e,t,n){return e instanceof st?sn(e,t):e instanceof si?sr(e,t):n}function r8(e,t){var n,i;return e instanceof ss?re(t)||t&&"doubleValue"in t?t:{integerValue:0}:null}class se extends r5{}class st extends r5{constructor(e){super(),this.elements=e}}function sn(e,t){let n=sa(t);for(let i of e.elements)n.some(e=>i6(e,i))||n.push(i);return{arrayValue:{values:n}}}class si extends r5{constructor(e){super(),this.elements=e}}function sr(e,t){let n=sa(t);for(let i of e.elements)n=n.filter(e=>!i6(e,i));return{arrayValue:{values:n}}}class ss extends r5{constructor(e,t){super(),this.serializer=e,this.Te=t}}function so(e){return iY(e.integerValue||e.doubleValue)}function sa(e){return rt(e)&&e.arrayValue.values?e.arrayValue.values.slice():[]}class sl{constructor(e,t){this.version=e,this.transformResults=t}}class sh{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new sh}static exists(e){return new sh(void 0,e)}static updateTime(e){return new sh(e)}get isNone(){return void 0===this.updateTime&&void 0===this.exists}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function su(e,t){return void 0!==e.updateTime?t.isFoundDocument()&&t.version.isEqual(e.updateTime):void 0===e.exists||e.exists===t.isFoundDocument()}class sc{}function sd(e,t){if(!e.hasLocalMutations||t&&0===t.fields.length)return null;if(null===t)return e.isNoDocument()?new sT(e.key,sh.none()):new s_(e.key,e.data,sh.none());{let n=e.data,i=ra.empty(),r=new iz(iC.comparator);for(let s of t.fields)if(!r.has(s)){let o=n.field(s);null===o&&s.length>1&&(s=s.popLast(),o=n.field(s)),null===o?i.delete(s):i.set(s,o),r=r.add(s)}return new sy(e.key,i,new iW(r.toArray()),sh.none())}}function sf(e,t,n){e instanceof s_?function(e,t,n){let i=e.value.clone(),r=sw(e.fieldTransforms,t,n.transformResults);i.setAll(r),t.convertToFoundDocument(n.version,i).setHasCommittedMutations()}(e,t,n):e instanceof sy?function(e,t,n){if(!su(e.precondition,t))return void t.convertToUnknownDocument(n.version);let i=sw(e.fieldTransforms,t,n.transformResults),r=t.data;r.setAll(sv(e)),r.setAll(i),t.convertToFoundDocument(n.version,r).setHasCommittedMutations()}(e,t,n):function(e,t,n){t.convertToNoDocument(n.version).setHasCommittedMutations()}(0,t,n)}function sp(e,t,n,i){var r,s,o;return e instanceof s_?function(e,t,n,i){if(!su(e.precondition,t))return n;let r=e.value.clone(),s=sb(e.fieldTransforms,i,t);return r.setAll(s),t.convertToFoundDocument(t.version,r).setHasLocalMutations(),null}(e,t,n,i):e instanceof sy?function(e,t,n,i){if(!su(e.precondition,t))return n;let r=sb(e.fieldTransforms,i,t),s=t.data;return(s.setAll(sv(e)),s.setAll(r),t.convertToFoundDocument(t.version,s).setHasLocalMutations(),null===n)?null:n.unionWith(e.fieldMask.fields).unionWith(e.fieldTransforms.map(e=>e.field))}(e,t,n,i):su(e.precondition,t)?(t.convertToNoDocument(t.version).setHasLocalMutations(),null):n}function sg(e,t){let n=null;for(let i of e.fieldTransforms){let r=t.data.field(i.field),s=r8(i.transform,r||null);null!=s&&(null===n&&(n=ra.empty()),n.set(i.field,s))}return n||null}function sm(e,t){var n,i;return e.type===t.type&&!!e.key.isEqual(t.key)&&!!e.precondition.isEqual(t.precondition)&&(n=e.fieldTransforms,i=t.fieldTransforms,!!(void 0===n&&void 0===i||!(!n||!i)&&iv(n,i,(e,t)=>{var n,i,r,s;return e.field.isEqual(t.field)&&(r=e.transform,s=t.transform,r instanceof st&&s instanceof st||r instanceof si&&s instanceof si?iv(r.elements,s.elements,i6):r instanceof ss&&s instanceof ss?i6(r.Te,s.Te):r instanceof se&&s instanceof se)})))&&(0===e.type?e.value.isEqual(t.value):1!==e.type||e.data.isEqual(t.data)&&e.fieldMask.isEqual(t.fieldMask))}class s_ extends sc{constructor(e,t,n,i=[]){super(),this.key=e,this.value=t,this.precondition=n,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class sy extends sc{constructor(e,t,n,i,r=[]){super(),this.key=e,this.data=t,this.fieldMask=n,this.precondition=i,this.fieldTransforms=r,this.type=1}getFieldMask(){return this.fieldMask}}function sv(e){let t=new Map;return e.fieldMask.fields.forEach(n=>{if(!n.isEmpty()){let i=e.data.field(n);t.set(n,i)}}),t}function sw(e,t,n){var i;let r=new Map;(i=e.length===n.length)||ii();for(let s=0;s<n.length;s++){let o=e[s],a=o.transform,l=t.data.field(o.field);r.set(o.field,r7(a,l,n[s]))}return r}function sb(e,t,n){let i=new Map;for(let r of e){let s=r.transform,o=n.data.field(r.field);i.set(r.field,r3(s,o,t))}return i}class sT extends sc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class sI extends sc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class sE{constructor(e,t,n,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=n,this.mutations=i}applyToRemoteDocument(e,t){let n=t.mutationResults;for(let i=0;i<this.mutations.length;i++){let r=this.mutations[i];r.key.isEqual(e.key)&&sf(r,e,n[i])}}applyToLocalView(e,t){for(let n of this.baseMutations)n.key.isEqual(e.key)&&(t=sp(n,e,t,this.localWriteTime));for(let i of this.mutations)i.key.isEqual(e.key)&&(t=sp(i,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){let n=rJ();return this.mutations.forEach(i=>{let r=e.get(i.key),s=r.overlayedDocument,o=this.applyToLocalView(s,r.mutatedFields);o=t.has(i.key)?null:o;let a=sd(s,o);null!==a&&n.set(i.key,a),s.isValidDocument()||s.convertToNoDocument(ib.min())}),n}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),r2())}isEqual(e){return this.batchId===e.batchId&&iv(this.mutations,e.mutations,(e,t)=>sm(e,t))&&iv(this.baseMutations,e.baseMutations,(e,t)=>sm(e,t))}}class sC{constructor(e,t,n,i){this.batch=e,this.commitVersion=t,this.mutationResults=n,this.docVersions=i}static from(e,t,n){var i;(i=e.mutations.length===n.length)||ii();let r=r0,s=e.mutations;for(let o=0;o<s.length;o++)r=r.insert(s[o].key,n[o].version);return new sC(e,t,n,r)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class sS{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return null!==e&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class sk{constructor(e,t){this.count=e,this.unchangedNames=t}}function sN(e){if(void 0===e)return n8("GRPC error has no .code"),ir.UNKNOWN;switch(e){case l.OK:return ir.OK;case l.CANCELLED:return ir.CANCELLED;case l.UNKNOWN:return ir.UNKNOWN;case l.DEADLINE_EXCEEDED:return ir.DEADLINE_EXCEEDED;case l.RESOURCE_EXHAUSTED:return ir.RESOURCE_EXHAUSTED;case l.INTERNAL:return ir.INTERNAL;case l.UNAVAILABLE:return ir.UNAVAILABLE;case l.UNAUTHENTICATED:return ir.UNAUTHENTICATED;case l.INVALID_ARGUMENT:return ir.INVALID_ARGUMENT;case l.NOT_FOUND:return ir.NOT_FOUND;case l.ALREADY_EXISTS:return ir.ALREADY_EXISTS;case l.PERMISSION_DENIED:return ir.PERMISSION_DENIED;case l.FAILED_PRECONDITION:return ir.FAILED_PRECONDITION;case l.ABORTED:return ir.ABORTED;case l.OUT_OF_RANGE:return ir.OUT_OF_RANGE;case l.UNIMPLEMENTED:return ir.UNIMPLEMENTED;case l.DATA_LOSS:return ir.DATA_LOSS;default:return ii()}}(h=l||(l={}))[h.OK=0]="OK",h[h.CANCELLED=1]="CANCELLED",h[h.UNKNOWN=2]="UNKNOWN",h[h.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",h[h.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",h[h.NOT_FOUND=5]="NOT_FOUND",h[h.ALREADY_EXISTS=6]="ALREADY_EXISTS",h[h.PERMISSION_DENIED=7]="PERMISSION_DENIED",h[h.UNAUTHENTICATED=16]="UNAUTHENTICATED",h[h.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",h[h.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",h[h.ABORTED=10]="ABORTED",h[h.OUT_OF_RANGE=11]="OUT_OF_RANGE",h[h.UNIMPLEMENTED=12]="UNIMPLEMENTED",h[h.INTERNAL=13]="INTERNAL",h[h.UNAVAILABLE=14]="UNAVAILABLE",h[h.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let sR=new n2([4294967295,4294967295],0);function sA(e){let t=(new TextEncoder).encode(e),n=new n1;return n.update(t),new Uint8Array(n.digest())}function sD(e){let t=new DataView(e.buffer),n=t.getUint32(0,!0),i=t.getUint32(4,!0),r=t.getUint32(8,!0),s=t.getUint32(12,!0);return[new n2([n,i],0),new n2([r,s],0)]}class sP{constructor(e,t,n){if(this.bitmap=e,this.padding=t,this.hashCount=n,t<0||t>=8)throw new sO(`Invalid padding: ${t}`);if(n<0||e.length>0&&0===this.hashCount)throw new sO(`Invalid hash count: ${n}`);if(0===e.length&&0!==t)throw new sO(`Invalid padding when bitmap length is 0: ${t}`);this.Ee=8*e.length-t,this.de=n2.fromNumber(this.Ee)}Ae(e,t,n){let i=e.add(t.multiply(n2.fromNumber(n)));return 1===i.compare(sR)&&(i=new n2([i.getBits(0),i.getBits(1)],0)),i.modulo(this.de).toNumber()}Re(e){return 0!=(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(0===this.Ee)return!1;let t=sA(e),[n,i]=sD(t);for(let r=0;r<this.hashCount;r++){let s=this.Ae(n,i,r);if(!this.Re(s))return!1}return!0}static create(e,t,n){let i=new Uint8Array(Math.ceil(e/8)),r=new sP(i,e%8==0?0:8-e%8,t);return n.forEach(e=>r.insert(e)),r}insert(e){if(0===this.Ee)return;let t=sA(e),[n,i]=sD(t);for(let r=0;r<this.hashCount;r++){let s=this.Ae(n,i,r);this.Ve(s)}}Ve(e){let t=Math.floor(e/8);this.bitmap[t]|=1<<e%8}}class sO extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class sx{constructor(e,t,n,i,r){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=n,this.documentUpdates=i,this.resolvedLimboDocuments=r}static createSynthesizedRemoteEventForCurrentChange(e,t,n){let i=new Map;return i.set(e,sL.createSynthesizedTargetChangeForCurrentChange(e,t,n)),new sx(ib.min(),i,new ij(iy),rK,r2())}}class sL{constructor(e,t,n,i,r){this.resumeToken=e,this.current=t,this.addedDocuments=n,this.modifiedDocuments=i,this.removedDocuments=r}static createSynthesizedTargetChangeForCurrentChange(e,t,n){return new sL(n,t,r2(),r2(),r2())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class sM{constructor(e,t,n,i){this.me=e,this.removedTargetIds=t,this.key=n,this.fe=i}}class sF{constructor(e,t){this.targetId=e,this.ge=t}}class sU{constructor(e,t,n=iK.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=n,this.cause=i}}class sV{constructor(){this.pe=0,this.ye=sB(),this.we=iK.EMPTY_BYTE_STRING,this.Se=!1,this.be=!0}get current(){return this.Se}get resumeToken(){return this.we}get De(){return 0!==this.pe}get Ce(){return this.be}ve(e){e.approximateByteSize()>0&&(this.be=!0,this.we=e)}Fe(){let e=r2(),t=r2(),n=r2();return this.ye.forEach((i,r)=>{switch(r){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:n=n.add(i);break;default:ii()}}),new sL(this.we,this.Se,e,t,n)}Me(){this.be=!1,this.ye=sB()}xe(e,t){this.be=!0,this.ye=this.ye.insert(e,t)}Oe(e){this.be=!0,this.ye=this.ye.remove(e)}Ne(){this.pe+=1}Be(){this.pe-=1}Le(){this.be=!0,this.Se=!0}}class sj{constructor(e){this.ke=e,this.qe=new Map,this.Qe=rK,this.Ke=sq(),this.$e=new ij(iy)}Ue(e){for(let t of e.me)e.fe&&e.fe.isFoundDocument()?this.We(t,e.fe):this.Ge(t,e.key,e.fe);for(let n of e.removedTargetIds)this.Ge(n,e.key,e.fe)}ze(e){this.forEachTarget(e,t=>{let n=this.je(t);switch(e.state){case 0:this.He(t)&&n.ve(e.resumeToken);break;case 1:n.Be(),n.De||n.Me(),n.ve(e.resumeToken);break;case 2:n.Be(),n.De||this.removeTarget(t);break;case 3:this.He(t)&&(n.Le(),n.ve(e.resumeToken));break;case 4:this.He(t)&&(this.Je(t),n.ve(e.resumeToken));break;default:ii()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.qe.forEach((e,n)=>{this.He(n)&&t(n)})}Ye(e){let t=e.targetId,n=e.ge.count,i=this.Ze(t);if(i){let r=i.target;if(rO(r)){if(0===n){let s=new iS(r.path);this.Ge(t,s,rh.newNoDocument(s,ib.min()))}else{var o;(o=1===n)||ii()}}else{let a=this.Xe(t);if(a!==n){let l=this.et(e),h=l?this.tt(l,e,a):1;0!==h&&(this.Je(t),this.$e=this.$e.insert(t,2===h?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch"))}}}}et(e){let t=e.ge.unchangedNames;if(!t||!t.bits)return null;let{bits:{bitmap:n="",padding:i=0},hashCount:r=0}=t,s,o;try{s=iX(n).toUint8Array()}catch(a){if(a instanceof iH)return ie("Decoding the base64 bloom filter in existence filter failed ("+a.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw a}try{o=new sP(s,i,r)}catch(l){return ie(l instanceof sO?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return 0===o.Ee?null:o}tt(e,t,n){return t.ge.count===n-this.it(e,t.targetId)?0:2}it(e,t){let n=this.ke.getRemoteKeysForTarget(t),i=0;return n.forEach(n=>{let r=this.ke.rt(),s=`projects/${r.projectId}/databases/${r.database}/documents/${n.path.canonicalString()}`;e.mightContain(s)||(this.Ge(t,n,null),i++)}),i}st(e){let t=new Map;this.qe.forEach((n,i)=>{let r=this.Ze(i);if(r){if(n.current&&rO(r.target)){let s=new iS(r.target.path);null!==this.Qe.get(s)||this.ot(i,s)||this.Ge(i,s,rh.newNoDocument(s,e))}n.Ce&&(t.set(i,n.Fe()),n.Me())}});let n=r2();this.Ke.forEach((e,t)=>{let i=!0;t.forEachWhile(e=>{let t=this.Ze(e);return!t||"TargetPurposeLimboResolution"===t.purpose||(i=!1,!1)}),i&&(n=n.add(e))}),this.Qe.forEach((t,n)=>n.setReadTime(e));let i=new sx(e,t,this.$e,this.Qe,n);return this.Qe=rK,this.Ke=sq(),this.$e=new ij(iy),i}We(e,t){if(!this.He(e))return;let n=this.ot(e,t.key)?2:0;this.je(e).xe(t.key,n),this.Qe=this.Qe.insert(t.key,t),this.Ke=this.Ke.insert(t.key,this._t(t.key).add(e))}Ge(e,t,n){if(!this.He(e))return;let i=this.je(e);this.ot(e,t)?i.xe(t,1):i.Oe(t),this.Ke=this.Ke.insert(t,this._t(t).delete(e)),n&&(this.Qe=this.Qe.insert(t,n))}removeTarget(e){this.qe.delete(e)}Xe(e){let t=this.je(e).Fe();return this.ke.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}Ne(e){this.je(e).Ne()}je(e){let t=this.qe.get(e);return t||(t=new sV,this.qe.set(e,t)),t}_t(e){let t=this.Ke.get(e);return t||(t=new iz(iy),this.Ke=this.Ke.insert(e,t)),t}He(e){let t=null!==this.Ze(e);return t||n7("WatchChangeAggregator","Detected inactive target",e),t}Ze(e){let t=this.qe.get(e);return t&&t.De?null:this.ke.ut(e)}Je(e){this.qe.set(e,new sV),this.ke.getRemoteKeysForTarget(e).forEach(t=>{this.Ge(e,t,null)})}ot(e,t){return this.ke.getRemoteKeysForTarget(e).has(t)}}function sq(){return new ij(iS.comparator)}function sB(){return new ij(iS.comparator)}let sz={asc:"ASCENDING",desc:"DESCENDING"},s$={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},sW={and:"AND",or:"OR"};class sH{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function sK(e,t){return e.useProto3Json||iL(t)?t:{value:t}}function sG(e,t){return e.useProto3Json?`${new Date(1e3*t.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+t.nanoseconds).slice(-9)}Z`:{seconds:""+t.seconds,nanos:t.nanoseconds}}function sQ(e,t){return e.useProto3Json?t.toBase64():t.toUint8Array()}function sY(e){return!e&&ii(),ib.fromTimestamp(function(e){let t=iQ(e);return new iw(t.seconds,t.nanos)}(e))}function sX(e,t){var n;return new iI(["projects",e.projectId,"databases",e.database]).child("documents").child(t).canonicalString()}function sJ(e){var t;let n=iI.fromString(e);return s3(n)||ii(),n}function sZ(e,t){return sX(e.databaseId,t.path)}function s0(e,t){let n=sJ(t);if(n.get(1)!==e.databaseId.projectId)throw new is(ir.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+n.get(1)+" vs "+e.databaseId.projectId);if(n.get(3)!==e.databaseId.database)throw new is(ir.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+n.get(3)+" vs "+e.databaseId.database);return new iS(s4(n))}function s1(e,t){return sX(e.databaseId,t)}function s2(e){return new iI(["projects",e.databaseId.projectId,"databases",e.databaseId.database]).canonicalString()}function s4(e){var t;return e.length>4&&"documents"===e.get(4)||ii(),e.popFirst(5)}function s9(e,t,n){return{name:sZ(e,t),fields:n.value.mapValue.fields}}function s6(e){return{fieldPath:e.canonicalString()}}function s5(e){return iC.fromServerFormat(e.fieldPath)}function s3(e){return e.length>=4&&"projects"===e.get(0)&&"databases"===e.get(2)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class s7{constructor(e,t,n,i,r=ib.min(),s=ib.min(),o=iK.EMPTY_BYTE_STRING,a=null){this.target=e,this.targetId=t,this.purpose=n,this.sequenceNumber=i,this.snapshotVersion=r,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=o,this.expectedCount=a}withSequenceNumber(e){return new s7(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new s7(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new s7(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new s7(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class s8{constructor(e){this.ct=e}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oe{constructor(){}Pt(e,t){this.It(e,t),t.Tt()}It(e,t){if("nullValue"in e)this.Et(t,5);else if("booleanValue"in e)this.Et(t,10),t.dt(e.booleanValue?1:0);else if("integerValue"in e)this.Et(t,15),t.dt(iY(e.integerValue));else if("doubleValue"in e){let n=iY(e.doubleValue);isNaN(n)?this.Et(t,13):(this.Et(t,15),iM(n)?t.dt(0):t.dt(n))}else if("timestampValue"in e){let i=e.timestampValue;this.Et(t,20),"string"==typeof i?t.At(i):(t.At(`${i.seconds||""}`),t.dt(i.nanos||0))}else if("stringValue"in e)this.Rt(e.stringValue,t),this.Vt(t);else if("bytesValue"in e)this.Et(t,30),t.ft(iX(e.bytesValue)),this.Vt(t);else if("referenceValue"in e)this.gt(e.referenceValue,t);else if("geoPointValue"in e){let r=e.geoPointValue;this.Et(t,45),t.dt(r.latitude||0),t.dt(r.longitude||0)}else"mapValue"in e?ro(e)?this.Et(t,Number.MAX_SAFE_INTEGER):(this.yt(e.mapValue,t),this.Vt(t)):"arrayValue"in e?(this.wt(e.arrayValue,t),this.Vt(t)):ii()}Rt(e,t){this.Et(t,25),this.St(e,t)}St(e,t){t.At(e)}yt(e,t){let n=e.fields||{};for(let i of(this.Et(t,55),Object.keys(n)))this.Rt(i,t),this.It(n[i],t)}wt(e,t){let n=e.values||[];for(let i of(this.Et(t,50),n))this.It(i,t)}gt(e,t){this.Et(t,37),iS.fromName(e).path.forEach(e=>{this.Et(t,60),this.St(e,t)})}Et(e,t){e.dt(t)}Vt(e){e.dt(2)}}oe.bt=new oe;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ot{constructor(){this._n=new on}addToCollectionParentIndex(e,t){return this._n.add(t),iP.resolve()}getCollectionParents(e,t){return iP.resolve(this._n.getEntries(t))}addFieldIndex(e,t){return iP.resolve()}deleteFieldIndex(e,t){return iP.resolve()}deleteAllFieldIndexes(e){return iP.resolve()}createTargetIndexes(e,t){return iP.resolve()}getDocumentsMatchingTarget(e,t){return iP.resolve(null)}getIndexType(e,t){return iP.resolve(0)}getFieldIndexes(e,t){return iP.resolve([])}getNextCollectionGroupToUpdate(e){return iP.resolve(null)}getMinOffset(e,t){return iP.resolve(iN.min())}getMinOffsetFromCollectionGroup(e,t){return iP.resolve(iN.min())}updateCollectionGroup(e,t,n){return iP.resolve()}updateIndexEntries(e,t){return iP.resolve()}}class on{constructor(){this.index={}}add(e){let t=e.lastSegment(),n=e.popLast(),i=this.index[t]||new iz(iI.comparator),r=!i.has(n);return this.index[t]=i.add(n),r}has(e){let t=e.lastSegment(),n=e.popLast(),i=this.index[t];return i&&i.has(n)}getEntries(e){return(this.index[e]||new iz(iI.comparator)).toArray()}}new Uint8Array(0);class oi{constructor(e,t,n){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=n}static withCacheSize(e){return new oi(e,oi.DEFAULT_COLLECTION_PERCENTILE,oi.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ oi.DEFAULT_COLLECTION_PERCENTILE=10,oi.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,oi.DEFAULT=new oi(41943040,oi.DEFAULT_COLLECTION_PERCENTILE,oi.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),oi.DISABLED=new oi(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class or{constructor(e){this.On=e}next(){return this.On+=2,this.On}static Nn(){return new or(0)}static Bn(){return new or(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class os{constructor(){this.changes=new rH(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,rh.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();let n=this.changes.get(t);return void 0!==n?iP.resolve(n):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ /**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oo{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oa{constructor(e,t,n,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=n,this.indexManager=i}getDocument(e,t){let n=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(n=i,this.remoteDocumentCache.getEntry(e,t))).next(e=>(null!==n&&sp(n.mutation,e,iW.empty(),iw.now()),e))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(t=>this.getLocalViewOfDocuments(e,t,r2()).next(()=>t))}getLocalViewOfDocuments(e,t,n=r2()){let i=rX();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,n).next(e=>{let t=rQ();return e.forEach((e,n)=>{t=t.insert(e,n.overlayedDocument)}),t}))}getOverlayedDocuments(e,t){let n=rX();return this.populateOverlays(e,n,t).next(()=>this.computeViews(e,t,n,r2()))}populateOverlays(e,t,n){let i=[];return n.forEach(e=>{t.has(e)||i.push(e)}),this.documentOverlayCache.getOverlays(e,i).next(e=>{e.forEach((e,n)=>{t.set(e,n)})})}computeViews(e,t,n,i){let r=rK,s=rZ(),o=rZ();return t.forEach((e,t)=>{let o=n.get(t.key);i.has(t.key)&&(void 0===o||o.mutation instanceof sy)?r=r.insert(t.key,t):void 0!==o?(s.set(t.key,o.mutation.getFieldMask()),sp(o.mutation,t,o.mutation.getFieldMask(),iw.now())):s.set(t.key,iW.empty())}),this.recalculateAndSaveOverlays(e,r).next(e=>(e.forEach((e,t)=>s.set(e,t)),t.forEach((e,t)=>{var n;return o.set(e,new oo(t,null!==(n=s.get(e))&&void 0!==n?n:null))}),o))}recalculateAndSaveOverlays(e,t){let n=rZ(),i=new ij((e,t)=>e-t),r=r2();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(e=>{for(let r of e)r.keys().forEach(e=>{let s=t.get(e);if(null===s)return;let o=n.get(e)||iW.empty();o=r.applyToLocalView(s,o),n.set(e,o);let a=(i.get(r.batchId)||r2()).add(e);i=i.insert(r.batchId,a)})}).next(()=>{let s=[],o=i.getReverseIterator();for(;o.hasNext();){let a=o.getNext(),l=a.key,h=a.value,u=rJ();h.forEach(e=>{if(!r.has(e)){let i=sd(t.get(e),n.get(e));null!==i&&u.set(e,i),r=r.add(e)}}),s.push(this.documentOverlayCache.saveOverlays(e,l,u))}return iP.waitFor(s)}).next(()=>n)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(t=>this.recalculateAndSaveOverlays(e,t))}getDocumentsMatchingQuery(e,t,n,i){var r,s;return iS.isDocumentKey(t.path)&&null===t.collectionGroup&&0===t.filters.length?this.getDocumentsMatchingDocumentQuery(e,t.path):null!==t.collectionGroup?this.getDocumentsMatchingCollectionGroupQuery(e,t,n,i):this.getDocumentsMatchingCollectionQuery(e,t,n,i)}getNextDocuments(e,t,n,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,n,i).next(r=>{let s=i-r.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,n.largestBatchId,i-r.size):iP.resolve(rX()),o=-1,a=r;return s.next(t=>iP.forEach(t,(t,n)=>(o<n.largestBatchId&&(o=n.largestBatchId),r.get(t)?iP.resolve():this.remoteDocumentCache.getEntry(e,t).next(e=>{a=a.insert(t,e)}))).next(()=>this.populateOverlays(e,t,r)).next(()=>this.computeViews(e,a,t,r2())).next(e=>({batchId:o,changes:rY(e)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new iS(t)).next(e=>{let t=rQ();return e.isFoundDocument()&&(t=t.insert(e.key,e)),t})}getDocumentsMatchingCollectionGroupQuery(e,t,n,i){let r=t.collectionGroup,s=rQ();return this.indexManager.getCollectionParents(e,r).next(o=>iP.forEach(o,o=>{var a,l;let h=(l=o.child(r),new rx(l,null,t.explicitOrderBy.slice(),t.filters.slice(),t.limit,t.limitType,t.startAt,t.endAt));return this.getDocumentsMatchingCollectionQuery(e,h,n,i).next(e=>{e.forEach((e,t)=>{s=s.insert(e,t)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,t,n,i){let r;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,n.largestBatchId).next(s=>(r=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,r,i))).next(e=>{r.forEach((t,n)=>{let i=n.getKey();null===e.get(i)&&(e=e.insert(i,rh.newInvalidDocument(i)))});let n=rQ();return e.forEach((e,i)=>{let s=r.get(e);void 0!==s&&sp(s.mutation,i,iW.empty(),iw.now()),rz(t,i)&&(n=n.insert(e,i))}),n})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ol{constructor(e){this.serializer=e,this.cr=new Map,this.lr=new Map}getBundleMetadata(e,t){return iP.resolve(this.cr.get(t))}saveBundleMetadata(e,t){var n;return this.cr.set(t.id,{id:t.id,version:t.version,createTime:sY(t.createTime)}),iP.resolve()}getNamedQuery(e,t){return iP.resolve(this.lr.get(t))}saveNamedQuery(e,t){var n;return this.lr.set(t.name,{name:t.name,query:function(e){let t=function(e){var t,n,i,r,s,o,a,l,h,u;let c=function(e){let t=sJ(e);return 4===t.length?iI.emptyPath():s4(t)}(e.parent),d=e.structuredQuery,f=d.from?d.from.length:0,p=null;if(f>0){(t=1===f)||ii();let g=d.from[0];g.allDescendants?p=g.collectionId:c=c.child(g.collectionId)}let m=[];d.where&&(m=function(e){let t=function e(t){var n,i;return void 0!==t.unaryFilter?function(e){switch(e.unaryFilter.op){case"IS_NAN":let t=s5(e.unaryFilter.field);return rm.create(t,"==",{doubleValue:NaN});case"IS_NULL":let n=s5(e.unaryFilter.field);return rm.create(n,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":let i=s5(e.unaryFilter.field);return rm.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":let r=s5(e.unaryFilter.field);return rm.create(r,"!=",{nullValue:"NULL_VALUE"});default:return ii()}}(t):void 0!==t.fieldFilter?rm.create(s5(t.fieldFilter.field),function(e){switch(e){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return ii()}}(t.fieldFilter.op),t.fieldFilter.value):void 0!==t.compositeFilter?r_.create(t.compositeFilter.filters.map(t=>e(t)),function(e){switch(e){case"AND":return"and";case"OR":return"or";default:return ii()}}(t.compositeFilter.op)):ii()}(e);return t instanceof r_&&rv(t)?t.getFilters():[t]}(d.where));let _=[];d.orderBy&&(_=(n=d.orderBy).map(e=>{var t;return new rf(s5(e.field),function(e){switch(e){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(e.direction))}));let y=null,v;d.limit&&(y=iL(v="object"==typeof(i=d.limit)?i.value:i)?null:v);let w=null;d.startAt&&(w=function(e){let t=!!e.before,n=e.values||[];return new ru(n,t)}(d.startAt));let b=null;return d.endAt&&(b=function(e){let t=!e.before,n=e.values||[];return new ru(n,t)}(d.endAt)),r=c,s=p,o=_,a=m,l=y,h=w,u=b,new rx(r,s,o,a,l,"F",h,u)}({parent:e.parent,structuredQuery:e.structuredQuery});return"LAST"===e.limitType?rV(t,t.limit,"L"):t}(t.bundledQuery),readTime:sY(t.readTime)}),iP.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oh{constructor(){this.overlays=new ij(iS.comparator),this.hr=new Map}getOverlay(e,t){return iP.resolve(this.overlays.get(t))}getOverlays(e,t){let n=rX();return iP.forEach(t,t=>this.getOverlay(e,t).next(e=>{null!==e&&n.set(t,e)})).next(()=>n)}saveOverlays(e,t,n){return n.forEach((n,i)=>{this.ht(e,t,i)}),iP.resolve()}removeOverlaysForBatchId(e,t,n){let i=this.hr.get(n);return void 0!==i&&(i.forEach(e=>this.overlays=this.overlays.remove(e)),this.hr.delete(n)),iP.resolve()}getOverlaysForCollection(e,t,n){let i=rX(),r=t.length+1,s=new iS(t.child("")),o=this.overlays.getIteratorFrom(s);for(;o.hasNext();){let a=o.getNext().value,l=a.getKey();if(!t.isPrefixOf(l.path))break;l.path.length===r&&a.largestBatchId>n&&i.set(a.getKey(),a)}return iP.resolve(i)}getOverlaysForCollectionGroup(e,t,n,i){let r=new ij((e,t)=>e-t),s=this.overlays.getIterator();for(;s.hasNext();){let o=s.getNext().value;if(o.getKey().getCollectionGroup()===t&&o.largestBatchId>n){let a=r.get(o.largestBatchId);null===a&&(a=rX(),r=r.insert(o.largestBatchId,a)),a.set(o.getKey(),o)}}let l=rX(),h=r.getIterator();for(;h.hasNext()&&(h.getNext().value.forEach((e,t)=>l.set(e,t)),!(l.size()>=i)););return iP.resolve(l)}ht(e,t,n){let i=this.overlays.get(n.key);if(null!==i){let r=this.hr.get(i.largestBatchId).delete(n.key);this.hr.set(i.largestBatchId,r)}this.overlays=this.overlays.insert(n.key,new sS(t,n));let s=this.hr.get(t);void 0===s&&(s=r2(),this.hr.set(t,s)),this.hr.set(t,s.add(n.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ou{constructor(){this.Pr=new iz(oc.Ir),this.Tr=new iz(oc.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(e,t){let n=new oc(e,t);this.Pr=this.Pr.add(n),this.Tr=this.Tr.add(n)}dr(e,t){e.forEach(e=>this.addReference(e,t))}removeReference(e,t){this.Ar(new oc(e,t))}Rr(e,t){e.forEach(e=>this.removeReference(e,t))}Vr(e){let t=new iS(new iI([])),n=new oc(t,e),i=new oc(t,e+1),r=[];return this.Tr.forEachInRange([n,i],e=>{this.Ar(e),r.push(e.key)}),r}mr(){this.Pr.forEach(e=>this.Ar(e))}Ar(e){this.Pr=this.Pr.delete(e),this.Tr=this.Tr.delete(e)}gr(e){let t=new iS(new iI([])),n=new oc(t,e),i=new oc(t,e+1),r=r2();return this.Tr.forEachInRange([n,i],e=>{r=r.add(e.key)}),r}containsKey(e){let t=new oc(e,0),n=this.Pr.firstAfterOrEqual(t);return null!==n&&e.isEqual(n.key)}}class oc{constructor(e,t){this.key=e,this.pr=t}static Ir(e,t){return iS.comparator(e.key,t.key)||iy(e.pr,t.pr)}static Er(e,t){return iy(e.pr,t.pr)||iS.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class od{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.yr=1,this.wr=new iz(oc.Ir)}checkEmpty(e){return iP.resolve(0===this.mutationQueue.length)}addMutationBatch(e,t,n,i){let r=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];let s=new sE(r,t,n,i);for(let o of(this.mutationQueue.push(s),i))this.wr=this.wr.add(new oc(o.key,r)),this.indexManager.addToCollectionParentIndex(e,o.key.path.popLast());return iP.resolve(s)}lookupMutationBatch(e,t){return iP.resolve(this.Sr(t))}getNextMutationBatchAfterBatchId(e,t){let n=this.br(t+1),i=n<0?0:n;return iP.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return iP.resolve(0===this.mutationQueue.length?-1:this.yr-1)}getAllMutationBatches(e){return iP.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){let n=new oc(t,0),i=new oc(t,Number.POSITIVE_INFINITY),r=[];return this.wr.forEachInRange([n,i],e=>{let t=this.Sr(e.pr);r.push(t)}),iP.resolve(r)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new iz(iy);return t.forEach(e=>{let t=new oc(e,0),i=new oc(e,Number.POSITIVE_INFINITY);this.wr.forEachInRange([t,i],e=>{n=n.add(e.pr)})}),iP.resolve(this.Dr(n))}getAllMutationBatchesAffectingQuery(e,t){let n=t.path,i=n.length+1,r=n;iS.isDocumentKey(r)||(r=r.child(""));let s=new oc(new iS(r),0),o=new iz(iy);return this.wr.forEachWhile(e=>{let t=e.key.path;return!!n.isPrefixOf(t)&&(t.length===i&&(o=o.add(e.pr)),!0)},s),iP.resolve(this.Dr(o))}Dr(e){let t=[];return e.forEach(e=>{let n=this.Sr(e);null!==n&&t.push(n)}),t}removeMutationBatch(e,t){var n;0===this.Cr(t.batchId,"removed")||ii(),this.mutationQueue.shift();let i=this.wr;return iP.forEach(t.mutations,n=>{let r=new oc(n.key,t.batchId);return i=i.delete(r),this.referenceDelegate.markPotentiallyOrphaned(e,n.key)}).next(()=>{this.wr=i})}Mn(e){}containsKey(e,t){let n=new oc(t,0),i=this.wr.firstAfterOrEqual(n);return iP.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,iP.resolve()}Cr(e,t){return this.br(e)}br(e){return 0===this.mutationQueue.length?0:e-this.mutationQueue[0].batchId}Sr(e){let t=this.br(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class of{constructor(e){this.vr=e,this.docs=new ij(iS.comparator),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){let n=t.key,i=this.docs.get(n),r=i?i.size:0,s=this.vr(t);return this.docs=this.docs.insert(n,{document:t.mutableCopy(),size:s}),this.size+=s-r,this.indexManager.addToCollectionParentIndex(e,n.path.popLast())}removeEntry(e){let t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){let n=this.docs.get(t);return iP.resolve(n?n.document.mutableCopy():rh.newInvalidDocument(t))}getEntries(e,t){let n=rK;return t.forEach(e=>{let t=this.docs.get(e);n=n.insert(e,t?t.document.mutableCopy():rh.newInvalidDocument(e))}),iP.resolve(n)}getDocumentsMatchingQuery(e,t,n,i){let r=rK,s=t.path,o=new iS(s.child("")),a=this.docs.getIteratorFrom(o);for(;a.hasNext();){let{key:l,value:{document:h}}=a.getNext();if(!s.isPrefixOf(l.path))break;l.path.length>s.length+1||0>=iR(ik(h),n)||(i.has(h.key)||rz(t,h))&&(r=r.insert(h.key,h.mutableCopy()))}return iP.resolve(r)}getAllFromCollectionGroup(e,t,n,i){ii()}Fr(e,t){return iP.forEach(this.docs,e=>t(e))}newChangeBuffer(e){return new op(this)}getSize(e){return iP.resolve(this.size)}}class op extends os{constructor(e){super(),this.ar=e}applyChanges(e){let t=[];return this.changes.forEach((n,i)=>{i.isValidDocument()?t.push(this.ar.addEntry(e,i)):this.ar.removeEntry(n)}),iP.waitFor(t)}getFromCache(e,t){return this.ar.getEntry(e,t)}getAllFromCache(e,t){return this.ar.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class og{constructor(e){this.persistence=e,this.Mr=new rH(e=>rD(e),rP),this.lastRemoteSnapshotVersion=ib.min(),this.highestTargetId=0,this.Or=0,this.Nr=new ou,this.targetCount=0,this.Br=or.Nn()}forEachTarget(e,t){return this.Mr.forEach((e,n)=>t(n)),iP.resolve()}getLastRemoteSnapshotVersion(e){return iP.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return iP.resolve(this.Or)}allocateTargetId(e){return this.highestTargetId=this.Br.next(),iP.resolve(this.highestTargetId)}setTargetsMetadata(e,t,n){return n&&(this.lastRemoteSnapshotVersion=n),t>this.Or&&(this.Or=t),iP.resolve()}qn(e){this.Mr.set(e.target,e);let t=e.targetId;t>this.highestTargetId&&(this.Br=new or(t),this.highestTargetId=t),e.sequenceNumber>this.Or&&(this.Or=e.sequenceNumber)}addTargetData(e,t){return this.qn(t),this.targetCount+=1,iP.resolve()}updateTargetData(e,t){return this.qn(t),iP.resolve()}removeTargetData(e,t){return this.Mr.delete(t.target),this.Nr.Vr(t.targetId),this.targetCount-=1,iP.resolve()}removeTargets(e,t,n){let i=0,r=[];return this.Mr.forEach((s,o)=>{o.sequenceNumber<=t&&null===n.get(o.targetId)&&(this.Mr.delete(s),r.push(this.removeMatchingKeysForTargetId(e,o.targetId)),i++)}),iP.waitFor(r).next(()=>i)}getTargetCount(e){return iP.resolve(this.targetCount)}getTargetData(e,t){let n=this.Mr.get(t)||null;return iP.resolve(n)}addMatchingKeys(e,t,n){return this.Nr.dr(t,n),iP.resolve()}removeMatchingKeys(e,t,n){this.Nr.Rr(t,n);let i=this.persistence.referenceDelegate,r=[];return i&&t.forEach(t=>{r.push(i.markPotentiallyOrphaned(e,t))}),iP.waitFor(r)}removeMatchingKeysForTargetId(e,t){return this.Nr.Vr(t),iP.resolve()}getMatchingKeysForTargetId(e,t){let n=this.Nr.gr(t);return iP.resolve(n)}containsKey(e,t){return iP.resolve(this.Nr.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class om{constructor(e,t){var n;this.Lr={},this.overlays={},this.kr=new ix(0),this.qr=!1,this.qr=!0,this.referenceDelegate=e(this),this.Qr=new og(this),this.indexManager=new ot,this.remoteDocumentCache=(n=e=>this.referenceDelegate.Kr(e),new of(n)),this.serializer=new s8(t),this.$r=new ol(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new oh,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let n=this.Lr[e.toKey()];return n||(n=new od(t,this.referenceDelegate),this.Lr[e.toKey()]=n),n}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(e,t,n){n7("MemoryPersistence","Starting transaction:",e);let i=new o_(this.kr.next());return this.referenceDelegate.Ur(),n(i).next(e=>this.referenceDelegate.Wr(i).next(()=>e)).toPromise().then(e=>(i.raiseOnCommittedEvent(),e))}Gr(e,t){return iP.or(Object.values(this.Lr).map(n=>()=>n.containsKey(e,t)))}}class o_ extends iA{constructor(e){super(),this.currentSequenceNumber=e}}class oy{constructor(e){this.persistence=e,this.zr=new ou,this.jr=null}static Hr(e){return new oy(e)}get Jr(){if(this.jr)return this.jr;throw ii()}addReference(e,t,n){return this.zr.addReference(n,t),this.Jr.delete(n.toString()),iP.resolve()}removeReference(e,t,n){return this.zr.removeReference(n,t),this.Jr.add(n.toString()),iP.resolve()}markPotentiallyOrphaned(e,t){return this.Jr.add(t.toString()),iP.resolve()}removeTarget(e,t){this.zr.Vr(t.targetId).forEach(e=>this.Jr.add(e.toString()));let n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(e,t.targetId).next(e=>{e.forEach(e=>this.Jr.add(e.toString()))}).next(()=>n.removeTargetData(e,t))}Ur(){this.jr=new Set}Wr(e){let t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return iP.forEach(this.Jr,n=>{let i=iS.fromPath(n);return this.Yr(e,i).next(e=>{e||t.removeEntry(i,ib.min())})}).next(()=>(this.jr=null,t.apply(e)))}updateLimboDocument(e,t){return this.Yr(e,t).next(e=>{e?this.Jr.delete(t.toString()):this.Jr.add(t.toString())})}Kr(e){return 0}Yr(e,t){return iP.or([()=>iP.resolve(this.zr.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gr(e,t)])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ov{constructor(e,t,n,i){this.targetId=e,this.fromCache=t,this.qi=n,this.Qi=i}static Ki(e,t){let n=r2(),i=r2();for(let r of t.docChanges)switch(r.type){case 0:n=n.add(r.doc.key);break;case 1:i=i.add(r.doc.key)}return new ov(e,t.fromCache,n,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ow{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ob{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=8}initialize(e,t){this.zi=e,this.indexManager=t,this.$i=!0}getDocumentsMatchingQuery(e,t,n,i){let r={result:null};return this.ji(e,t).next(e=>{r.result=e}).next(()=>{if(!r.result)return this.Hi(e,t,i,n).next(e=>{r.result=e})}).next(()=>{if(r.result)return;let n=new ow;return this.Ji(e,t,n).next(i=>{if(r.result=i,this.Ui)return this.Yi(e,t,n,i.size)})}).next(()=>r.result)}Yi(e,t,n,i){return n.documentReadCount<this.Wi?(n3()<=f.in.DEBUG&&n7("QueryEngine","SDK will not create cache indexes for query:",rB(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),iP.resolve()):(n3()<=f.in.DEBUG&&n7("QueryEngine","Query:",rB(t),"scans",n.documentReadCount,"local documents and returns",i,"documents as results."),n.documentReadCount>this.Gi*i?(n3()<=f.in.DEBUG&&n7("QueryEngine","The SDK decides to create cache indexes for query:",rB(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,rU(t))):iP.resolve())}ji(e,t){if(rM(t))return iP.resolve(null);let n=rU(t);return this.indexManager.getIndexType(e,n).next(i=>0===i?null:(null!==t.limit&&1===i&&(t=rV(t,null,"F"),n=rU(t)),this.indexManager.getDocumentsMatchingTarget(e,n).next(i=>{let r=r2(...i);return this.zi.getDocuments(e,r).next(i=>this.indexManager.getMinOffset(e,n).next(n=>{let s=this.Zi(t,i);return this.Xi(t,s,r,n.readTime)?this.ji(e,rV(t,null,"F")):this.es(e,s,t,n)}))})))}Hi(e,t,n,i){return rM(t)||i.isEqual(ib.min())?iP.resolve(null):this.zi.getDocuments(e,n).next(r=>{let s=this.Zi(t,r);return this.Xi(t,s,n,i)?iP.resolve(null):(n3()<=f.in.DEBUG&&n7("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),rB(t)),this.es(e,s,t,function(e,t){let n=e.toTimestamp().seconds,i=e.toTimestamp().nanoseconds+1,r=ib.fromTimestamp(1e9===i?new iw(n+1,0):new iw(n,i));return new iN(r,iS.empty(),-1)}(i,-1)).next(e=>e))})}Zi(e,t){let n=new iz(r$(e));return t.forEach((t,i)=>{rz(e,i)&&(n=n.add(i))}),n}Xi(e,t,n,i){if(null===e.limit)return!1;if(n.size!==t.size)return!0;let r="F"===e.limitType?t.last():t.first();return!!r&&(r.hasPendingWrites||r.version.compareTo(i)>0)}Ji(e,t,n){return n3()<=f.in.DEBUG&&n7("QueryEngine","Using full collection scan to execute query:",rB(t)),this.zi.getDocumentsMatchingQuery(e,t,iN.min(),n)}es(e,t,n,i){return this.zi.getDocumentsMatchingQuery(e,n,i).next(e=>(t.forEach(t=>{e=e.insert(t.key,t)}),e))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oT{constructor(e,t,n,i){this.persistence=e,this.ts=t,this.serializer=i,this.ns=new ij(iy),this.rs=new rH(e=>rD(e),rP),this.ss=new Map,this.os=e.getRemoteDocumentCache(),this.Qr=e.getTargetCache(),this.$r=e.getBundleCache(),this._s(n)}_s(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new oa(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.ns))}}async function oI(e,t){var n;return await e.persistence.runTransaction("Handle user change","readonly",n=>{let i;return e.mutationQueue.getAllMutationBatches(n).next(r=>(i=r,e._s(t),e.mutationQueue.getAllMutationBatches(n))).next(t=>{let r=[],s=[],o=r2();for(let a of i)for(let l of(r.push(a.batchId),a.mutations))o=o.add(l.key);for(let h of t)for(let u of(s.push(h.batchId),h.mutations))o=o.add(u.key);return e.localDocuments.getDocuments(n,o).next(e=>({us:e,removedBatchIds:r,addedBatchIds:s}))})})}function oE(e){var t;return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Qr.getLastRemoteSnapshotVersion(t))}function oC(e,t){var n;return e.persistence.runTransaction("Get next mutation batch","readonly",n=>(void 0===t&&(t=-1),e.mutationQueue.getNextMutationBatchAfterBatchId(n,t)))}async function oS(e,t,n){var i;let r=e,s=r.ns.get(t);try{n||await r.persistence.runTransaction("Release target",n?"readwrite":"readwrite-primary",e=>r.persistence.referenceDelegate.removeTarget(e,s))}catch(o){if(!iO(o))throw o;n7("LocalStore",`Failed to update sequence numbers for target ${t}: ${o}`)}r.ns=r.ns.remove(t),r.rs.delete(s.target)}function ok(e,t,n){var i;let r=ib.min(),s=r2();return e.persistence.runTransaction("Execute query","readwrite",i=>(function(e,t,n){var i;let r=e.rs.get(n);return void 0!==r?iP.resolve(e.ns.get(r)):e.Qr.getTargetData(t,n)})(e,i,rU(t)).next(t=>{if(t)return r=t.lastLimboFreeSnapshotVersion,e.Qr.getMatchingKeysForTargetId(i,t.targetId).next(e=>{s=e})}).next(()=>e.ts.getDocumentsMatchingQuery(i,t,n?r:ib.min(),n?s:r2())).next(n=>{var i,r,o,a;let l;return r=e,o=t.collectionGroup||(t.path.length%2==1?t.path.lastSegment():t.path.get(t.path.length-2)),a=n,l=r.ss.get(o)||ib.min(),a.forEach((e,t)=>{t.readTime.compareTo(l)>0&&(l=t.readTime)}),r.ss.set(o,l),{documents:n,hs:s}}))}class oN{constructor(){this.activeTargetIds=r4}As(e){this.activeTargetIds=this.activeTargetIds.add(e)}Rs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ds(){let e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class oR{constructor(){this.no=new oN,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,n){}addLocalQueryTarget(e){return this.no.As(e),this.ro[e]||"not-current"}updateQueryState(e,t,n){this.ro[e]=t}removeLocalQueryTarget(e){this.no.Rs(e)}isLocalQueryTarget(e){return this.no.activeTargetIds.has(e)}clearQueryState(e){delete this.ro[e]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(e){return this.no.activeTargetIds.has(e)}start(){return this.no=new oN,Promise.resolve()}handleUserChange(e,t,n){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oA{io(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oD{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(e){this.uo.push(e)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){for(let e of(n7("ConnectivityMonitor","Network connectivity changed: AVAILABLE"),this.uo))e(0)}ao(){for(let e of(n7("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE"),this.uo))e(1)}static C(){return"undefined"!=typeof window&&void 0!==window.addEventListener&&void 0!==window.removeEventListener}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let oP=null;function oO(){return null===oP?oP=268435456+Math.round(2147483648*Math.random()):oP++,"0x"+oP.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let ox={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oL{constructor(e){this.lo=e.lo,this.ho=e.ho}Po(e){this.Io=e}To(e){this.Eo=e}onMessage(e){this.Ao=e}close(){this.ho()}send(e){this.lo(e)}Ro(){this.Io()}Vo(e){this.Eo(e)}mo(e){this.Ao(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let oM="WebChannelConnection";class oF extends class{constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;let t=e.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),i=encodeURIComponent(this.databaseId.database);this.fo=t+"://"+e.host,this.po=`projects/${n}/databases/${i}`,this.yo="(default)"===this.databaseId.database?`project_id=${n}`:`project_id=${n}&database_id=${i}`}get wo(){return!1}So(e,t,n,i,r){let s=oO(),o=this.bo(e,t);n7("RestConnection",`Sending RPC '${e}' ${s}:`,o,n);let a={"google-cloud-resource-prefix":this.po,"x-goog-request-params":this.yo};return this.Do(a,i,r),this.Co(e,o,a,n).then(t=>(n7("RestConnection",`Received RPC '${e}' ${s}: `,t),t),t=>{throw ie("RestConnection",`RPC '${e}' ${s} failed with error: `,t,"url: ",o,"request:",n),t})}vo(e,t,n,i,r,s){return this.So(e,t,n,i,r)}Do(e,t,n){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+n6}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((t,n)=>e[n]=t),n&&n.headers.forEach((t,n)=>e[n]=t)}bo(e,t){let n=ox[e];return`${this.fo}/v1/${t}:${n}`}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Co(e,t,n,i){let r=oO();return new Promise((s,o)=>{let a=new n0;a.setWithCredentials(!0),a.listenOnce(nY.COMPLETE,()=>{try{switch(a.getLastErrorCode()){case nQ.NO_ERROR:let t=a.getResponseJson();n7(oM,`XHR for RPC '${e}' ${r} received:`,JSON.stringify(t)),s(t);break;case nQ.TIMEOUT:n7(oM,`RPC '${e}' ${r} timed out`),o(new is(ir.DEADLINE_EXCEEDED,"Request time out"));break;case nQ.HTTP_ERROR:let n=a.getStatus();if(n7(oM,`RPC '${e}' ${r} failed with status:`,n,"response text:",a.getResponseText()),n>0){let i=a.getResponseJson();Array.isArray(i)&&(i=i[0]);let l=null==i?void 0:i.error;if(l&&l.status&&l.message){let h=function(e){let t=e.toLowerCase().replace(/_/g,"-");return Object.values(ir).indexOf(t)>=0?t:ir.UNKNOWN}(l.status);o(new is(h,l.message))}else o(new is(ir.UNKNOWN,"Server responded with status "+a.getStatus()))}else o(new is(ir.UNAVAILABLE,"Connection failed."));break;default:ii()}}finally{n7(oM,`RPC '${e}' ${r} completed.`)}});let l=JSON.stringify(i);n7(oM,`RPC '${e}' ${r} sending request:`,i),a.send(t,"POST",l,n,15)})}Fo(e,t,n){let i=oO(),r=[this.fo,"/","google.firestore.v1.Firestore","/",e,"/channel"],s=nK(),o=nG(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},h=this.longPollingOptions.timeoutSeconds;void 0!==h&&(a.longPollingTimeout=Math.round(1e3*h)),this.useFetchStreams&&(a.useFetchStreams=!0),this.Do(a.initMessageHeaders,t,n),a.encodeInitMessageHeaders=!0;let u=r.join("");n7(oM,`Creating RPC '${e}' stream ${i}: ${u}`,a);let c=s.createWebChannel(u,a),d=!1,f=!1,p=new oL({lo(t){f?n7(oM,`Not sending because RPC '${e}' stream ${i} is closed:`,t):(d||(n7(oM,`Opening RPC '${e}' stream ${i} transport.`),c.open(),d=!0),n7(oM,`RPC '${e}' stream ${i} sending:`,t),c.send(t))},ho:()=>c.close()}),g=(e,t,n)=>{e.listen(t,e=>{try{n(e)}catch(t){setTimeout(()=>{throw t},0)}})};return g(c,nZ.EventType.OPEN,()=>{f||n7(oM,`RPC '${e}' stream ${i} transport opened.`)}),g(c,nZ.EventType.CLOSE,()=>{f||(f=!0,n7(oM,`RPC '${e}' stream ${i} transport closed`),p.Vo())}),g(c,nZ.EventType.ERROR,t=>{f||(f=!0,ie(oM,`RPC '${e}' stream ${i} transport errored:`,t),p.Vo(new is(ir.UNAVAILABLE,"The operation could not be completed")))}),g(c,nZ.EventType.MESSAGE,t=>{var n,r;if(!f){let s=t.data[0];(r=!!s)||ii();let o=s.error||(null===(n=s[0])||void 0===n?void 0:n.error);if(o){n7(oM,`RPC '${e}' stream ${i} received error:`,o);let a=o.status,h=function(e){let t=l[e];if(void 0!==t)return sN(t)}(a),u=o.message;void 0===h&&(h=ir.INTERNAL,u="Unknown error status: "+a+" with message "+o.message),f=!0,p.Vo(new is(h,u)),c.close()}else n7(oM,`RPC '${e}' stream ${i} received:`,s),p.mo(s)}}),g(o,nX.STAT_EVENT,t=>{t.stat===nJ.PROXY?n7(oM,`RPC '${e}' stream ${i} detected buffering proxy`):t.stat===nJ.NOPROXY&&n7(oM,`RPC '${e}' stream ${i} detected no buffering proxy`)}),setTimeout(()=>{p.Ro()},0),p}}function oU(){return"undefined"!=typeof document?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function oV(e){return new sH(e,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oj{constructor(e,t,n=1e3,i=1.5,r=6e4){this.oi=e,this.timerId=t,this.Mo=n,this.xo=i,this.Oo=r,this.No=0,this.Bo=null,this.Lo=Date.now(),this.reset()}reset(){this.No=0}ko(){this.No=this.Oo}qo(e){this.cancel();let t=Math.floor(this.No+this.Qo()),n=Math.max(0,Date.now()-this.Lo),i=Math.max(0,t-n);i>0&&n7("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.No} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`),this.Bo=this.oi.enqueueAfterDelay(this.timerId,i,()=>(this.Lo=Date.now(),e())),this.No*=this.xo,this.No<this.Mo&&(this.No=this.Mo),this.No>this.Oo&&(this.No=this.Oo)}Ko(){null!==this.Bo&&(this.Bo.skipDelay(),this.Bo=null)}cancel(){null!==this.Bo&&(this.Bo.cancel(),this.Bo=null)}Qo(){return(Math.random()-.5)*this.No}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oq{constructor(e,t,n,i,r,s,o,a){this.oi=e,this.$o=n,this.Uo=i,this.connection=r,this.authCredentialsProvider=s,this.appCheckCredentialsProvider=o,this.listener=a,this.state=0,this.Wo=0,this.Go=null,this.zo=null,this.stream=null,this.jo=new oj(e,t)}Ho(){return 1===this.state||5===this.state||this.Jo()}Jo(){return 2===this.state||3===this.state}start(){4!==this.state?this.auth():this.Yo()}async stop(){this.Ho()&&await this.close(0)}Zo(){this.state=0,this.jo.reset()}Xo(){this.Jo()&&null===this.Go&&(this.Go=this.oi.enqueueAfterDelay(this.$o,6e4,()=>this.e_()))}t_(e){this.n_(),this.stream.send(e)}async e_(){if(this.Jo())return this.close(0)}n_(){this.Go&&(this.Go.cancel(),this.Go=null)}r_(){this.zo&&(this.zo.cancel(),this.zo=null)}async close(e,t){this.n_(),this.r_(),this.jo.cancel(),this.Wo++,4!==e?this.jo.reset():t&&t.code===ir.RESOURCE_EXHAUSTED?(n8(t.toString()),n8("Using maximum backoff delay to prevent overloading the backend."),this.jo.ko()):t&&t.code===ir.UNAUTHENTICATED&&3!==this.state&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),null!==this.stream&&(this.i_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.To(t)}i_(){}auth(){this.state=1;let e=this.s_(this.Wo),t=this.Wo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([e,n])=>{this.Wo===t&&this.o_(e,n)},t=>{e(()=>{let e=new is(ir.UNKNOWN,"Fetching auth token failed: "+t.message);return this.__(e)})})}o_(e,t){let n=this.s_(this.Wo);this.stream=this.a_(e,t),this.stream.Po(()=>{n(()=>(this.state=2,this.zo=this.oi.enqueueAfterDelay(this.Uo,1e4,()=>(this.Jo()&&(this.state=3),Promise.resolve())),this.listener.Po()))}),this.stream.To(e=>{n(()=>this.__(e))}),this.stream.onMessage(e=>{n(()=>this.onMessage(e))})}Yo(){this.state=5,this.jo.qo(async()=>{this.state=0,this.start()})}__(e){return n7("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}s_(e){return t=>{this.oi.enqueueAndForget(()=>this.Wo===e?t():(n7("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class oB extends oq{constructor(e,t,n,i,r,s){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,n,i,s),this.serializer=r}a_(e,t){return this.connection.Fo("Listen",e,t)}onMessage(e){this.jo.reset();let t=function(e,t){let n;if("targetChange"in t){var i,r,s,o;t.targetChange;let a="NO_CHANGE"===(i=t.targetChange.targetChangeType||"NO_CHANGE")?0:"ADD"===i?1:"REMOVE"===i?2:"CURRENT"===i?3:"RESET"===i?4:ii(),l=t.targetChange.targetIds||[],h=(s=t.targetChange.resumeToken,e.useProto3Json?(void 0===s||"string"==typeof s||ii(),iK.fromBase64String(s||"")):(void 0===s||s instanceof Uint8Array||ii(),iK.fromUint8Array(s||new Uint8Array))),u=t.targetChange.cause,c=u&&function(e){let t=void 0===e.code?ir.UNKNOWN:sN(e.code);return new is(t,e.message||"")}(u);n=new sU(a,l,h,c||null)}else if("documentChange"in t){t.documentChange;let d=t.documentChange;d.document,d.document.name,d.document.updateTime;let f=s0(e,d.document.name),p=sY(d.document.updateTime),g=d.document.createTime?sY(d.document.createTime):ib.min(),m=new ra({mapValue:{fields:d.document.fields}}),_=rh.newFoundDocument(f,p,g,m),y=d.targetIds||[],v=d.removedTargetIds||[];n=new sM(y,v,_.key,_)}else if("documentDelete"in t){t.documentDelete;let w=t.documentDelete;w.document;let b=s0(e,w.document),T=w.readTime?sY(w.readTime):ib.min(),I=rh.newNoDocument(b,T),E=w.removedTargetIds||[];n=new sM([],E,I.key,I)}else if("documentRemove"in t){t.documentRemove;let C=t.documentRemove;C.document;let S=s0(e,C.document),k=C.removedTargetIds||[];n=new sM([],k,S,null)}else{if(!("filter"in t))return ii();{t.filter;let N=t.filter;N.targetId;let{count:R=0,unchangedNames:A}=N,D=new sk(R,A),P=N.targetId;n=new sF(P,D)}}return n}(this.serializer,e),n=function(e){if(!("targetChange"in e))return ib.min();let t=e.targetChange;return t.targetIds&&t.targetIds.length?ib.min():t.readTime?sY(t.readTime):ib.min()}(e);return this.listener.u_(t,n)}c_(e){let t={};t.database=s2(this.serializer),t.addTarget=function(e,t){var n,i;let r,s=t.target;if((r=rO(s)?{documents:{documents:[s1(e,s.path)]}}:{query:function(e,t){var n,i;let r={structuredQuery:{}},s=t.path;null!==t.collectionGroup?(r.parent=s1(e,s),r.structuredQuery.from=[{collectionId:t.collectionGroup,allDescendants:!0}]):(r.parent=s1(e,s.popLast()),r.structuredQuery.from=[{collectionId:s.lastSegment()}]);let o=function(e){if(0!==e.length)return function e(t){return t instanceof rm?function(e){var t;if("=="===e.op){if(ri(e.value))return{unaryFilter:{field:s6(e.field),op:"IS_NAN"}};if(rn(e.value))return{unaryFilter:{field:s6(e.field),op:"IS_NULL"}}}else if("!="===e.op){if(ri(e.value))return{unaryFilter:{field:s6(e.field),op:"IS_NOT_NAN"}};if(rn(e.value))return{unaryFilter:{field:s6(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:s6(e.field),op:s$[t=e.op],value:e.value}}}(t):t instanceof r_?function(t){var n;let i=t.getFilters().map(t=>e(t));return 1===i.length?i[0]:{compositeFilter:{op:sW[n=t.op],filters:i}}}(t):ii()}(r_.create(e,"and"))}(t.filters);o&&(r.structuredQuery.where=o);let a=function(e){if(0!==e.length)return e.map(e=>{var t,n;return{field:s6(e.field),direction:(n=e.dir,sz[n])}})}(t.orderBy);a&&(r.structuredQuery.orderBy=a);let l=sK(e,t.limit);return null!==l&&(r.structuredQuery.limit=l),t.startAt&&(r.structuredQuery.startAt={before:(n=t.startAt).inclusive,values:n.position}),t.endAt&&(r.structuredQuery.endAt={before:!(i=t.endAt).inclusive,values:i.position}),r}(e,s)}).targetId=t.targetId,t.resumeToken.approximateByteSize()>0){r.resumeToken=sQ(e,t.resumeToken);let o=sK(e,t.expectedCount);null!==o&&(r.expectedCount=o)}else if(t.snapshotVersion.compareTo(ib.min())>0){r.readTime=sG(e,t.snapshotVersion.toTimestamp());let a=sK(e,t.expectedCount);null!==a&&(r.expectedCount=a)}return r}(this.serializer,e);let n=function(e,t){let n=function(e){switch(e){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return ii()}}(t.purpose);return null==n?null:{"goog-listen-tags":n}}(this.serializer,e);n&&(t.labels=n),this.t_(t)}l_(e){let t={};t.database=s2(this.serializer),t.removeTarget=e,this.t_(t)}}class oz extends oq{constructor(e,t,n,i,r,s){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,n,i,s),this.serializer=r,this.h_=!1}get P_(){return this.h_}start(){this.h_=!1,this.lastStreamToken=void 0,super.start()}i_(){this.h_&&this.I_([])}a_(e,t){return this.connection.Fo("Write",e,t)}onMessage(e){var t,n,i,r;if(!e.streamToken&&ii(),this.lastStreamToken=e.streamToken,this.h_){this.jo.reset();let s=(n=e.writeResults,i=e.commitTime,n&&n.length>0?(void 0!==i||ii(),n.map(e=>{var t,n;let r;return n=i,(r=e.updateTime?sY(e.updateTime):sY(n)).isEqual(ib.min())&&(r=sY(n)),new sl(r,e.transformResults||[])})):[]),o=sY(e.commitTime);return this.listener.T_(o,s)}return e.writeResults&&0!==e.writeResults.length&&ii(),this.h_=!0,this.listener.E_()}d_(){let e={};e.database=s2(this.serializer),this.t_(e)}I_(e){let t={streamToken:this.lastStreamToken,writes:e.map(e=>(function(e,t){var n,i,r,s;let o;if(t instanceof s_)o={update:s9(e,t.key,t.value)};else if(t instanceof sT)o={delete:sZ(e,t.key)};else if(t instanceof sy)o={update:s9(e,t.key,t.data),updateMask:function(e){let t=[];return e.fields.forEach(e=>t.push(e.canonicalString())),{fieldPaths:t}}(t.fieldMask)};else{if(!(t instanceof sI))return ii();o={verify:sZ(e,t.key)}}return t.fieldTransforms.length>0&&(o.updateTransforms=t.fieldTransforms.map(e=>(function(e,t){let n=t.transform;if(n instanceof se)return{fieldPath:t.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(n instanceof st)return{fieldPath:t.field.canonicalString(),appendMissingElements:{values:n.elements}};if(n instanceof si)return{fieldPath:t.field.canonicalString(),removeAllFromArray:{values:n.elements}};if(n instanceof ss)return{fieldPath:t.field.canonicalString(),increment:n.Te};throw ii()})(0,e))),t.precondition.isNone||(o.currentDocument=void 0!==(i=t.precondition).updateTime?{updateTime:sG(e,(s=i.updateTime).toTimestamp())}:void 0!==i.exists?{exists:i.exists}:ii()),o})(this.serializer,e))};this.t_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class o$ extends class{}{constructor(e,t,n,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=n,this.serializer=i,this.A_=!1}R_(){if(this.A_)throw new is(ir.FAILED_PRECONDITION,"The client has already been terminated.")}So(e,t,n){return this.R_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,r])=>this.connection.So(e,t,n,i,r)).catch(e=>{throw"FirebaseError"===e.name?(e.code===ir.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),e):new is(ir.UNKNOWN,e.toString())})}vo(e,t,n,i){return this.R_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([r,s])=>this.connection.vo(e,t,n,r,s,i)).catch(e=>{throw"FirebaseError"===e.name?(e.code===ir.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),e):new is(ir.UNKNOWN,e.toString())})}terminate(){this.A_=!0}}class oW{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.m_=0,this.f_=null,this.g_=!0}p_(){0===this.m_&&(this.y_("Unknown"),this.f_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.f_=null,this.w_("Backend didn't respond within 10 seconds."),this.y_("Offline"),Promise.resolve())))}S_(e){"Online"===this.state?this.y_("Unknown"):(this.m_++,this.m_>=1&&(this.b_(),this.w_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.y_("Offline")))}set(e){this.b_(),this.m_=0,"Online"===e&&(this.g_=!1),this.y_(e)}y_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}w_(e){let t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.g_?(n8(t),this.g_=!1):n7("OnlineStateTracker",t)}b_(){null!==this.f_&&(this.f_.cancel(),this.f_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class oH{constructor(e,t,n,i,r){this.localStore=e,this.datastore=t,this.asyncQueue=n,this.remoteSyncer={},this.D_=[],this.C_=new Map,this.v_=new Set,this.F_=[],this.M_=r,this.M_.io(e=>{n.enqueueAndForget(async()=>{o1(this)&&(n7("RemoteStore","Restarting streams for network reachability change."),await async function(e){var t;e.v_.add(4),await oG(e),e.x_.set("Unknown"),e.v_.delete(4),await oK(e)}(this))})}),this.x_=new oW(n,i)}}async function oK(e){if(o1(e))for(let t of e.F_)await t(!0)}async function oG(e){for(let t of e.F_)await t(!1)}function oQ(e,t){var n;e.C_.has(t.targetId)||(e.C_.set(t.targetId,t),o0(e)?oZ(e):ah(e).Jo()&&oX(e,t))}function oY(e,t){var n;let i=ah(e);e.C_.delete(t),i.Jo()&&oJ(e,t),0===e.C_.size&&(i.Jo()?i.Xo():o1(e)&&e.x_.set("Unknown"))}function oX(e,t){if(e.O_.Ne(t.targetId),t.resumeToken.approximateByteSize()>0||t.snapshotVersion.compareTo(ib.min())>0){let n=e.remoteSyncer.getRemoteKeysForTarget(t.targetId).size;t=t.withExpectedCount(n)}ah(e).c_(t)}function oJ(e,t){e.O_.Ne(t),ah(e).l_(t)}function oZ(e){e.O_=new sj({getRemoteKeysForTarget:t=>e.remoteSyncer.getRemoteKeysForTarget(t),ut:t=>e.C_.get(t)||null,rt:()=>e.datastore.serializer.databaseId}),ah(e).start(),e.x_.p_()}function o0(e){return o1(e)&&!ah(e).Ho()&&e.C_.size>0}function o1(e){var t;return 0===e.v_.size}function o2(e){e.O_=void 0}async function o4(e){e.C_.forEach((t,n)=>{oX(e,t)})}async function o9(e,t){o2(e),o0(e)?(e.x_.S_(t),oZ(e)):e.x_.set("Unknown")}async function o6(e,t,n){if(e.x_.set("Online"),t instanceof sU&&2===t.state&&t.cause)try{await async function(e,t){let n=t.cause;for(let i of t.targetIds)e.C_.has(i)&&(await e.remoteSyncer.rejectListen(i,n),e.C_.delete(i),e.O_.removeTarget(i))}(e,t)}catch(i){n7("RemoteStore","Failed to remove targets %s: %s ",t.targetIds.join(","),i),await o5(e,i)}else if(t instanceof sM?e.O_.Ue(t):t instanceof sF?e.O_.Ye(t):e.O_.ze(t),!n.isEqual(ib.min()))try{let r=await oE(e.localStore);n.compareTo(r)>=0&&await function(e,t){let n=e.O_.st(t);return n.targetChanges.forEach((n,i)=>{if(n.resumeToken.approximateByteSize()>0){let r=e.C_.get(i);r&&e.C_.set(i,r.withResumeToken(n.resumeToken,t))}}),n.targetMismatches.forEach((t,n)=>{let i=e.C_.get(t);if(!i)return;e.C_.set(t,i.withResumeToken(iK.EMPTY_BYTE_STRING,i.snapshotVersion)),oJ(e,t);let r=new s7(i.target,t,n,i.sequenceNumber);oX(e,r)}),e.remoteSyncer.applyRemoteEvent(n)}(e,n)}catch(s){n7("RemoteStore","Failed to raise snapshot:",s),await o5(e,s)}}async function o5(e,t,n){if(!iO(t))throw t;e.v_.add(1),await oG(e),e.x_.set("Offline"),n||(n=()=>oE(e.localStore)),e.asyncQueue.enqueueRetryable(async()=>{n7("RemoteStore","Retrying IndexedDB access"),await n(),e.v_.delete(1),await oK(e)})}function o3(e,t){return t().catch(n=>o5(e,n,t))}async function o7(e){var t;let n=au(e),i=e.D_.length>0?e.D_[e.D_.length-1].batchId:-1;for(;o8(e);)try{let r=await oC(e.localStore,i);if(null===r){0===e.D_.length&&n.Xo();break}i=r.batchId,ae(e,r)}catch(s){await o5(e,s)}at(e)&&an(e)}function o8(e){return o1(e)&&e.D_.length<10}function ae(e,t){e.D_.push(t);let n=au(e);n.Jo()&&n.P_&&n.I_(t.mutations)}function at(e){return o1(e)&&!au(e).Ho()&&e.D_.length>0}function an(e){au(e).start()}async function ai(e){au(e).d_()}async function ar(e){let t=au(e);for(let n of e.D_)t.I_(n.mutations)}async function as(e,t,n){let i=e.D_.shift(),r=sC.from(i,t,n);await o3(e,()=>e.remoteSyncer.applySuccessfulWrite(r)),await o7(e)}async function ao(e,t){t&&au(e).P_&&await async function(e,t){var n;if(function(e){switch(e){default:return ii();case ir.CANCELLED:case ir.UNKNOWN:case ir.DEADLINE_EXCEEDED:case ir.RESOURCE_EXHAUSTED:case ir.INTERNAL:case ir.UNAVAILABLE:case ir.UNAUTHENTICATED:return!1;case ir.INVALID_ARGUMENT:case ir.NOT_FOUND:case ir.ALREADY_EXISTS:case ir.PERMISSION_DENIED:case ir.FAILED_PRECONDITION:case ir.ABORTED:case ir.OUT_OF_RANGE:case ir.UNIMPLEMENTED:case ir.DATA_LOSS:return!0}}(n=t.code)&&n!==ir.ABORTED){let i=e.D_.shift();au(e).Zo(),await o3(e,()=>e.remoteSyncer.rejectFailedWrite(i.batchId,t)),await o7(e)}}(e,t),at(e)&&an(e)}async function aa(e,t){var n;e.asyncQueue.verifyOperationInProgress(),n7("RemoteStore","RemoteStore received new credentials");let i=o1(e);e.v_.add(3),await oG(e),i&&e.x_.set("Unknown"),await e.remoteSyncer.handleCredentialChange(t),e.v_.delete(3),await oK(e)}async function al(e,t){var n;t?(e.v_.delete(2),await oK(e)):t||(e.v_.add(2),await oG(e),e.x_.set("Unknown"))}function ah(e){return e.N_||(e.N_=function(e,t,n){var i;return e.R_(),new oB(t,e.connection,e.authCredentials,e.appCheckCredentials,e.serializer,n)}(e.datastore,e.asyncQueue,{Po:o4.bind(null,e),To:o9.bind(null,e),u_:o6.bind(null,e)}),e.F_.push(async t=>{t?(e.N_.Zo(),o0(e)?oZ(e):e.x_.set("Unknown")):(await e.N_.stop(),o2(e))})),e.N_}function au(e){return e.B_||(e.B_=function(e,t,n){var i;return e.R_(),new oz(t,e.connection,e.authCredentials,e.appCheckCredentials,e.serializer,n)}(e.datastore,e.asyncQueue,{Po:ai.bind(null,e),To:ao.bind(null,e),E_:ar.bind(null,e),T_:as.bind(null,e)}),e.F_.push(async t=>{t?(e.B_.Zo(),await o7(e)):(await e.B_.stop(),e.D_.length>0&&(n7("RemoteStore",`Stopping write stream with ${e.D_.length} pending writes`),e.D_=[]))})),e.B_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ac{constructor(e,t,n,i,r){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=n,this.op=i,this.removalCallback=r,this.deferred=new io,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(e=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,n,i,r){let s=Date.now()+n,o=new ac(e,t,s,i,r);return o.start(n),o}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){null!==this.timerHandle&&(this.clearTimeout(),this.deferred.reject(new is(ir.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>null!==this.timerHandle?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){null!==this.timerHandle&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function ad(e,t){if(n8("AsyncQueue",`${t}: ${e}`),iO(e))return new is(ir.UNAVAILABLE,`${t}: ${e}`);throw e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class af{constructor(e){this.comparator=e?(t,n)=>e(t,n)||iS.comparator(t.key,n.key):(e,t)=>iS.comparator(e.key,t.key),this.keyedMap=rQ(),this.sortedSet=new ij(this.comparator)}static emptySet(e){return new af(e.comparator)}has(e){return null!=this.keyedMap.get(e)}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){let t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,n)=>(e(t),!1))}add(e){let t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){let t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof af)||this.size!==e.size)return!1;let t=this.sortedSet.getIterator(),n=e.sortedSet.getIterator();for(;t.hasNext();){let i=t.getNext().key,r=n.getNext().key;if(!i.isEqual(r))return!1}return!0}toString(){let e=[];return this.forEach(t=>{e.push(t.toString())}),0===e.length?"DocumentSet ()":"DocumentSet (\n  "+e.join("  \n")+"\n)"}copy(e,t){let n=new af;return n.comparator=this.comparator,n.keyedMap=e,n.sortedSet=t,n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ap{constructor(){this.L_=new ij(iS.comparator)}track(e){let t=e.doc.key,n=this.L_.get(t);n?0!==e.type&&3===n.type?this.L_=this.L_.insert(t,e):3===e.type&&1!==n.type?this.L_=this.L_.insert(t,{type:n.type,doc:e.doc}):2===e.type&&2===n.type?this.L_=this.L_.insert(t,{type:2,doc:e.doc}):2===e.type&&0===n.type?this.L_=this.L_.insert(t,{type:0,doc:e.doc}):1===e.type&&0===n.type?this.L_=this.L_.remove(t):1===e.type&&2===n.type?this.L_=this.L_.insert(t,{type:1,doc:n.doc}):0===e.type&&1===n.type?this.L_=this.L_.insert(t,{type:2,doc:e.doc}):ii():this.L_=this.L_.insert(t,e)}k_(){let e=[];return this.L_.inorderTraversal((t,n)=>{e.push(n)}),e}}class ag{constructor(e,t,n,i,r,s,o,a,l){this.query=e,this.docs=t,this.oldDocs=n,this.docChanges=i,this.mutatedKeys=r,this.fromCache=s,this.syncStateChanged=o,this.excludesMetadataChanges=a,this.hasCachedResults=l}static fromInitialDocuments(e,t,n,i,r){let s=[];return t.forEach(e=>{s.push({type:0,doc:e})}),new ag(e,t,af.emptySet(t),s,n,i,!0,!1,r)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&rj(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;let t=this.docChanges,n=e.docChanges;if(t.length!==n.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==n[i].type||!t[i].doc.isEqual(n[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class am{constructor(){this.q_=void 0,this.listeners=[]}}class a_{constructor(){this.queries=new rH(e=>rq(e),rj),this.onlineState="Unknown",this.Q_=new Set}}async function ay(e,t){var n;let i=t.query,r=!1,s=e.queries.get(i);if(s||(r=!0,s=new am),r)try{s.q_=await e.onListen(i)}catch(a){let o=ad(a,`Initialization of query '${rB(t.query)}' failed`);return void t.onError(o)}e.queries.set(i,s),s.listeners.push(t),t.K_(e.onlineState),s.q_&&t.U_(s.q_)&&aT(e)}async function av(e,t){var n;let i=t.query,r=!1,s=e.queries.get(i);if(s){let o=s.listeners.indexOf(t);o>=0&&(s.listeners.splice(o,1),r=0===s.listeners.length)}if(r)return e.queries.delete(i),e.onUnlisten(i)}function aw(e,t){var n;let i=!1;for(let r of t){let s=r.query,o=e.queries.get(s);if(o){for(let a of o.listeners)a.U_(r)&&(i=!0);o.q_=r}}i&&aT(e)}function ab(e,t,n){var i;let r=e.queries.get(t);if(r)for(let s of r.listeners)s.onError(n);e.queries.delete(t)}function aT(e){e.Q_.forEach(e=>{e.next()})}class aI{constructor(e,t,n){this.query=e,this.W_=t,this.G_=!1,this.z_=null,this.onlineState="Unknown",this.options=n||{}}U_(e){if(!this.options.includeMetadataChanges){let t=[];for(let n of e.docChanges)3!==n.type&&t.push(n);e=new ag(e.query,e.docs,e.oldDocs,t,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let i=!1;return this.G_?this.j_(e)&&(this.W_.next(e),i=!0):this.H_(e,this.onlineState)&&(this.J_(e),i=!0),this.z_=e,i}onError(e){this.W_.error(e)}K_(e){this.onlineState=e;let t=!1;return this.z_&&!this.G_&&this.H_(this.z_,e)&&(this.J_(this.z_),t=!0),t}H_(e,t){return!e.fromCache||(!this.options.Y_||!("Offline"!==t))&&(!e.docs.isEmpty()||e.hasCachedResults||"Offline"===t)}j_(e){if(e.docChanges.length>0)return!0;let t=this.z_&&this.z_.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&!0===this.options.includeMetadataChanges}J_(e){e=ag.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.G_=!0,this.W_.next(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class aE{constructor(e){this.key=e}}class aC{constructor(e){this.key=e}}class aS{constructor(e,t){this.query=e,this.sa=t,this.oa=null,this.hasCachedResults=!1,this.current=!1,this._a=r2(),this.mutatedKeys=r2(),this.aa=r$(e),this.ua=new af(this.aa)}get ca(){return this.sa}la(e,t){let n=t?t.ha:new ap,i=t?t.ua:this.ua,r=t?t.mutatedKeys:this.mutatedKeys,s=i,o=!1,a="F"===this.query.limitType&&i.size===this.query.limit?i.last():null,l="L"===this.query.limitType&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((e,t)=>{let h=i.get(e),u=rz(this.query,t)?t:null,c=!!h&&this.mutatedKeys.has(h.key),d=!!u&&(u.hasLocalMutations||this.mutatedKeys.has(u.key)&&u.hasCommittedMutations),f=!1;h&&u?h.data.isEqual(u.data)?c!==d&&(n.track({type:3,doc:u}),f=!0):this.Pa(h,u)||(n.track({type:2,doc:u}),f=!0,(a&&this.aa(u,a)>0||l&&0>this.aa(u,l))&&(o=!0)):!h&&u?(n.track({type:0,doc:u}),f=!0):h&&!u&&(n.track({type:1,doc:h}),f=!0,(a||l)&&(o=!0)),f&&(u?(s=s.add(u),r=d?r.add(e):r.delete(e)):(s=s.delete(e),r=r.delete(e)))}),null!==this.query.limit)for(;s.size>this.query.limit;){let h="F"===this.query.limitType?s.last():s.first();s=s.delete(h.key),r=r.delete(h.key),n.track({type:1,doc:h})}return{ua:s,ha:n,Xi:o,mutatedKeys:r}}Pa(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,n){let i=this.ua;this.ua=e.ua,this.mutatedKeys=e.mutatedKeys;let r=e.ha.k_();r.sort((e,t)=>(function(e,t){let n=e=>{switch(e){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return ii()}};return n(e)-n(t)})(e.type,t.type)||this.aa(e.doc,t.doc)),this.Ia(n);let s=t?this.Ta():[],o=0===this._a.size&&this.current?1:0,a=o!==this.oa;return(this.oa=o,0!==r.length||a)?{snapshot:new ag(this.query,e.ua,i,r,e.mutatedKeys,0===o,a,!1,!!n&&n.resumeToken.approximateByteSize()>0),Ea:s}:{Ea:s}}K_(e){return this.current&&"Offline"===e?(this.current=!1,this.applyChanges({ua:this.ua,ha:new ap,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{Ea:[]}}da(e){return!this.sa.has(e)&&!!this.ua.has(e)&&!this.ua.get(e).hasLocalMutations}Ia(e){e&&(e.addedDocuments.forEach(e=>this.sa=this.sa.add(e)),e.modifiedDocuments.forEach(e=>{}),e.removedDocuments.forEach(e=>this.sa=this.sa.delete(e)),this.current=e.current)}Ta(){if(!this.current)return[];let e=this._a;this._a=r2(),this.ua.forEach(e=>{this.da(e.key)&&(this._a=this._a.add(e.key))});let t=[];return e.forEach(e=>{this._a.has(e)||t.push(new aC(e))}),this._a.forEach(n=>{e.has(n)||t.push(new aE(n))}),t}Aa(e){this.sa=e.hs,this._a=r2();let t=this.la(e.documents);return this.applyChanges(t,!0)}Ra(){return ag.fromInitialDocuments(this.query,this.ua,this.mutatedKeys,0===this.oa,this.hasCachedResults)}}class ak{constructor(e,t,n){this.query=e,this.targetId=t,this.view=n}}class aN{constructor(e){this.key=e,this.Va=!1}}class aR{constructor(e,t,n,i,r,s){this.localStore=e,this.remoteStore=t,this.eventManager=n,this.sharedClientState=i,this.currentUser=r,this.maxConcurrentLimboResolutions=s,this.ma={},this.fa=new rH(e=>rq(e),rj),this.ga=new Map,this.pa=new Set,this.ya=new ij(iS.comparator),this.wa=new Map,this.Sa=new ou,this.ba={},this.Da=new Map,this.Ca=or.Bn(),this.onlineState="Unknown",this.va=void 0}get isPrimaryClient(){return!0===this.va}}async function aA(e,t){let n=function(e){var t;let n=e;return n.remoteStore.remoteSyncer.applyRemoteEvent=ax.bind(null,n),n.remoteStore.remoteSyncer.getRemoteKeysForTarget=aG.bind(null,n),n.remoteStore.remoteSyncer.rejectListen=aM.bind(null,n),n.ma.u_=aw.bind(null,n.eventManager),n.ma.Ma=ab.bind(null,n.eventManager),n}(e),i,r,s=n.fa.get(t);if(s)i=s.targetId,n.sharedClientState.addLocalQueryTarget(i),r=s.view.Ra();else{let o=await function(e,t){var n;let i=e;return i.persistence.runTransaction("Allocate target","readwrite",e=>{let n;return i.Qr.getTargetData(e,t).next(r=>r?(n=r,iP.resolve(n)):i.Qr.allocateTargetId(e).next(r=>(n=new s7(t,r,"TargetPurposeListen",e.currentSequenceNumber),i.Qr.addTargetData(e,n).next(()=>n))))}).then(e=>{let n=i.ns.get(e.targetId);return(null===n||e.snapshotVersion.compareTo(n.snapshotVersion)>0)&&(i.ns=i.ns.insert(e.targetId,e),i.rs.set(t,e.targetId)),e})}(n.localStore,rU(t)),a=n.sharedClientState.addLocalQueryTarget(o.targetId);r=await aD(n,t,i=o.targetId,"current"===a,o.resumeToken),n.isPrimaryClient&&oQ(n.remoteStore,o)}return r}async function aD(e,t,n,i,r){e.Fa=(t,n,i)=>(async function(e,t,n,i){let r=t.view.la(n);r.Xi&&(r=await ok(e.localStore,t.query,!1).then(({documents:e})=>t.view.la(e,r)));let s=i&&i.targetChanges.get(t.targetId),o=t.view.applyChanges(r,e.isPrimaryClient,s);return az(e,t.targetId,o.Ea),o.snapshot})(e,t,n,i);let s=await ok(e.localStore,t,!0),o=new aS(t,s.hs),a=o.la(s.documents),l=sL.createSynthesizedTargetChangeForCurrentChange(n,i&&"Offline"!==e.onlineState,r),h=o.applyChanges(a,e.isPrimaryClient,l);az(e,n,h.Ea);let u=new ak(t,n,o);return e.fa.set(t,u),e.ga.has(n)?e.ga.get(n).push(t):e.ga.set(n,[t]),h.snapshot}async function aP(e,t){var n;let i=e.fa.get(t),r=e.ga.get(i.targetId);if(r.length>1)return e.ga.set(i.targetId,r.filter(e=>!rj(e,t))),void e.fa.delete(t);e.isPrimaryClient?(e.sharedClientState.removeLocalQueryTarget(i.targetId),e.sharedClientState.isActiveQueryTarget(i.targetId)||await oS(e.localStore,i.targetId,!1).then(()=>{e.sharedClientState.clearQueryState(i.targetId),oY(e.remoteStore,i.targetId),aq(e,i.targetId)}).catch(iD)):(aq(e,i.targetId),await oS(e.localStore,i.targetId,!0))}async function aO(e,t,n){let i=function(e){var t;let n=e;return n.remoteStore.remoteSyncer.applySuccessfulWrite=aF.bind(null,n),n.remoteStore.remoteSyncer.rejectFailedWrite=aU.bind(null,n),n}(e);try{var r,s,o;let a=await function(e,t){var n;let i=iw.now(),r=t.reduce((e,t)=>e.add(t.key),r2()),s,o;return e.persistence.runTransaction("Locally write mutations","readwrite",n=>{let a=rK,l=r2();return e.os.getEntries(n,r).next(e=>{(a=e).forEach((e,t)=>{t.isValidDocument()||(l=l.add(e))})}).next(()=>e.localDocuments.getOverlayedDocuments(n,a)).next(r=>{s=r;let o=[];for(let a of t){let l=sg(a,s.get(a.key).overlayedDocument);null!=l&&o.push(new sy(a.key,l,rl(l.value.mapValue),sh.exists(!0)))}return e.mutationQueue.addMutationBatch(n,i,o,t)}).next(t=>{o=t;let i=t.applyToLocalDocumentSet(s,l);return e.documentOverlayCache.saveOverlays(n,t.batchId,i)})}).then(()=>({batchId:o.batchId,changes:rY(s)}))}(i.localStore,t),l;i.sharedClientState.addPendingMutation(a.batchId),r=i,s=a.batchId,(l=r.ba[r.currentUser.toKey()])||(l=new ij(iy)),l=l.insert(s,n),r.ba[r.currentUser.toKey()]=l,await aH(i,a.changes),await o7(i.remoteStore)}catch(u){let h=ad(u,"Failed to persist write");n.reject(h)}}async function ax(e,t){var n;try{let i=await function(e,t){var n;let i=e,r=t.snapshotVersion,s=i.ns;return i.persistence.runTransaction("Apply remote event","readwrite-primary",e=>{var n,o,a;let l=i.os.newChangeBuffer({trackRemovals:!0});s=i.ns;let h=[];t.targetChanges.forEach((n,o)=>{var a,l,u;let c=s.get(o);if(!c)return;h.push(i.Qr.removeMatchingKeys(e,n.removedDocuments,o).next(()=>i.Qr.addMatchingKeys(e,n.addedDocuments,o)));let d=c.withSequenceNumber(e.currentSequenceNumber);null!==t.targetMismatches.get(o)?d=d.withResumeToken(iK.EMPTY_BYTE_STRING,ib.min()).withLastLimboFreeSnapshotVersion(ib.min()):n.resumeToken.approximateByteSize()>0&&(d=d.withResumeToken(n.resumeToken,r)),s=s.insert(o,d),l=d,(0===c.resumeToken.approximateByteSize()||l.snapshotVersion.toMicroseconds()-c.snapshotVersion.toMicroseconds()>=3e8||n.addedDocuments.size+n.modifiedDocuments.size+n.removedDocuments.size>0)&&h.push(i.Qr.updateTargetData(e,d))});let u=rK,c=r2(),d,f;if(t.documentUpdates.forEach(n=>{t.resolvedLimboDocuments.has(n)&&h.push(i.persistence.referenceDelegate.updateLimboDocument(e,n))}),h.push((n=e,o=l,a=t.documentUpdates,d=r2(),f=r2(),a.forEach(e=>d=d.add(e)),o.getEntries(n,d).next(e=>{let t=rK;return a.forEach((n,i)=>{let r=e.get(n);i.isFoundDocument()!==r.isFoundDocument()&&(f=f.add(n)),i.isNoDocument()&&i.version.isEqual(ib.min())?(o.removeEntry(n,i.readTime),t=t.insert(n,i)):!r.isValidDocument()||i.version.compareTo(r.version)>0||0===i.version.compareTo(r.version)&&r.hasPendingWrites?(o.addEntry(i),t=t.insert(n,i)):n7("LocalStore","Ignoring outdated watch update for ",n,". Current version:",r.version," Watch version:",i.version)}),{cs:t,ls:f}})).next(e=>{u=e.cs,c=e.ls})),!r.isEqual(ib.min())){let p=i.Qr.getLastRemoteSnapshotVersion(e).next(t=>i.Qr.setTargetsMetadata(e,e.currentSequenceNumber,r));h.push(p)}return iP.waitFor(h).next(()=>l.apply(e)).next(()=>i.localDocuments.getLocalViewOfDocuments(e,u,c)).next(()=>u)}).then(e=>(i.ns=s,e))}(e.localStore,t);t.targetChanges.forEach((t,n)=>{var i,r,s;let o=e.wa.get(n);o&&(t.addedDocuments.size+t.modifiedDocuments.size+t.removedDocuments.size<=1||ii(),t.addedDocuments.size>0?o.Va=!0:t.modifiedDocuments.size>0?(r=o.Va)||ii():t.removedDocuments.size>0&&(o.Va||ii(),o.Va=!1))}),await aH(e,i,t)}catch(r){await iD(r)}}function aL(e,t,n){var i;let r=e;if(r.isPrimaryClient&&0===n||!r.isPrimaryClient&&1===n){let s=[];r.fa.forEach((e,n)=>{let i=n.view.K_(t);i.snapshot&&s.push(i.snapshot)}),function(e,t){var n;let i=e;i.onlineState=t;let r=!1;i.queries.forEach((e,n)=>{for(let i of n.listeners)i.K_(t)&&(r=!0)}),r&&aT(i)}(r.eventManager,t),s.length&&r.ma.u_(s),r.onlineState=t,r.isPrimaryClient&&r.sharedClientState.setOnlineState(t)}}async function aM(e,t,n){var i;let r=e;r.sharedClientState.updateQueryState(t,"rejected",n);let s=r.wa.get(t),o=s&&s.key;if(o){let a=new ij(iS.comparator);a=a.insert(o,rh.newNoDocument(o,ib.min()));let l=r2().add(o),h=new sx(ib.min(),new Map,new ij(iy),a,l);await ax(r,h),r.ya=r.ya.remove(o),r.wa.delete(t),aW(r)}else await oS(r.localStore,t,!1).then(()=>aq(r,t,n)).catch(iD)}async function aF(e,t){var n;let i=t.batch.batchId;try{let r=await function(e,t){var n;return e.persistence.runTransaction("Acknowledge batch","readwrite-primary",n=>{let i=t.batch.keys(),r=e.os.newChangeBuffer({trackRemovals:!0});return(function(e,t,n,i){let r=n.batch,s=r.keys(),o=iP.resolve();return s.forEach(e=>{o=o.next(()=>i.getEntry(t,e)).next(t=>{let s=n.docVersions.get(e);null!==s||ii(),0>t.version.compareTo(s)&&(r.applyToRemoteDocument(t,n),t.isValidDocument()&&(t.setReadTime(n.commitVersion),i.addEntry(t)))})}),o.next(()=>e.mutationQueue.removeMutationBatch(t,r))})(e,n,t,r).next(()=>r.apply(n)).next(()=>e.mutationQueue.performConsistencyCheck(n)).next(()=>e.documentOverlayCache.removeOverlaysForBatchId(n,i,t.batch.batchId)).next(()=>e.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,function(e){let t=r2();for(let n=0;n<e.mutationResults.length;++n)e.mutationResults[n].transformResults.length>0&&(t=t.add(e.batch.mutations[n].key));return t}(t))).next(()=>e.localDocuments.getDocuments(n,i))})}(e.localStore,t);aj(e,i,null),aV(e,i),e.sharedClientState.updateMutationState(i,"acknowledged"),await aH(e,r)}catch(s){await iD(s)}}async function aU(e,t,n){var i;try{let r=await function(e,t){var n;return e.persistence.runTransaction("Reject batch","readwrite-primary",n=>{let i;return e.mutationQueue.lookupMutationBatch(n,t).next(t=>(null!==t||ii(),i=t.keys(),e.mutationQueue.removeMutationBatch(n,t))).next(()=>e.mutationQueue.performConsistencyCheck(n)).next(()=>e.documentOverlayCache.removeOverlaysForBatchId(n,i,t)).next(()=>e.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,i)).next(()=>e.localDocuments.getDocuments(n,i))})}(e.localStore,t);aj(e,t,n),aV(e,t),e.sharedClientState.updateMutationState(t,"rejected",n),await aH(e,r)}catch(s){await iD(s)}}function aV(e,t){(e.Da.get(t)||[]).forEach(e=>{e.resolve()}),e.Da.delete(t)}function aj(e,t,n){var i;let r=e,s=r.ba[r.currentUser.toKey()];if(s){let o=s.get(t);o&&(n?o.reject(n):o.resolve(),s=s.remove(t)),r.ba[r.currentUser.toKey()]=s}}function aq(e,t,n=null){for(let i of(e.sharedClientState.removeLocalQueryTarget(t),e.ga.get(t)))e.fa.delete(i),n&&e.ma.Ma(i,n);e.ga.delete(t),e.isPrimaryClient&&e.Sa.Vr(t).forEach(t=>{e.Sa.containsKey(t)||aB(e,t)})}function aB(e,t){e.pa.delete(t.path.canonicalString());let n=e.ya.get(t);null!==n&&(oY(e.remoteStore,n),e.ya=e.ya.remove(t),e.wa.delete(n),aW(e))}function az(e,t,n){for(let i of n)i instanceof aE?(e.Sa.addReference(i.key,t),a$(e,i)):i instanceof aC?(n7("SyncEngine","Document no longer in limbo: "+i.key),e.Sa.removeReference(i.key,t),e.Sa.containsKey(i.key)||aB(e,i.key)):ii()}function a$(e,t){let n=t.key,i=n.path.canonicalString();e.ya.get(n)||e.pa.has(i)||(n7("SyncEngine","New document in limbo: "+n),e.pa.add(i),aW(e))}function aW(e){for(;e.pa.size>0&&e.ya.size<e.maxConcurrentLimboResolutions;){let t=e.pa.values().next().value;e.pa.delete(t);let n=new iS(iI.fromString(t)),i=e.Ca.next();e.wa.set(i,new aN(n)),e.ya=e.ya.insert(n,i),oQ(e.remoteStore,new s7(rU(rL(n.path)),i,"TargetPurposeLimboResolution",ix.ae))}}async function aH(e,t,n){var i;let r=[],s=[],o=[];e.fa.isEmpty()||(e.fa.forEach((i,a)=>{o.push(e.Fa(a,t,n).then(t=>{if((t||n)&&e.isPrimaryClient&&e.sharedClientState.updateQueryState(a.targetId,(null==t?void 0:t.fromCache)?"not-current":"current"),t){r.push(t);let i=ov.Ki(a.targetId,t);s.push(i)}}))}),await Promise.all(o),e.ma.u_(r),await async function(e,t){var n;let i=e;try{await i.persistence.runTransaction("notifyLocalViewChanges","readwrite",e=>iP.forEach(t,t=>iP.forEach(t.qi,n=>i.persistence.referenceDelegate.addReference(e,t.targetId,n)).next(()=>iP.forEach(t.Qi,n=>i.persistence.referenceDelegate.removeReference(e,t.targetId,n)))))}catch(r){if(!iO(r))throw r;n7("LocalStore","Failed to update sequence numbers: "+r)}for(let s of t){let o=s.targetId;if(!s.fromCache){let a=i.ns.get(o),l=a.snapshotVersion,h=a.withLastLimboFreeSnapshotVersion(l);i.ns=i.ns.insert(o,h)}}}(e.localStore,s))}async function aK(e,t){var n,i,r;let s=e;if(!s.currentUser.isEqual(t)){n7("SyncEngine","User change. New user:",t.toKey());let o=await oI(s.localStore,t);s.currentUser=t,r="'waitForPendingWrites' promise is rejected due to a user change.",(i=s).Da.forEach(e=>{e.forEach(e=>{e.reject(new is(ir.CANCELLED,r))})}),i.Da.clear(),s.sharedClientState.handleUserChange(t,o.removedBatchIds,o.addedBatchIds),await aH(s,o.us)}}function aG(e,t){var n;let i=e.wa.get(t);if(i&&i.Va)return r2().add(i.key);{let r=r2(),s=e.ga.get(t);if(!s)return r;for(let o of s){let a=e.fa.get(o);r=r.unionWith(a.view.ca)}return r}}class aQ{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=oV(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){var t,n,i,r;return t=this.persistence,n=new ob,i=e.initialUser,r=this.serializer,new oT(t,n,i,r)}createPersistence(e){return new om(oy.Hr,this.serializer)}createSharedClientState(e){return new oR}async terminate(){this.gcScheduler&&this.gcScheduler.stop(),await this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class aY{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=e=>aL(this.syncEngine,e,1),this.remoteStore.remoteSyncer.handleCredentialChange=aK.bind(null,this.syncEngine),await al(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return new a_}createDatastore(e){var t,n,i,r,s;let o=oV(e.databaseInfo.databaseId),a=(t=e.databaseInfo,new oF(t));return n=e.authCredentials,i=e.appCheckCredentials,new o$(n,i,a,o)}createRemoteStore(e){var t,n,i,r,s;return t=this.localStore,n=this.datastore,i=e.asyncQueue,r=e=>aL(this.syncEngine,e,0),s=oD.C()?new oD:new oA,new oH(t,n,i,r,s)}createSyncEngine(e,t){return function(e,t,n,i,r,s,o){let a=new aR(e,t,n,i,r,s);return o&&(a.va=!0),a}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}terminate(){return async function(e){var t;n7("RemoteStore","RemoteStore shutting down."),e.v_.add(5),await oG(e),e.M_.shutdown(),e.x_.set("Unknown")}(this.remoteStore)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ /**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class aX{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Na(this.observer.next,e)}error(e){this.observer.error?this.Na(this.observer.error,e):n8("Uncaught Error in snapshot listener:",e.toString())}Ba(){this.muted=!0}Na(e,t){this.muted||setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class aJ{constructor(e,t,n,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=n,this.databaseInfo=i,this.user=n9.UNAUTHENTICATED,this.clientId=i_.V(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(n,async e=>{n7("FirestoreClient","Received user=",e.uid),await this.authCredentialListener(e),this.user=e}),this.appCheckCredentials.start(n,e=>(n7("FirestoreClient","Received new app check token=",e),this.appCheckCredentialListener(e,this.user)))}async getConfiguration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new is(ir.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();let e=new io;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(n){let t=ad(n,"Failed to shutdown persistence");e.reject(t)}}),e.promise}}async function aZ(e,t){e.asyncQueue.verifyOperationInProgress(),n7("FirestoreClient","Initializing OfflineComponentProvider");let n=await e.getConfiguration();await t.initialize(n);let i=n.initialUser;e.setCredentialChangeListener(async e=>{i.isEqual(e)||(await oI(t.localStore,e),i=e)}),t.persistence.setDatabaseDeletedListener(()=>e.terminate()),e._offlineComponents=t}async function a0(e,t){e.asyncQueue.verifyOperationInProgress();let n=await a1(e);n7("FirestoreClient","Initializing OnlineComponentProvider");let i=await e.getConfiguration();await t.initialize(n,i),e.setCredentialChangeListener(e=>aa(t.remoteStore,e)),e.setAppCheckTokenChangeListener((e,n)=>aa(t.remoteStore,n)),e._onlineComponents=t}async function a1(e){if(!e._offlineComponents){if(e._uninitializedComponentsProvider){n7("FirestoreClient","Using user provided OfflineComponentProvider");try{await aZ(e,e._uninitializedComponentsProvider._offline)}catch(n){var t;if("FirebaseError"===n.name?n.code!==ir.FAILED_PRECONDITION&&n.code!==ir.UNIMPLEMENTED:!!("undefined"!=typeof DOMException&&n instanceof DOMException)&&22!==n.code&&20!==n.code&&11!==n.code)throw n;ie("Error using user provided cache. Falling back to memory cache: "+n),await aZ(e,new aQ)}}else n7("FirestoreClient","Using default OfflineComponentProvider"),await aZ(e,new aQ)}return e._offlineComponents}async function a2(e){return e._onlineComponents||(e._uninitializedComponentsProvider?(n7("FirestoreClient","Using user provided OnlineComponentProvider"),await a0(e,e._uninitializedComponentsProvider._online)):(n7("FirestoreClient","Using default OnlineComponentProvider"),await a0(e,new aY))),e._onlineComponents}async function a4(e){let t=await a2(e),n=t.eventManager;return n.onListen=aA.bind(null,t.syncEngine),n.onUnlisten=aP.bind(null,t.syncEngine),n}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function a9(e){let t={};return void 0!==e.timeoutSeconds&&(t.timeoutSeconds=e.timeoutSeconds),t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let a6=new Map;function a5(e){if(!iS.isDocumentKey(e))throw new is(ir.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${e} has ${e.length}.`)}function a3(e){if(void 0===e)return"undefined";if(null===e)return"null";if("string"==typeof e)return e.length>20&&(e=`${e.substring(0,20)}...`),JSON.stringify(e);if("number"==typeof e||"boolean"==typeof e)return""+e;if("object"==typeof e){if(e instanceof Array)return"an array";{var t;let n=(t=e).constructor?t.constructor.name:null;return n?`a custom ${n} object`:"an object"}}return"function"==typeof e?"a function":ii()}function a7(e,t){if("_delegate"in e&&(e=e._delegate),!(e instanceof t)){if(t.name===e.constructor.name)throw new is(ir.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{let n=a3(e);throw new is(ir.INVALID_ARGUMENT,`Expected type '${t.name}', but it was: ${n}`)}}return e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class a8{constructor(e){var t,n;if(void 0===e.host){if(void 0!==e.ssl)throw new is(ir.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=null===(t=e.ssl)||void 0===t||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,void 0===e.cacheSizeBytes)this.cacheSizeBytes=41943040;else{if(-1!==e.cacheSizeBytes&&e.cacheSizeBytes<1048576)throw new is(ir.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}(function(e,t,n,i){if(!0===t&&!0===i)throw new is(ir.INVALID_ARGUMENT,`${e} and ${n} cannot be used together.`)})("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:void 0===e.experimentalAutoDetectLongPolling?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=a9(null!==(n=e.experimentalLongPollingOptions)&&void 0!==n?n:{}),function(e){if(void 0!==e.timeoutSeconds){if(isNaN(e.timeoutSeconds))throw new is(ir.INVALID_ARGUMENT,`invalid long polling timeout: ${e.timeoutSeconds} (must not be NaN)`);if(e.timeoutSeconds<5)throw new is(ir.INVALID_ARGUMENT,`invalid long polling timeout: ${e.timeoutSeconds} (minimum allowed value is 5)`);if(e.timeoutSeconds>30)throw new is(ir.INVALID_ARGUMENT,`invalid long polling timeout: ${e.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){var t,n;return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&(t=this.experimentalLongPollingOptions,n=e.experimentalLongPollingOptions,t.timeoutSeconds===n.timeoutSeconds)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class le{constructor(e,t,n,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=n,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new a8({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new is(ir.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return void 0!==this._terminateTask}_setSettings(e){if(this._settingsFrozen)throw new is(ir.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new a8(e),void 0!==e.credentials&&(this._authCredentials=function(e){if(!e)return new il;switch(e.type){case"firstParty":return new id(e.sessionIndex||"0",e.iamToken||null,e.authTokenFactory||null);case"provider":return e.client;default:throw new is(ir.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(e){let t=a6.get(e);t&&(n7("ComponentProvider","Removing Datastore"),a6.delete(e),t.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class lt{constructor(e,t,n){this.converter=t,this._query=n,this.type="query",this.firestore=e}withConverter(e){return new lt(this.firestore,e,this._query)}}class ln{constructor(e,t,n){this.converter=t,this._key=n,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new li(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new ln(this.firestore,e,this._key)}}class li extends lt{constructor(e,t,n){super(e,t,rL(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){let e=this._path.popLast();return e.isEmpty()?null:new ln(this.firestore,null,new iS(e))}withConverter(e){return new li(this.firestore,e,this._path)}}function lr(e,t,...n){if(e=(0,p.m9)(e),1===arguments.length&&(t=i_.V()),/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e,t,n){if(!n)throw new is(ir.INVALID_ARGUMENT,`Function doc() cannot be called with an empty ${t}.`)}("doc","path",t),e instanceof le){let i=iI.fromString(t,...n);return a5(i),new ln(e,null,new iS(i))}{if(!(e instanceof ln||e instanceof li))throw new is(ir.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");let r=e._path.child(iI.fromString(t,...n));return a5(r),new ln(e.firestore,e instanceof li?e.converter:null,new iS(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ls{constructor(){this.Ya=Promise.resolve(),this.Za=[],this.Xa=!1,this.eu=[],this.tu=null,this.nu=!1,this.ru=!1,this.iu=[],this.jo=new oj(this,"async_queue_retry"),this.su=()=>{let e=oU();e&&n7("AsyncQueue","Visibility state changed to "+e.visibilityState),this.jo.Ko()};let e=oU();e&&"function"==typeof e.addEventListener&&e.addEventListener("visibilitychange",this.su)}get isShuttingDown(){return this.Xa}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.ou(),this._u(e)}enterRestrictedMode(e){if(!this.Xa){this.Xa=!0,this.ru=e||!1;let t=oU();t&&"function"==typeof t.removeEventListener&&t.removeEventListener("visibilitychange",this.su)}}enqueue(e){if(this.ou(),this.Xa)return new Promise(()=>{});let t=new io;return this._u(()=>this.Xa&&this.ru?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Za.push(e),this.au()))}async au(){if(0!==this.Za.length){try{await this.Za[0](),this.Za.shift(),this.jo.reset()}catch(e){if(!iO(e))throw e;n7("AsyncQueue","Operation failed with retryable error: "+e)}this.Za.length>0&&this.jo.qo(()=>this.au())}}_u(e){let t=this.Ya.then(()=>(this.nu=!0,e().catch(e=>{var t;this.tu=e,this.nu=!1;let n,i=(n=e.message||"",e.stack&&(n=e.stack.includes(e.message)?e.stack:e.message+"\n"+e.stack),n);throw n8("INTERNAL UNHANDLED ERROR: ",i),e}).then(e=>(this.nu=!1,e))));return this.Ya=t,t}enqueueAfterDelay(e,t,n){this.ou(),this.iu.indexOf(e)>-1&&(t=0);let i=ac.createAndSchedule(this,e,t,n,e=>this.uu(e));return this.eu.push(i),i}ou(){this.tu&&ii()}verifyOperationInProgress(){}async cu(){let e;do await (e=this.Ya);while(e!==this.Ya)}lu(e){for(let t of this.eu)if(t.timerId===e)return!0;return!1}hu(e){return this.cu().then(()=>{for(let t of(this.eu.sort((e,t)=>e.targetTimeMs-t.targetTimeMs),this.eu))if(t.skipDelay(),"all"!==e&&t.timerId===e)break;return this.cu()})}Pu(e){this.iu.push(e)}uu(e){let t=this.eu.indexOf(e);this.eu.splice(t,1)}}class lo extends le{constructor(e,t,n,i){super(e,t,n,i),this.type="firestore",this._queue=new ls,this._persistenceKey=(null==i?void 0:i.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||lh(this),this._firestoreClient.terminate()}}function la(e,t){let n="object"==typeof e?e:(0,c.Mq)(),i=(0,c.qX)(n,"firestore").getImmediate({identifier:"string"==typeof e?e:t||"(default)"});if(!i._initialized){let r=(0,p.P0)("firestore");r&&function(e,t,n,i={}){var r;let s=(e=a7(e,le))._getSettings(),o=`${t}:${n}`;if("firestore.googleapis.com"!==s.host&&s.host!==o&&ie("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used."),e._setSettings(Object.assign(Object.assign({},s),{host:o,ssl:!1})),i.mockUserToken){let a,l;if("string"==typeof i.mockUserToken)a=i.mockUserToken,l=n9.MOCK_USER;else{a=(0,p.Sg)(i.mockUserToken,null===(r=e._app)||void 0===r?void 0:r.options.projectId);let h=i.mockUserToken.sub||i.mockUserToken.user_id;if(!h)throw new is(ir.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");l=new n9(h)}e._authCredentials=new ih(new ia(a,l))}}(i,...r)}return i}function ll(e){return e._firestoreClient||lh(e),e._firestoreClient.verifyNotTerminated(),e._firestoreClient}function lh(e){var t,n,i,r,s,o,a;let l=e._freezeSettings(),h=(r=e._databaseId,s=(null===(t=e._app)||void 0===t?void 0:t.options.appId)||"",o=e._persistenceKey,new i1(r,s,o,l.host,l.ssl,l.experimentalForceLongPolling,l.experimentalAutoDetectLongPolling,a9(l.experimentalLongPollingOptions),l.useFetchStreams));e._firestoreClient=new aJ(e._authCredentials,e._appCheckCredentials,e._queue,h),(null===(n=l.localCache)||void 0===n?void 0:n._offlineComponentProvider)&&(null===(i=l.localCache)||void 0===i?void 0:i._onlineComponentProvider)&&(e._firestoreClient._uninitializedComponentsProvider={_offlineKind:l.localCache.kind,_offline:l.localCache._offlineComponentProvider,_online:l.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class lu{constructor(e){this._byteString=e}static fromBase64String(e){try{return new lu(iK.fromBase64String(e))}catch(t){throw new is(ir.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new lu(iK.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class lc{constructor(...e){for(let t=0;t<e.length;++t)if(0===e[t].length)throw new is(ir.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new iC(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class ld{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class lf{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new is(ir.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new is(ir.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return iy(this._lat,e._lat)||iy(this._long,e._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let lp=/^__.*__$/;class lg{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return new sy(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function lm(e){switch(e){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw ii()}}class l_{constructor(e,t,n,i,r,s){this.settings=e,this.databaseId=t,this.serializer=n,this.ignoreUndefinedProperties=i,void 0===r&&this.Iu(),this.fieldTransforms=r||[],this.fieldMask=s||[]}get path(){return this.settings.path}get Tu(){return this.settings.Tu}Eu(e){return new l_(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}du(e){var t;let n=null===(t=this.path)||void 0===t?void 0:t.child(e),i=this.Eu({path:n,Au:!1});return i.Ru(e),i}Vu(e){var t;let n=null===(t=this.path)||void 0===t?void 0:t.child(e),i=this.Eu({path:n,Au:!1});return i.Iu(),i}mu(e){return this.Eu({path:void 0,Au:!0})}fu(e){return lS(e,this.settings.methodName,this.settings.gu||!1,this.path,this.settings.pu)}contains(e){return void 0!==this.fieldMask.find(t=>e.isPrefixOf(t))||void 0!==this.fieldTransforms.find(t=>e.isPrefixOf(t.field))}Iu(){if(this.path)for(let e=0;e<this.path.length;e++)this.Ru(this.path.get(e))}Ru(e){if(0===e.length)throw this.fu("Document fields must not be empty");if(lm(this.Tu)&&lp.test(e))throw this.fu('Document fields cannot begin and end with "__"')}}class ly{constructor(e,t,n){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=n||oV(e)}yu(e,t,n,i=!1){return new l_({Tu:e,methodName:t,pu:n,path:iC.emptyPath(),Au:!1,gu:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}class lv extends ld{_toFieldTransform(e){if(2!==e.Tu)throw 1===e.Tu?e.fu(`${this._methodName}() can only appear at the top level of your update data`):e.fu(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof lv}}function lw(e,t){if(lb(e=(0,p.m9)(e)))return lT("Unsupported field value:",t,e),function(e,t){let n={};return iV(e)?t.path&&t.path.length>0&&t.fieldMask.push(t.path):iU(e,(e,i)=>{let r=lw(i,t.du(e));null!=r&&(n[e]=r)}),{mapValue:{fields:n}}}(e,t);if(e instanceof ld)return function(e,t){if(!lm(t.Tu))throw t.fu(`${e._methodName}() can only be used with update() and set()`);if(!t.path)throw t.fu(`${e._methodName}() is not currently supported inside arrays`);let n=e._toFieldTransform(t);n&&t.fieldTransforms.push(n)}(e,t),null;if(void 0===e&&t.ignoreUndefinedProperties)return null;if(t.path&&t.fieldMask.push(t.path),e instanceof Array){if(t.settings.Au&&4!==t.Tu)throw t.fu("Nested arrays are not supported");return function(e,t){let n=[],i=0;for(let r of e){let s=lw(r,t.mu(i));null==s&&(s={nullValue:"NULL_VALUE"}),n.push(s),i++}return{arrayValue:{values:n}}}(e,t)}return function(e,t){if(null===(e=(0,p.m9)(e)))return{nullValue:"NULL_VALUE"};if("number"==typeof e){var n,i,r;return n=t.serializer,"number"==typeof(i=e)&&Number.isInteger(i)&&!iM(i)&&i<=Number.MAX_SAFE_INTEGER&&i>=Number.MIN_SAFE_INTEGER?r6(i):r9(n,i)}if("boolean"==typeof e)return{booleanValue:e};if("string"==typeof e)return{stringValue:e};if(e instanceof Date){let s=iw.fromDate(e);return{timestampValue:sG(t.serializer,s)}}if(e instanceof iw){let o=new iw(e.seconds,1e3*Math.floor(e.nanoseconds/1e3));return{timestampValue:sG(t.serializer,o)}}if(e instanceof lf)return{geoPointValue:{latitude:e.latitude,longitude:e.longitude}};if(e instanceof lu)return{bytesValue:sQ(t.serializer,e._byteString)};if(e instanceof ln){let a=t.databaseId,l=e.firestore._databaseId;if(!l.isEqual(a))throw t.fu(`Document reference is for database ${l.projectId}/${l.database} but should be for database ${a.projectId}/${a.database}`);return{referenceValue:sX(e.firestore._databaseId||t.databaseId,e._key.path)}}throw t.fu(`Unsupported field value: ${a3(e)}`)}(e,t)}function lb(e){return!("object"!=typeof e||null===e||e instanceof Array||e instanceof Date||e instanceof iw||e instanceof lf||e instanceof lu||e instanceof ln||e instanceof ld)}function lT(e,t,n){var i;if(!lb(n)||"object"!=typeof n||null===n||Object.getPrototypeOf(n)!==Object.prototype&&null!==Object.getPrototypeOf(n)){let r=a3(n);throw"an object"===r?t.fu(e+" a custom object"):t.fu(e+" "+r)}}function lI(e,t,n){if((t=(0,p.m9)(t))instanceof lc)return t._internalPath;if("string"==typeof t)return lC(e,t);throw lS("Field path arguments must be of type string or ",e,!1,void 0,n)}let lE=RegExp("[~\\*/\\[\\]]");function lC(e,t,n){if(t.search(lE)>=0)throw lS(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`,e,!1,void 0,n);try{return new lc(...t.split("."))._internalPath}catch(i){throw lS(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,e,!1,void 0,n)}}function lS(e,t,n,i,r){let s=i&&!i.isEmpty(),o=void 0!==r,a=`Function ${t}() called with invalid data`;n&&(a+=" (via `toFirestore()`)"),a+=". ";let l="";return(s||o)&&(l+=" (found",s&&(l+=` in field ${i}`),o&&(l+=` in document ${r}`),l+=")"),new is(ir.INVALID_ARGUMENT,a+e+l)}function lk(e,t){return e.some(e=>e.isEqual(t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class lN{constructor(e,t,n,i,r){this._firestore=e,this._userDataWriter=t,this._key=n,this._document=i,this._converter=r}get id(){return this._key.path.lastSegment()}get ref(){return new ln(this._firestore,this._converter,this._key)}exists(){return null!==this._document}data(){if(this._document){if(this._converter){let e=new lR(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){let t=this._document.data.field(lA("DocumentSnapshot.get",e));if(null!==t)return this._userDataWriter.convertValue(t)}}}class lR extends lN{data(){return super.data()}}function lA(e,t){return"string"==typeof t?lC(e,t):t instanceof lc?t._internalPath:t._delegate._internalPath}class lD{convertValue(e,t="none"){switch(i9(e)){case 0:return null;case 1:return e.booleanValue;case 2:return iY(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(iX(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw ii()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){let n={};return iU(e,(e,i)=>{n[e]=this.convertValue(i,t)}),n}convertGeoPoint(e){return new lf(iY(e.latitude),iY(e.longitude))}convertArray(e,t){return(e.values||[]).map(e=>this.convertValue(e,t))}convertServerTimestamp(e,t){switch(t){case"previous":let n=iZ(e);return null==n?null:this.convertValue(n,t);case"estimate":return this.convertTimestamp(i0(e));default:return null}}convertTimestamp(e){let t=iQ(e);return new iw(t.seconds,t.nanos)}convertDocumentKey(e,t){var n;let i=iI.fromString(e);(n=s3(i))||ii();let r=new i2(i.get(1),i.get(3)),s=new iS(i.popFirst(5));return r.isEqual(t)||n8(`Document ${s} contains a document reference within a different database (${r.projectId}/${r.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),s}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class lP{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class lO extends lN{constructor(e,t,n,i,r,s){super(e,t,n,i,s),this._firestore=e,this._firestoreImpl=e,this.metadata=r}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){let t=new lx(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){let n=this._document.data.field(lA("DocumentSnapshot.get",e));if(null!==n)return this._userDataWriter.convertValue(n,t.serverTimestamps)}}}class lx extends lO{data(e={}){return super.data(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function lL(e){e=a7(e,ln);let t=a7(e.firestore,lo);return(function(e,t,n={}){let i=new io;return e.asyncQueue.enqueueAndForget(async()=>(function(e,t,n,i,r){let s=new aX({next(s){t.enqueueAndForget(()=>av(e,o));let a=s.docs.has(n);!a&&s.fromCache?r.reject(new is(ir.UNAVAILABLE,"Failed to get document because the client is offline.")):a&&s.fromCache&&i&&"server"===i.source?r.reject(new is(ir.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):r.resolve(s)},error:e=>r.reject(e)}),o=new aI(rL(n.path),s,{includeMetadataChanges:!0,Y_:!0});return ay(e,o)})(await a4(e),e.asyncQueue,t,n,i)),i.promise})(ll(t),e._key).then(n=>(function(e,t,n){let i=n.docs.get(t._key),r=new lM(e);return new lO(e,r,t._key,i,new lP(n.hasPendingWrites,n.fromCache),t.converter)})(t,e,n))}class lM extends lD{constructor(e){super(),this.firestore=e}convertBytes(e){return new lu(e)}convertReference(e){let t=this.convertDocumentKey(e,this.firestore._databaseId);return new ln(this.firestore,null,t)}}function lF(e,t,n,...i){var r,s;e=a7(e,ln);let o=a7(e.firestore,lo),a=function(e){let t=e._freezeSettings(),n=oV(e._databaseId);return new ly(e._databaseId,!!t.ignoreUndefinedProperties,n)}(o),l;return l="string"==typeof(t=(0,p.m9)(t))||t instanceof lc?function(e,t,n,i,r,s){let o=e.yu(1,t,n),a=[lI(t,i,n)],l=[r];if(s.length%2!=0)throw new is(ir.INVALID_ARGUMENT,`Function ${t}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let h=0;h<s.length;h+=2)a.push(lI(t,s[h])),l.push(s[h+1]);let u=[],c=ra.empty();for(let d=a.length-1;d>=0;--d)if(!lk(u,a[d])){let f=a[d],g=l[d];g=(0,p.m9)(g);let m=o.Vu(f);if(g instanceof lv)u.push(f);else{let _=lw(g,m);null!=_&&(u.push(f),c.set(f,_))}}let y=new iW(u);return new lg(c,y,o.fieldTransforms)}(a,"updateDoc",e._key,t,n,i):function(e,t,n,i){let r=e.yu(1,t,n);lT("Data must be an object, but it was:",r,i);let s=[],o=ra.empty();iU(i,(e,i)=>{let a=lC(t,e,n);i=(0,p.m9)(i);let l=r.Vu(a);if(i instanceof lv)s.push(a);else{let h=lw(i,l);null!=h&&(s.push(a),o.set(a,h))}});let a=new iW(s);return new lg(o,a,r.fieldTransforms)}(a,"updateDoc",e._key,t),r=o,s=[l.toMutation(e._key,sh.exists(!0))],function(e,t){let n=new io;return e.asyncQueue.enqueueAndForget(async()=>{var i;return aO(await a2(e).then(e=>e.syncEngine),t,n)}),n.promise}(ll(r),s)}new WeakMap,function(e=!0){var t;n6=c.Jn,(0,c.Xd)(new d.wA("firestore",(t,{instanceIdentifier:n,options:i})=>{let r=t.getProvider("app").getImmediate(),s=new lo(new iu(t.getProvider("auth-internal")),new ig(t.getProvider("app-check-internal")),function(e,t){if(!Object.prototype.hasOwnProperty.apply(e.options,["projectId"]))throw new is(ir.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new i2(e.options.projectId,t)}(r,n),r);return i=Object.assign({useFetchStreams:e},i),s._setSettings(i),s},"PUBLIC").setMultipleInstances(!0)),(0,c.KN)(n4,"4.3.0",void 0),(0,c.KN)(n4,"4.3.0","esm2017")}()},6650:function(e,t,n){"use strict";n.d(t,{Jt:function(){return en},cF:function(){return er},iH:function(){return ei},KV:function(){return et}});var i,r,s,o,a=n(5816),l=n(4444),h=n(8463);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let u="firebasestorage.googleapis.com",c="storageBucket";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class d extends l.ZR{constructor(e,t,n=0){super(f(e),`Firebase Storage: ${t} (${f(e)})`),this.status_=n,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,d.prototype)}get status(){return this.status_}set status(e){this.status_=e}_codeEquals(e){return f(e)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=`${this._baseMessage}
${this.customData.serverResponse}`:this.message=this._baseMessage}}function f(e){return"storage/"+e}function p(){return new d(s.UNKNOWN,"An unknown error occurred, please check the error payload for server response.")}function g(e){return new d(s.INVALID_ARGUMENT,e)}function m(){return new d(s.APP_DELETED,"The Firebase app was deleted.")}function _(e,t){return new d(s.INVALID_FORMAT,"String does not match format '"+e+"': "+t)}function y(e){throw new d(s.INTERNAL_ERROR,"Internal error: "+e)}(i=s||(s={})).UNKNOWN="unknown",i.OBJECT_NOT_FOUND="object-not-found",i.BUCKET_NOT_FOUND="bucket-not-found",i.PROJECT_NOT_FOUND="project-not-found",i.QUOTA_EXCEEDED="quota-exceeded",i.UNAUTHENTICATED="unauthenticated",i.UNAUTHORIZED="unauthorized",i.UNAUTHORIZED_APP="unauthorized-app",i.RETRY_LIMIT_EXCEEDED="retry-limit-exceeded",i.INVALID_CHECKSUM="invalid-checksum",i.CANCELED="canceled",i.INVALID_EVENT_NAME="invalid-event-name",i.INVALID_URL="invalid-url",i.INVALID_DEFAULT_BUCKET="invalid-default-bucket",i.NO_DEFAULT_BUCKET="no-default-bucket",i.CANNOT_SLICE_BLOB="cannot-slice-blob",i.SERVER_FILE_WRONG_SIZE="server-file-wrong-size",i.NO_DOWNLOAD_URL="no-download-url",i.INVALID_ARGUMENT="invalid-argument",i.INVALID_ARGUMENT_COUNT="invalid-argument-count",i.APP_DELETED="app-deleted",i.INVALID_ROOT_OPERATION="invalid-root-operation",i.INVALID_FORMAT="invalid-format",i.INTERNAL_ERROR="internal-error",i.UNSUPPORTED_ENVIRONMENT="unsupported-environment";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class v{constructor(e,t){this.bucket=e,this.path_=t}get path(){return this.path_}get isRoot(){return 0===this.path.length}fullServerUrl(){let e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)}bucketOnlyServerUrl(){let e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o"}static makeFromBucketSpec(e,t){var n;let i;try{i=v.makeFromUrl(e,t)}catch(r){return new v(e,"")}if(""===i.path)return i;throw new d(s.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+e+"'.")}static makeFromUrl(e,t){let n=null,i="([A-Za-z0-9.\\-_]+)",r=RegExp("^gs://"+i+"(/(.*))?$","i");function o(e){e.path_=decodeURIComponent(e.path)}let a=t.replace(/[.]/g,"\\."),l=RegExp(`^https?://${a}/v[A-Za-z0-9_]+/b/${i}/o(/([^?#]*).*)?$`,"i"),h=RegExp(`^https?://${t===u?"(?:storage.googleapis.com|storage.cloud.google.com)":t}/${i}/([^?#]*)`,"i"),c=[{regex:r,indices:{bucket:1,path:3},postModify:function(e){"/"===e.path.charAt(e.path.length-1)&&(e.path_=e.path_.slice(0,-1))}},{regex:l,indices:{bucket:1,path:3},postModify:o},{regex:h,indices:{bucket:1,path:2},postModify:o}];for(let f=0;f<c.length;f++){let p=c[f],g=p.regex.exec(e);if(g){let m=g[p.indices.bucket],_=g[p.indices.path];_||(_=""),n=new v(m,_),p.postModify(n);break}}if(null==n){var y;throw new d(s.INVALID_URL,"Invalid URL '"+e+"'.")}return n}}class w{constructor(e){this.promise_=Promise.reject(e)}getPromise(){return this.promise_}cancel(e=!1){}}function b(e){return"string"==typeof e||e instanceof String}function T(e){return I()&&e instanceof Blob}function I(){return"undefined"!=typeof Blob&&!(0,l.UG)()}function E(e,t,n,i){if(i<t)throw g(`Invalid value for '${e}'. Expected ${t} or greater.`);if(i>n)throw g(`Invalid value for '${e}'. Expected ${n} or less.`)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function C(e,t,n){let i=t;return null==n&&(i=`https://${t}`),`${n}://${i}/v0${e}`}function S(e){let t=encodeURIComponent,n="?";for(let i in e)if(e.hasOwnProperty(i)){let r=t(i)+"="+t(e[i]);n=n+r+"&"}return n.slice(0,-1)}(r=o||(o={}))[r.NO_ERROR=0]="NO_ERROR",r[r.NETWORK_ERROR=1]="NETWORK_ERROR",r[r.ABORT=2]="ABORT";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class k{constructor(e,t,n,i,r,s,o,a,l,h,u,c=!0){this.url_=e,this.method_=t,this.headers_=n,this.body_=i,this.successCodes_=r,this.additionalRetryCodes_=s,this.callback_=o,this.errorCallback_=a,this.timeout_=l,this.progressCallback_=h,this.connectionFactory_=u,this.retry=c,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise((e,t)=>{this.resolve_=e,this.reject_=t,this.start_()})}start_(){let e=(e,t)=>{if(t){e(!1,new N(!1,null,!0));return}let n=this.connectionFactory_();this.pendingConnection_=n;let i=e=>{let t=e.loaded,n=e.lengthComputable?e.total:-1;null!==this.progressCallback_&&this.progressCallback_(t,n)};null!==this.progressCallback_&&n.addUploadProgressListener(i),n.send(this.url_,this.method_,this.body_,this.headers_).then(()=>{null!==this.progressCallback_&&n.removeUploadProgressListener(i),this.pendingConnection_=null;let t=n.getErrorCode()===o.NO_ERROR,r=n.getStatus();if(!t||/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e,t){let n=-1!==[408,429].indexOf(e),i=-1!==t.indexOf(e);return e>=500&&e<600||n||i}(r,this.additionalRetryCodes_)&&this.retry){let s=n.getErrorCode()===o.ABORT;e(!1,new N(!1,null,s));return}let a=-1!==this.successCodes_.indexOf(r);e(!0,new N(a,n))})},t=(e,t)=>{let n=this.resolve_,i=this.reject_,r=t.connection;if(t.wasSuccessCode)try{var o;let a=this.callback_(r,r.getResponse());void 0!==a?n(a):n()}catch(l){i(l)}else if(null!==r){let h=p();h.serverResponse=r.getErrorText(),i(this.errorCallback_?this.errorCallback_(r,h):h)}else if(t.canceled){let u=this.appDelete_?m():new d(s.CANCELED,"User canceled the upload/download.");i(u)}else{let c=new d(s.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.");i(c)}};this.canceled_?t(!1,new N(!1,null,!0)):this.backoffId_=/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e,t,n){let i=1,r=null,s=null,o=!1,a=0;function l(){return 2===a}let h=!1;function u(...e){h||(h=!0,t.apply(null,e))}function c(t){r=setTimeout(()=>{r=null,e(f,l())},t)}function d(){s&&clearTimeout(s)}function f(e,...t){if(h){d();return}if(e){d(),u.call(null,e,...t);return}let n=l()||o;if(n){d(),u.call(null,e,...t);return}i<64&&(i*=2);let r;1===a?(a=2,r=0):r=(i+Math.random())*1e3,c(r)}let p=!1;function g(e){if(!p)p=!0,d(),!h&&(null!==r?(e||(a=2),clearTimeout(r),c(0)):e||(a=1))}return c(0),s=setTimeout(()=>{o=!0,g(!0)},n),g}(e,t,this.timeout_)}getPromise(){return this.promise_}cancel(e){if(this.canceled_=!0,this.appDelete_=e||!1,null!==this.backoffId_){var t;(t=this.backoffId_)(!1)}null!==this.pendingConnection_&&this.pendingConnection_.abort()}}class N{constructor(e,t,n){this.wasSuccessCode=e,this.connection=t,this.canceled=!!n}}function R(...e){let t="undefined"!=typeof BlobBuilder?BlobBuilder:"undefined"!=typeof WebKitBlobBuilder?WebKitBlobBuilder:void 0;if(void 0!==t){let n=new t;for(let i=0;i<e.length;i++)n.append(e[i]);return n.getBlob()}if(I())return new Blob(e);throw new d(s.UNSUPPORTED_ENVIRONMENT,"This browser doesn't seem to support creating Blobs")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ let A={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"};class D{constructor(e,t){this.data=e,this.contentType=t||null}}function P(e){let t=[];for(let n=0;n<e.length;n++){let i=e.charCodeAt(n);if(i<=127)t.push(i);else if(i<=2047)t.push(192|i>>6,128|63&i);else if((64512&i)==55296){let r=n<e.length-1&&(64512&e.charCodeAt(n+1))==56320;if(r){let s=i,o=e.charCodeAt(++n);i=65536|(1023&s)<<10|1023&o,t.push(240|i>>18,128|i>>12&63,128|i>>6&63,128|63&i)}else t.push(239,191,189)}else(64512&i)==56320?t.push(239,191,189):t.push(224|i>>12,128|i>>6&63,128|63&i)}return new Uint8Array(t)}function O(e,t){switch(e){case A.BASE64:{let n=-1!==t.indexOf("-"),i=-1!==t.indexOf("_");if(n||i)throw _(e,"Invalid character '"+(n?"-":"_")+"' found: is it base64url encoded?");break}case A.BASE64URL:{let r=-1!==t.indexOf("+"),o=-1!==t.indexOf("/");if(r||o)throw _(e,"Invalid character '"+(r?"+":"/")+"' found: is it base64 encoded?");t=t.replace(/-/g,"+").replace(/_/g,"/")}}let a;try{a=/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){if("undefined"==typeof atob){var t;throw new d(s.UNSUPPORTED_ENVIRONMENT,"base-64 is missing. Make sure to install the required polyfills. See https://firebase.google.com/docs/web/environments-js-sdk#polyfills for more information.")}return atob(e)}(t)}catch(l){if(l.message.includes("polyfill"))throw l;throw _(e,"Invalid character found")}let h=new Uint8Array(a.length);for(let u=0;u<a.length;u++)h[u]=a.charCodeAt(u);return h}class x{constructor(e){this.base64=!1,this.contentType=null;let t=e.match(/^data:([^,]+)?,/);if(null===t)throw _(A.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");let n=t[1]||null;null!=n&&(this.base64=function(e,t){let n=e.length>=t.length;return!!n&&e.substring(e.length-t.length)===t}(n,";base64"),this.contentType=this.base64?n.substring(0,n.length-7):n),this.rest=e.substring(e.indexOf(",")+1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class L{constructor(e,t){let n=0,i="";T(e)?(this.data_=e,n=e.size,i=e.type):e instanceof ArrayBuffer?(t?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),n=this.data_.length):e instanceof Uint8Array&&(t?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),n=e.length),this.size_=n,this.type_=i}size(){return this.size_}type(){return this.type_}slice(e,t){if(T(this.data_)){var n,i,r;let s=this.data_,o=(n=s,i=e,r=t,n.webkitSlice?n.webkitSlice(i,r):n.mozSlice?n.mozSlice(i,r):n.slice?n.slice(i,r):null);return null===o?null:new L(o)}{let a=new Uint8Array(this.data_.buffer,e,t-e);return new L(a,!0)}}static getBlob(...e){if(I()){let t=e.map(e=>e instanceof L?e.data_:e);return new L(R.apply(null,t))}{let n=e.map(e=>b(e)?function(e,t){switch(e){case A.RAW:return new D(P(t));case A.BASE64:case A.BASE64URL:return new D(O(e,t));case A.DATA_URL:return new D(function(e){let t=new x(e);return t.base64?O(A.BASE64,t.rest):function(e){let t;try{t=decodeURIComponent(e)}catch(n){throw _(A.DATA_URL,"Malformed data URL.")}return P(t)}(t.rest)}(t),function(e){let t=new x(e);return t.contentType}(t))}throw p()}(A.RAW,e).data:e.data_),i=0;n.forEach(e=>{i+=e.byteLength});let r=new Uint8Array(i),s=0;return n.forEach(e=>{for(let t=0;t<e.length;t++)r[s++]=e[t]}),new L(r,!0)}}uploadData(){return this.data_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function M(e){var t;let n;try{n=JSON.parse(e)}catch(i){return null}return"object"!=typeof(t=n)||Array.isArray(t)?null:n}function F(e){let t=e.lastIndexOf("/",e.length-2);return -1===t?e:e.slice(t+1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function U(e,t){return t}class V{constructor(e,t,n,i){this.server=e,this.local=t||e,this.writable=!!n,this.xform=i||U}}let j=null;function q(){if(j)return j;let e=[];e.push(new V("bucket")),e.push(new V("generation")),e.push(new V("metageneration")),e.push(new V("name","fullPath",!0));let t=new V("name");t.xform=function(e,t){var n;return!b(t)||t.length<2?t:F(t)},e.push(t);let n=new V("size");return n.xform=function(e,t){return void 0!==t?Number(t):t},e.push(n),e.push(new V("timeCreated")),e.push(new V("updated")),e.push(new V("md5Hash",null,!0)),e.push(new V("cacheControl",null,!0)),e.push(new V("contentDisposition",null,!0)),e.push(new V("contentEncoding",null,!0)),e.push(new V("contentLanguage",null,!0)),e.push(new V("contentType",null,!0)),e.push(new V("metadata","customMetadata",!0)),j=e}function B(e,t,n){let i=M(t);return null===i?null:function(e,t,n){var i,r;let s={};s.type="file";let o=n.length;for(let a=0;a<o;a++){let l=n[a];s[l.local]=l.xform(s,t[l.server])}return Object.defineProperty(s,"ref",{get:function(){let t=s.bucket,n=s.fullPath,i=new v(t,n);return e._makeStorageReference(i)}}),s}(e,i,n)}class z{constructor(e,t,n,i){this.url=e,this.method=t,this.handler=n,this.timeout=i,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function $(e){if(!e)throw p()}function W(e){return function(t,n){var i,r;let o;return 401===t.getStatus()?o=t.getErrorText().includes("Firebase App Check token is invalid")?new d(s.UNAUTHORIZED_APP,"This app does not have permission to access Firebase Storage on this project."):new d(s.UNAUTHENTICATED,"User is not authenticated, please authenticate using Firebase Authentication and try again."):402===t.getStatus()?(i=e.bucket,o=new d(s.QUOTA_EXCEEDED,"Quota for bucket '"+i+"' exceeded, please view quota on https://firebase.google.com/pricing/.")):403===t.getStatus()?(r=e.path,o=new d(s.UNAUTHORIZED,"User does not have permission to access '"+r+"'.")):o=n,o.status=t.getStatus(),o.serverResponse=n.serverResponse,o}}class H{constructor(){this.sent_=!1,this.xhr_=new XMLHttpRequest,this.initXhr(),this.errorCode_=o.NO_ERROR,this.sendPromise_=new Promise(e=>{this.xhr_.addEventListener("abort",()=>{this.errorCode_=o.ABORT,e()}),this.xhr_.addEventListener("error",()=>{this.errorCode_=o.NETWORK_ERROR,e()}),this.xhr_.addEventListener("load",()=>{e()})})}send(e,t,n,i){if(this.sent_)throw y("cannot .send() more than once");if(this.sent_=!0,this.xhr_.open(t,e,!0),void 0!==i)for(let r in i)i.hasOwnProperty(r)&&this.xhr_.setRequestHeader(r,i[r].toString());return void 0!==n?this.xhr_.send(n):this.xhr_.send(),this.sendPromise_}getErrorCode(){if(!this.sent_)throw y("cannot .getErrorCode() before sending");return this.errorCode_}getStatus(){if(!this.sent_)throw y("cannot .getStatus() before sending");try{return this.xhr_.status}catch(e){return -1}}getResponse(){if(!this.sent_)throw y("cannot .getResponse() before sending");return this.xhr_.response}getErrorText(){if(!this.sent_)throw y("cannot .getErrorText() before sending");return this.xhr_.statusText}abort(){this.xhr_.abort()}getResponseHeader(e){return this.xhr_.getResponseHeader(e)}addUploadProgressListener(e){null!=this.xhr_.upload&&this.xhr_.upload.addEventListener("progress",e)}removeUploadProgressListener(e){null!=this.xhr_.upload&&this.xhr_.upload.removeEventListener("progress",e)}}class K extends H{initXhr(){this.xhr_.responseType="text"}}function G(){return new K}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ class Q{constructor(e,t){this._service=e,t instanceof v?this._location=t:this._location=v.makeFromUrl(t,e.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(e,t){return new Q(e,t)}get root(){let e=new v(this._location.bucket,"");return this._newRef(this._service,e)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return F(this._location.path)}get storage(){return this._service}get parent(){let e=/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ function(e){if(0===e.length)return null;let t=e.lastIndexOf("/");if(-1===t)return"";let n=e.slice(0,t);return n}(this._location.path);if(null===e)return null;let t=new v(this._location.bucket,e);return new Q(this._service,t)}_throwIfRoot(e){if(""===this._location.path){var t;throw new d(s.INVALID_ROOT_OPERATION,"The operation '"+e+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}}}function Y(e,t){let n=null==t?void 0:t[c];return null==n?null:v.makeFromBucketSpec(n,e)}class X{constructor(e,t,n,i,r){this.app=e,this._authProvider=t,this._appCheckProvider=n,this._url=i,this._firebaseVersion=r,this._bucket=null,this._host=u,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=12e4,this._maxUploadRetryTime=6e5,this._requests=new Set,null!=i?this._bucket=v.makeFromBucketSpec(i,this._host):this._bucket=Y(this._host,this.app.options)}get host(){return this._host}set host(e){this._host=e,null!=this._url?this._bucket=v.makeFromBucketSpec(this._url,e):this._bucket=Y(e,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(e){E("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(e){E("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;let e=this._authProvider.getImmediate({optional:!0});if(e){let t=await e.getToken();if(null!==t)return t.accessToken}return null}async _getAppCheckToken(){let e=this._appCheckProvider.getImmediate({optional:!0});if(e){let t=await e.getToken();return t.token}return null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach(e=>e.cancel()),this._requests.clear()),Promise.resolve()}_makeStorageReference(e){return new Q(this,e)}_makeRequest(e,t,n,i,r=!0){if(this._deleted)return new w(m());{let s=function(e,t,n,i,r,s,o=!0){var a,l,h,u,c,d,f,p;let g=S(e.urlParams),m=e.url+g,_=Object.assign({},e.headers);return a=_,t&&(a["X-Firebase-GMPID"]=t),h=_,null!==n&&n.length>0&&(h.Authorization="Firebase "+n),(c=_)["X-Firebase-Storage-Version"]="webjs/"+(null!=s?s:"AppManager"),f=_,null!==i&&(f["X-Firebase-AppCheck"]=i),new k(m,e.method,_,e.body,e.successCodes,e.additionalRetryCodes,e.handler,e.errorHandler,e.timeout,e.progressCallback,r,o)}(e,this._appId,n,i,t,this._firebaseVersion,r);return this._requests.add(s),s.getPromise().then(()=>this._requests.delete(s),()=>this._requests.delete(s)),s}}async makeRequestWithTokens(e,t){let[n,i]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(e,t,n,i).getPromise()}}let J="@firebase/storage",Z="0.11.2",ee="storage";function et(e,t,n){return function(e,t,n){e._throwIfRoot("uploadBytes");let i=function(e,t,n,i,r){var o,a;let l=t.bucketOnlyServerUrl(),h={"X-Goog-Upload-Protocol":"multipart"},u=function(){let e="";for(let t=0;t<2;t++)e+=Math.random().toString().slice(2);return e}();h["Content-Type"]="multipart/related; boundary="+u;let c=function(e,t,n){let i=Object.assign({},n);if(i.fullPath=e.path,i.size=t.size(),!i.contentType){var r,s;i.contentType=t&&t.type()||"application/octet-stream"}return i}(t,i,r),f=function(e,t){let n={},i=t.length;for(let r=0;r<i;r++){let s=t[r];s.writable&&(n[s.server]=e[s.local])}return JSON.stringify(n)}(c,n),p="--"+u+"\r\nContent-Type: application/json; charset=utf-8\r\n\r\n"+f+"\r\n--"+u+"\r\nContent-Type: "+c.contentType+"\r\n\r\n",g=L.getBlob(p,i,"\r\n--"+u+"--");if(null===g)throw new d(s.CANNOT_SLICE_BLOB,"Cannot slice blob for upload. Please retry the upload.");let m={name:c.fullPath},_=C(l,e.host,e._protocol),y=e.maxUploadRetryTime,v=new z(_,"POST",function(t,i){let r=B(e,i,n);return $(null!==r),r},y);return v.urlParams=m,v.headers=h,v.body=g.uploadData(),v.errorHandler=W(t),v}(e.storage,e._location,q(),new L(t,!0),n);return e.storage.makeRequestWithTokens(i,G).then(t=>({metadata:t,ref:e}))}(e=(0,l.m9)(e),t,n)}function en(e){return function(e){e._throwIfRoot("getDownloadURL");let t=function(e,t,n){var i,r;let o=t.fullServerUrl(),a=C(o,e.host,e._protocol),l=e.maxOperationRetryTime,h=new z(a,"GET",function(t,i){let r=B(e,i,n);return $(null!==r),function(e,t,n,i){let r=M(t);if(null===r||!b(r.downloadTokens))return null;let s=r.downloadTokens;if(0===s.length)return null;let o=encodeURIComponent,a=s.split(","),l=a.map(t=>{let r=e.bucket,s=e.fullPath,a="/b/"+o(r)+"/o/"+o(s),l=C(a,n,i),h=S({alt:"media",token:t});return l+h});return l[0]}(r,i,e.host,e._protocol)},l);return h.errorHandler=function(e){let t=W(e);return function(n,i){let r=t(n,i);if(404===n.getStatus()){var o;o=e.path,r=new d(s.OBJECT_NOT_FOUND,"Object '"+o+"' does not exist.")}return r.serverResponse=i.serverResponse,r}}(t),h}(e.storage,e._location,q());return e.storage.makeRequestWithTokens(t,G).then(e=>{if(null===e)throw new d(s.NO_DOWNLOAD_URL,"The given file does not have any download URLs.");return e})}(e=(0,l.m9)(e))}function ei(e,t){return function(e,t){var n,i,r;if(!(t&&/^[A-Za-z]+:\/\//.test(t)))return function e(t,n){if(t instanceof X){if(null==t._bucket)throw new d(s.NO_DEFAULT_BUCKET,"No default bucket found. Did you set the '"+c+"' property when initializing the app?");let i=new Q(t,t._bucket);return null!=n?e(i,n):i}return void 0!==n?function(e,t){let n=function(e,t){let n=t.split("/").filter(e=>e.length>0).join("/");return 0===e.length?n:e+"/"+n}(e._location.path,t),i=new v(e._location.bucket,n);return new Q(e.storage,i)}(t,n):t}(e,t);if(e instanceof X)return i=e,r=t,new Q(i,r);throw g("To use ref(service, url), the first argument must be a Storage instance.")}(e=(0,l.m9)(e),t)}function er(e=(0,a.Mq)(),t){e=(0,l.m9)(e);let n=(0,a.qX)(e,ee),i=n.getImmediate({identifier:t}),r=(0,l.P0)("storage");return r&&function(e,t,n,i={}){!function(e,t,n,i={}){e.host=`${t}:${n}`,e._protocol="http";let{mockUserToken:r}=i;r&&(e._overrideAuthToken="string"==typeof r?r:(0,l.Sg)(r,e.app.options.projectId))}(e,t,n,i)}(i,...r),i}(0,a.Xd)(new h.wA(ee,function e(t,{instanceIdentifier:n}){let i=t.getProvider("app").getImmediate(),r=t.getProvider("auth-internal"),s=t.getProvider("app-check-internal");return new X(i,r,s,n,a.Jn)},"PUBLIC").setMultipleInstances(!0)),(0,a.KN)(J,Z,""),(0,a.KN)(J,Z,"esm2017")}},function(e){var t=function(t){return e(e.s=t)};e.O(0,[774,179],function(){return t(1118),t(387)}),_N_E=e.O()}]);